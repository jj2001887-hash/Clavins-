'use strict';
/**
 * talklessBridge — mounts the TALKLESS command pack (talkless/) inside this bot,
 * with per-number data isolation.
 *
 * Every message is dispatched inside an AsyncLocalStorage scope keyed by the
 * paired number (sock.user.id), so talkless/database and talkless/data resolve to
 * talkless/{database,data}/numbers/<number>/ for that session only.
 */
const path = require('path');

// The obfuscated Talkless command modules call global.log(msg, color). The original
// Talkless runtime defines it in its own index.js; this host never did, so any
// failed log call threw "global[...] is not a function" and killed the process.
if (typeof global.log !== 'function') {
  global.log = (msg, color) => {
    if (color) console.log(String(msg));
    else console.log(String(msg));
  };
}

global.__CORE__ = path.join(__dirname, 'talkless');
global.__ROOT__ = path.join(__dirname, 'talkless');

// installs the per-number fs remap BEFORE the Talkless modules are loaded
const sessionFs = require('./talkless/sessionFs');

let _handler = null;

function load() {
  if (!_handler) {
    _handler = require('./talkless/handler');
    console.log(`[TALKLESS] command pack mounted — ${_handler.getCommandCount()} commands`);
  }
  return _handler;
}

function pairedSession(sock) {
  return sessionFs.sessionFromSock(sock);
}

// ─── Auto status view / react ────────────────────────────────
const _DEFAULT_STATUS_EMOJIS = ['🥹','🤭','🥰','💖','🌄','✅','☝️','☺️','😭','🥲','😔','😩','🫠','🥺'];
// Pool that older versions saved to disk as the default. If the stored pool is exactly
// this, the owner never customised it, so the new default above is used instead.
const _LEGACY_DEFAULT_POOL = ['🔥','😍','💙','💚','💜','❤️','🥰','😎','😂','🤩','👏','🙌','✨','💯','🎉','😮','🤭','💖','😻','👌','🫶','🥳','💫','😁','🤝','🙏','🌟','😇','🤗','💪','😆','🤯','🧡','💛','🤍','🖤','🎊','👍','😋','🤤','🥹','😌','🌹','💐','👑','⚡','🌈','🍀','🎯','💎'];
const _statusHandled = new Set();
const _statusProcessing = new Set();

// Shuffle the full pool and use each emoji once before reshuffling. This gives
// statuses varied reactions without repeats until the configured pool cycles.
const _emojiCycles = new Map();
function pickStatusEmoji(st, sock) {
  // The persisted setting is authoritative; do not rely on a separate marker
  // file that may be absent or stored in a different per-number data folder.
  if (!st.randomEmoji) return st.emoji || '💙';
  const configuredPool = Array.isArray(st.emojiPool)
    ? st.emojiPool.filter(e => typeof e === 'string' && e.trim())
    : [];
  const isLegacy = configuredPool.length === _LEGACY_DEFAULT_POOL.length &&
    configuredPool.every((e, idx) => e === _LEGACY_DEFAULT_POOL[idx]);
  const pool = [...new Set(configuredPool.length && !isLegacy ? configuredPool : _DEFAULT_STATUS_EMOJIS)];
  const key = String(sock?.user?.id || '').split(':')[0];
  const signature = pool.join('|');
  let cycle = _emojiCycles.get(key);
  if (!cycle || cycle.signature !== signature) cycle = { signature, bag: [], last: null };
  if (!cycle.bag.length) {
    cycle.bag = pool.slice();
    for (let i = cycle.bag.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cycle.bag[i], cycle.bag[j]] = [cycle.bag[j], cycle.bag[i]];
    }
    if (cycle.bag.length > 1 && cycle.bag[0] === cycle.last) {
      [cycle.bag[0], cycle.bag[1]] = [cycle.bag[1], cycle.bag[0]];
    }
  }
  const pick = cycle.bag.shift() || '💙';
  cycle.last = pick;
  _emojiCycles.set(key, cycle);
  return pick;
}

async function handleStatusCore(sock, msg) {
  const session = pairedSession(sock);
  if (!session) return;
  const key = msg?.key;
  const message = msg?.message?.ephemeralMessage?.message || msg?.message;
  if (!key || key.remoteJid !== 'status@broadcast' || key.fromMe || !message) return;
  if (message.protocolMessage || message.reactionMessage) return;
  const normalizeRecipient = value => {
    if (typeof value !== 'string' || !value.includes('@')) return null;
    const [user, server] = value.split('@');
    if (!user || !server) return null;
    // A participantAlt is usually the phone-number JID for an LID contact.
    // Strip device suffixes because statusJidList addresses contacts, not devices.
    return server === 's.whatsapp.net'
      ? `${user.split(':')[0]}@s.whatsapp.net`
      : `${user}@${server}`;
  };
  const participantJids = [...new Set([
    key.participantAlt,
    msg.participantAlt,
    key.participant,
    msg.participant
  ].map(normalizeRecipient).filter(Boolean))];
  if (!participantJids.length) {
    console.warn('[STATUS] skipped status without a participant JID:', key.id || '(no message id)');
    return;
  }

  const dedupe = session + '|' + (key.id || '') + '|' + participantJids[0];
  if (_statusHandled.has(dedupe) || _statusProcessing.has(dedupe)) return;
  _statusProcessing.add(dedupe);

  try {
    const db = require('./talkless/database');
    const st = db.loadSettings();
    if (!st.enabled && !st.react) return;

    // Small delay so many sessions do not react at exactly the same time.
    await new Promise(r => setTimeout(r, 800 + Math.floor(Math.random() * 1700)));
    // Re-read after the delay so an owner's OFF command takes effect immediately.
    const currentSettings = db.loadSettings();
    if (!currentSettings.enabled && !currentSettings.react) {
      _statusHandled.add(dedupe);
      return;
    }

    if (currentSettings.enabled) {
      try { await sock.readMessages([key]); }
      catch (e) { console.error('[STATUS] view failed:', e.message); }
    }

    if (currentSettings.react) {
      const emoji = pickStatusEmoji(currentSettings, sock);
      const me = normalizeRecipient(sock.user?.id || sock.user?.lid);
      const reaction = { react: { text: emoji, key } };
      const recipientAttempts = [];
      const addAttempt = list => {
        const clean = [...new Set(list.filter(v => typeof v === 'string' && v.includes('@')))];
        const signature = clean.join('|');
        if (clean.length && !recipientAttempts.some(a => a.join('|') === signature)) recipientAttempts.push(clean);
      };
      // 1) The form WhatsApp itself used for the status author (raw participant) + own JIDs.
      //    This is the combination that reliably delivers a status reaction.
      const rawAuthors = [key.participant, msg.participant, key.participantAlt, msg.participantAlt];
      const myIds = [sock.user?.id, sock.user?.lid, me];
      addAttempt([rawAuthors[0] || rawAuthors[1], ...myIds]);
      // 2) Author in every address form we know (LID + phone-number JID) + own JIDs.
      addAttempt([...rawAuthors, ...myIds]);
      // 3) Normalised fallbacks.
      for (const author of participantJids) {
        addAttempt([author, me]);
        addAttempt([author]);
      }
      let sent = false;
      let lastError;
      for (const statusJidList of recipientAttempts) {
        try {
          await sock.sendMessage(key.remoteJid, reaction, { statusJidList });
          sent = true;
          break;
        } catch (error) {
          lastError = error;
        }
      }
      if (!sent) {                                   // last resort: let the library work out the audience itself
        try { await sock.sendMessage(key.remoteJid, reaction); sent = true; }
        catch (error) { lastError = error; }
      }
      if (sent) console.log(`[STATUS] ${emoji} liked status ${key.id || ''} from +${(participantJids[0] || '').split('@')[0]}`);
      if (!sent) {
        console.error('[STATUS] react failed for status', key.id || '(no id)', lastError?.message || 'unknown send error');
        throw lastError || new Error('status react send failed'); // wrapper retries once
      }
    }

    _statusHandled.add(dedupe);
    if (_statusHandled.size > 2000) _statusHandled.delete(_statusHandled.values().next().value);
  } finally {
    _statusProcessing.delete(dedupe);
  }
}


// ── Paced per-session queue ──────────────────────────────────
// WhatsApp delivers every active status in a burst on (re)connect. Reacting to
// all of them at once is the fastest way to get flagged, so statuses are handled
// one at a time with a random human-like gap, and a failed send is retried once.
const _statusQueues = new Map();
function handleStatusImpl(sock, msg) {
  const qkey = pairedSession(sock);
  if (!qkey) return Promise.resolve();
  const prev = _statusQueues.get(qkey) || Promise.resolve();
  const next = prev.catch(() => {}).then(async () => {
    try { await handleStatusCore(sock, msg); }
    catch (e) {
      console.warn('[STATUS] first attempt failed, retrying:', e && e.message);
      await new Promise(r => setTimeout(r, 4000));
      await handleStatusCore(sock, msg);
    }
    await new Promise(r => setTimeout(r, 1500 + Math.floor(Math.random() * 3500)));
  });
  _statusQueues.set(qkey, next);
  next.finally(() => { if (_statusQueues.get(qkey) === next) _statusQueues.delete(qkey); }).catch(() => {});
  return next;
}

module.exports = {
  async handle(sock, msg) {
    const session = pairedSession(sock);
    if (!session) return;
    return sessionFs.runWithSession(session, async () => {
      try {
        return await load().handleMessage(sock, msg);
      } catch (e) {
        console.error('[TALKLESS] handler error:', e && e.message);
      }
    });
  },
  // Auto view / auto react for WhatsApp statuses (status@broadcast).
  initializeStatusSettings(sock) {
    const session = pairedSession(sock);
    if (!session) throw new Error('Cannot initialize status settings without a paired identity');
    return sessionFs.runWithSession(session, () => require('./talkless/database').loadSettings());
  },
  handleStatus(sock, msg) {
    const session = pairedSession(sock);
    if (!session) return Promise.resolve();
    return sessionFs.runWithSession(session, async () => {
      try { return await handleStatusImpl(sock, msg); } catch (e) {
        console.error('[STATUS] auto view/react error:', e && e.message);
      }
    });
  },
  // Cache every incoming message the moment it arrives (antidelete / antiedit need the original).
  store(sock, msg) {
    const session = pairedSession(sock);
    if (!session) return;
    sessionFs.runWithSession(session, () => {
      try { load().storeForAnti(sock, msg); } catch (_) {}
    });
  },
  // Deleted messages: from messages.update (stub REVOKE) ...
  handleMessagesUpdate(sock, updates) {
    const session = pairedSession(sock);
    if (!session) return Promise.resolve();
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleMessagesUpdate(sock, updates); } catch (e) {
        console.error('[TALKLESS] messages.update error:', e && e.message);
      }
    });
  },
  // ... and from protocolMessage REVOKE notices in messages.upsert.
  handleRevoke(sock, items) {
    const session = pairedSession(sock);
    if (!session) return Promise.resolve();
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleRevokes(sock, items); } catch (e) {
        console.error('[TALKLESS] revoke error:', e && e.message);
      }
    });
  },
  // Edited messages arriving as protocolMessage (type 14) in messages.upsert.
  handleEdit(sock, items) {
    const session = pairedSession(sock);
    if (!session) return Promise.resolve();
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleEdits(sock, items); } catch (e) {
        console.error('[TALKLESS] edit error:', e && e.message);
      }
    });
  },
  handleGroupUpdate(sock, update) {
    const session = pairedSession(sock);
    if (!session) return Promise.resolve();
    return sessionFs.runWithSession(session, async () => {
      try { return await load().handleGroupUpdate(sock, update); } catch (e) {
        console.error('[TALKLESS] group update error:', e && e.message);
      }
    });
  },
  initAntiCall(sock) {
    try { return load().initializeAntiCall(sock); } catch (e) {
      console.error('[TALKLESS] anticall error:', e && e.message);
    }
  },
  get count() {
    try { return load().getCommandCount(); } catch { return 0; }
  },
  preload() { load(); },
};
