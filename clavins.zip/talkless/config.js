const config = {
  ownerNumber: ['254781447360'],
  ownerName: ['TALKLESS XMD'],
  botName: 'TALKLESS XMD',
  poweredBy: 'TALKLESS TECH',
  menuImageUrl: 'https://i.ibb.co/JRBYd54Y/ffe9da187a54.jpg',
  prefix: '.',
  version: '2.9.0',
  sessionName: '',
  sessionID: process.env.SESSION_ID || '',
  newsletterJid: '120363426406372312@newsletter',
  // Add your own services here (or set them as environment variables).
  PAIR_API_URL: process.env.PAIR_API_URL || '',          // pairing-code service, e.g. https://your-pair.example.com
  TALKLESS_API_URL: process.env.TALKLESS_API_URL || '',  // chatbot API base URL
  TALKLESS_BOT_ID: process.env.TALKLESS_BOT_ID || '',    // chatbot API bot id
  TALKLESS_API_KEY: process.env.TALKLESS_API_KEY || '',  // chatbot API key
  updateZipUrl: '',
  packname: '',
  telegramToken: process.env.TELEGRAM_TOKEN || '',
  selfMode: false,
  autoRead: false,
  autoTyping: false,
  autoBio: false,
  autoSticker: false,
  autoReact: false,
  autoReactMode: 'bot',
  autoDownload: false,
  autoRecording: false,
  autoRecordType: false,
  defaultGroupSettings: {
    antilink: false,
    antilinkAction: 'delete',
    antitag: false,
    antitagAction: 'delete',
    antiall: false,
    antiviewonce: false,
    antibot: false,
    anticall: false,
    anticallAction: 'decline',
    antigroupmention: false,
    antigroupmentionAction: 'delete',
    antigroupstatus: false,
    antigroupstatusAction: 'delete',
    welcome: false,
    welcomeMessage: ' 𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @user 👋\n Member count: #memberCount\n 𝚃𝙸𝙼𝙴: time⏰\n\n\n*@user* Welcome to *@group*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\ngroupDesc\n\n> TALKLESS TECH',
    welcomeNoPP: false,
    goodbye: false,
    goodbyeMessage: 'Goodbye @user 👋 We will never miss you!',
    antiSpam: false,
    antiSpamLimit: 5,
    antiSpamWindow: 5,
    antiSpamAction: 'delete',
    antidelete: false,
    nsfw: false,
    detect: false,
    chatbot: false,
    autosticker: false,
    antiimage: false,
    antiimageAction: 'delete',
    antisticker: false,
    antistickerAction: 'delete',
    antiaudio: false,
    antiaudioAction: 'delete',
    antibadword: false,
    antibadwordAction: 'warn',
    badwords: [],
    anticontact: false,
    anticontactAction: 'delete',
    antigif: false,
    antigifAction: 'delete'
  },
  apiKeys: {
    openai: '',
    deepai: '',
    remove_bg: ''
  },
  messages: {
    wait: '⏳ Please wait...',
    success: '✅ Success!',
    error: '❌ Error occurred!',
    ownerOnly: '👑 This command is only for bot owner!',
    adminOnly: '🛡️ This command is only for group admins!',
    groupOnly: '👥 This command can only be used in groups!',
    privateOnly: '💬 This command can only be used in private chat!',
    botAdminNeeded: '🚫 Bot needs to be admin to execute this command!',
    invalidCommand: '❓ Invalid command! Type .menu for help'
  },
  timezone: 'Africa/Nairobi',
  maxWarnings: 3,
  social: {
    instagram: 'https://instagram.com/activator_negative'
  }
};

// Keep the original values as immutable fallbacks. Database access is lazy so
// database.js can continue importing this module without creating a hard cycle.
const sessionConfigFallbacks = Object.freeze({
  ownerNumber: Object.freeze(config.ownerNumber.slice()),
  ownerName: Object.freeze(config.ownerName.slice()),
  prefix: config.prefix,
  botName: config.botName
});
const resolvingSessionConfig = new Set();

function getSessionConfigValue(key) {
  const session = require('./utils/sessionCtx').current();
  const fallback = key === 'ownerNumber' && session && /^\d+$/.test(session)
    ? [session]
    : sessionConfigFallbacks[key];
  if (!session) {
    return Array.isArray(fallback) ? fallback.slice() : fallback;
  }
  if (resolvingSessionConfig.has(key)) {
    return Array.isArray(fallback) ? fallback.slice() : fallback;
  }

  resolvingSessionConfig.add(key);
  try {
    let database;
    try {
      // During database.js initialization this can return its partial exports.
      database = require('./database');
    } catch (_) {
      return Array.isArray(fallback) ? fallback.slice() : fallback;
    }
    // Check the module record before inspecting exports; Node warns when a
    // missing export is read from a module that is still in a circular load.
    let databaseModule;
    try {
      databaseModule = require.cache[require.resolve('./database')];
    } catch (_) {
      return Array.isArray(fallback) ? fallback.slice() : fallback;
    }
    if (databaseModule && !databaseModule.loaded) {
      return Array.isArray(fallback) ? fallback.slice() : fallback;
    }
    if (!database || typeof database.getBotSetting !== 'function') {
      return Array.isArray(fallback) ? fallback.slice() : fallback;
    }

    let value;
    try {
      value = database.getBotSetting(key);
    } catch (_) {
      return Array.isArray(fallback) ? fallback.slice() : fallback;
    }
    if (value === undefined || value === null) {
      return Array.isArray(fallback) ? fallback.slice() : fallback;
    }
    if (key === 'ownerName' || key === 'ownerNumber') {
      return Array.isArray(value) ? value.slice() : [value];
    }
    // Do not use truthiness here: an empty prefix is an intentional setting.
    return value;
  } finally {
    resolvingSessionConfig.delete(key);
  }
}

for (const key of ['ownerNumber', 'ownerName', 'prefix', 'botName']) {
  Object.defineProperty(config, key, {
    enumerable: true,
    configurable: true,
    get() {
      return getSessionConfigValue(key);
    },
    // Some legacy call sites assign a just-resolved local value back to config.
    // Keep the original global fallback immutable; persisted settings are read
    // from the session-scoped database instead.
    set(_value) {}
  });
}

module.exports = config;
