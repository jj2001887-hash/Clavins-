# Per-number data isolation (TALKLESS pack)

Every paired WhatsApp session writes its own data. Nothing is shared between numbers.

## Layout

```
talkless/
├── database/                 ← seed templates (empty defaults, never written at runtime)
│   ├── groups.json  users.json  warnings.json  mods.json  muted.json
│   ├── botmode.json  bot-settings.json  session.json  groupStats.json
│   └── numbers/
│       └── 2541XXXXXXXX/     ← one folder per paired number, created on first use
└── data/
    ├── antibot.json  fontSettings.json  menuSettings.json
    └── numbers/
        └── 2541XXXXXXXX/
```

## How it works

- `talkless/utils/sessionCtx.js` — AsyncLocalStorage scope. The session id is the
  paired number taken from `sock.user.id`.
- `talkless/sessionFs.js` — remaps `fs` / `fs.promises` for paths inside
  `talkless/database/` and `talkless/data/` to the active number's folder. Two-path
  calls (`renameSync`, `copyFileSync`, `linkSync`, `symlinkSync`) get both
  arguments remapped, so atomic `write tmp → rename` stays inside the folder.
  First touch of a file copies the seed template from the parent folder.
- `talkless/database.js` — its parsed-JSON cache (`v13`) is replaced with
  `ScopedCache`, which prefixes cache keys with the session id. Without this the
  cache would hand one number's data to another.
- `talkless/utils/groupstats.js` — one cache slot per session, and the 5s flush runs
  each slot inside its own session context.

## Deliberately still shared

- `talkless/temp/` — transient render files, cleaned up by `utils/cleanup.js`.
- `handler.js` group metadata cache — keyed by group JID, identical for every
  number, 5 minute TTL.
- `talkless/config.js` — static constants (API keys, owner list, defaults). Prefix
  and owner numbers are not per-number yet; wire them to the host bot's
  `setWaSetting(number, 'prefix', ...)` store if you need that.
