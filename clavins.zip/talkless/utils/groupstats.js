// utils/groupStats.js
// In-memory store with async flush — no sync disk I/O on every message.
// Per-number: one cache slot per paired session, flushed inside that session's
// context so it lands in database/numbers/<number>/groupStats.json.
const fs = require('fs');
const path = require('path');
const { current, run } = require('./sessionCtx');

const DB_PATH = path.join(__dirname, '../database/groupStats.json');

// ── In-memory store, one slot per session number ──────────────────────────────
const _slots = new Map(); // sessionId -> { data, dirty }

function _slot() {
  const key = current() || 'default';
  let slot = _slots.get(key);
  if (!slot) {
    slot = { data: null, dirty: false };
    _slots.set(key, slot);
  }
  return slot;
}

function _load(slot) {
  if (slot.data !== null) return;
  try {
    if (!fs.existsSync(DB_PATH)) {
      slot.data = {};
      return;
    }
    const raw = fs.readFileSync(DB_PATH, 'utf8').trim();
    slot.data = raw ? JSON.parse(raw) : {};
  } catch {
    slot.data = {};
  }
}

function _flush(slot) {
  if (!slot.dirty || !slot.data) return;
  slot.dirty = false;
  const json = JSON.stringify(slot.data);
  const tmp = DB_PATH + '.tmp';
  try {
    fs.writeFileSync(tmp, json);
    fs.renameSync(tmp, DB_PATH);
  } catch (err) {
    console.error('[groupStats] flush error:', err.message);
  }
}

function _flushAll() {
  for (const [sessionId, slot] of _slots) {
    run(sessionId, () => _flush(slot));
  }
}

// Flush every 5 seconds — only writes if something actually changed
setInterval(_flushAll, 5000).unref();

// Also flush on process exit so no data is lost on clean shutdown
process.on('exit', _flushAll);

// ── Public API ────────────────────────────────────────────────────────────────

function addMessage(groupId, senderId) {
  const slot = _slot();
  _load(slot);
  const today = new Date().toISOString().slice(0, 10);
  const hour = new Date().getHours().toString();
  if (!slot.data[groupId]) slot.data[groupId] = {};
  if (!slot.data[groupId][today]) {
    slot.data[groupId][today] = {
      total: 0,
      users: {},
      hours: {}
    };
  }
  const g = slot.data[groupId][today];
  g.total++;
  g.users[senderId] = (g.users[senderId] || 0) + 1;
  g.hours[hour] = (g.hours[hour] || 0) + 1;
  slot.dirty = true;
}

function getStats(groupId) {
  const slot = _slot();
  _load(slot);
  const today = new Date().toISOString().slice(0, 10);
  if (!slot.data[groupId] || !slot.data[groupId][today]) return null;
  return slot.data[groupId][today];
}

function getActiveUsers(groupId, limit = 15) {
  const slot = _slot();
  _load(slot);
  if (!slot.data[groupId]) return [];
  const totals = {};
  for (const day of Object.values(slot.data[groupId])) {
    for (const [jid, count] of Object.entries(day.users || {})) {
      totals[jid] = (totals[jid] || 0) + count;
    }
  }
  return Object.entries(totals).map(([jid, count]) => ({
    jid,
    count
  })).sort((a, b) => b.count - a.count).slice(0, limit);
}

function normalizeJid(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return '';
  if (raw.includes('@')) return raw.replace(/:\d+(?=@)/, '');
  const digits = raw.replace(/\D/g, '');
  return digits ? `${digits}@s.whatsapp.net` : '';
}

function participantJids(participant) {
  if (typeof participant === 'string') return [normalizeJid(participant)].filter(Boolean);
  if (!participant || typeof participant !== 'object') return [];
  return [participant.id, participant.jid, participant.lid, participant.phoneNumber, participant.pn]
    .map(normalizeJid).filter(Boolean);
}

function getInactiveUsers(groupId, allParticipants) {
  const slot = _slot();
  _load(slot);
  const active = new Set();
  if (slot.data[groupId]) {
    for (const day of Object.values(slot.data[groupId])) {
      for (const jid of Object.keys(day.users || {})) {
        const normalized = normalizeJid(jid);
        if (normalized) active.add(normalized);
      }
    }
  }
  return (Array.isArray(allParticipants) ? allParticipants : []).filter(participant =>
    !participantJids(participant).some(jid => active.has(jid))
  );
}

module.exports = {
  addMessage,
  getStats,
  getActiveUsers,
  getInactiveUsers
};
