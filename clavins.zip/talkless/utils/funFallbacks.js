'use strict';

// Small, self-contained fallback content for fun commands. These are used only
// when an external provider fails or returns an invalid response.
const data = {
  jokes: [
    { setup: 'Why did the bicycle fall over?', punchline: 'Because it was two-tired.' },
    { setup: 'Why did the scarecrow win an award?', punchline: 'Because he was outstanding in his field.' },
    { setup: 'What do you call a bear with no teeth?', punchline: 'A gummy bear.' },
    { setup: 'Why did the computer go to the doctor?', punchline: 'It had a virus.' },
    { setup: 'What kind of music do planets like?', punchline: 'Neptunes.' },
    { setup: 'Why was the math book sad?', punchline: 'It had too many problems.' },
    { setup: 'What do you call cheese that is not yours?', punchline: 'Nacho cheese.' },
    { setup: 'Why did the cookie go to the hospital?', punchline: 'It felt crummy.' }
  ],
  facts: [
    'An octopus has three hearts.',
    'Venus rotates in the opposite direction to most planets in our solar system.',
    'A day on Venus is longer than its year.',
    'Blue whales are the largest animals known to have lived on Earth.',
    'Wombats produce cube-shaped droppings.',
    'Water expands as it freezes into ice.',
    'The Moon is slowly moving away from Earth by a few centimetres each year.',
    'Strawberries are not botanical berries, while bananas are.',
    'The Pacific Ocean is the largest ocean on Earth.',
    'Adult humans typically have 206 bones, though the exact count can vary.'
  ],
  quotes: [
    { content: 'Well done is better than well said.', author: 'Benjamin Franklin' },
    { content: 'No act of kindness, no matter how small, is ever wasted.', author: 'Aesop' },
    { content: 'The secret of getting ahead is getting started.', author: 'Mark Twain' },
    { content: 'The only thing we have to fear is fear itself.', author: 'Franklin D. Roosevelt' },
    { content: 'It always seems impossible until it is done.', author: 'Nelson Mandela' },
    { content: 'Happiness depends upon ourselves.', author: 'Aristotle' }
  ],
  pickupLines: [
    'Are you a keyboard? Because you are just my type.',
    'Do you have a map? I keep getting lost in your smile.',
    'Are you a camera? Every time I see you, I smile.',
    'If kindness were a superpower, you would be unstoppable.',
    'You must be a good song, because you have been stuck in my head.'
  ],
  flirts: [
    'You make ordinary moments feel a little more special.',
    'I was having a good day, and then your smile made it better.',
    'You have a way of making people feel seen. It is lovely.',
    'If good company were a talent, you would be a natural.',
    'Your smile deserves its own fan club.'
  ],
  truths: [
    'What is one small thing that always makes you happy?',
    'What is a skill you would love to learn?',
    'What is the kindest thing someone has done for you?',
    'What song can you listen to on repeat?',
    'What is one goal you are proud of working toward?',
    'Which place would you most like to visit?',
    'What is a funny memory you enjoy sharing?',
    'What is one thing you appreciate about your friends?'
  ],
  wouldYouRather: [
    { a: 'Always arrive 10 minutes early', b: 'Always arrive 10 minutes late' },
    { a: 'Explore the ocean', b: 'Explore outer space' },
    { a: 'Be able to speak every language', b: 'Be able to play every instrument' },
    { a: 'Have a library in your home', b: 'Have a cinema in your home' },
    { a: 'Travel to the past for one day', b: 'Travel to the future for one day' },
    { a: 'Have a personal chef', b: 'Have a personal driver' }
  ],
  paranoia: [
    'Who in the group would be the best at keeping a surprise?',
    'Who in the group would most likely start a new hobby this week?',
    'Who in the group gives the best advice?',
    'Who in the group would plan the most fun day out?',
    'Who in the group is most likely to make everyone laugh?',
    'Who in the group would be calmest during a sudden change of plans?'
  ],
  trivia: [
    { category: 'Science & Nature', difficulty: 'easy', question: 'Which planet is known as the Red Planet?', correct: 'Mars', incorrect: ['Venus', 'Jupiter', 'Mercury'] },
    { category: 'Geography', difficulty: 'easy', question: 'What is the largest ocean on Earth?', correct: 'Pacific Ocean', incorrect: ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean'] },
    { category: 'Science & Nature', difficulty: 'easy', question: 'What is the chemical symbol for water?', correct: 'H₂O', incorrect: ['CO₂', 'O₂', 'NaCl'] },
    { category: 'General Knowledge', difficulty: 'easy', question: 'How many sides does a hexagon have?', correct: 'Six', incorrect: ['Five', 'Seven', 'Eight'] },
    { category: 'Geography', difficulty: 'easy', question: 'Which continent contains the Sahara Desert?', correct: 'Africa', incorrect: ['Asia', 'South America', 'Europe'] }
  ]
};

const pick = items => items[Math.floor(Math.random() * items.length)];
module.exports = {
  joke: () => ({ ...pick(data.jokes) }),
  fact: () => pick(data.facts),
  quote: () => ({ ...pick(data.quotes) }),
  pickupLine: () => pick(data.pickupLines),
  flirt: () => pick(data.flirts),
  truth: () => pick(data.truths),
  wouldYouRather: () => ({ ...pick(data.wouldYouRather) }),
  paranoia: () => pick(data.paranoia),
  trivia: () => {
    const item = pick(data.trivia);
    return { ...item, incorrect: [...item.incorrect] };
  }
};
