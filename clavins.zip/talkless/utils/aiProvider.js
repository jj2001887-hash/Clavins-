'use strict';

const axios = require('axios');
const FormData = require('form-data');
const dns = require('dns').promises;
const net = require('net');

const BASE_URL = 'https://api.openai.com/v1';
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const MAX_AUDIO_BYTES = 25 * 1024 * 1024;

function apiKey() {
  const key = String(process.env.OPENAI_API_KEY || '').trim();
  if (!key) throw new Error('OpenAI API key is not configured. Set OPENAI_API_KEY in Pterodactyl → Startup → Variables, then restart the bot.');
  return key;
}

function model(name, fallback) {
  return String(process.env[name] || fallback).trim();
}

function headers(extra = {}) {
  return { Authorization: `Bearer ${apiKey()}`, ...extra };
}

function getApiError(error) {
  const status = error?.response?.status;
  const detail = error?.response?.data?.error?.message || error?.response?.data?.message || error?.message || 'Unknown OpenAI API error';
  if (status === 401) return 'OpenAI rejected OPENAI_API_KEY. Check the key in Pterodactyl Startup variables.';
  if (status === 403) return `OpenAI denied this request: ${detail}`;
  if (status === 404) return `OpenAI endpoint or model was not found. Check the configured AI model name. ${detail}`;
  if (status === 429) return `OpenAI rate limit or account quota reached. Check your OpenAI billing and limits. ${detail}`;
  return `OpenAI API error${status ? ` (HTTP ${status})` : ''}: ${detail}`;
}

async function postJson(endpoint, body, timeout = 90000) {
  try {
    const { data } = await axios.post(`${BASE_URL}${endpoint}`, body, {
      timeout,
      headers: headers({ 'Content-Type': 'application/json', Accept: 'application/json' })
    });
    if (!data || data.error) throw new Error(data?.error?.message || 'OpenAI returned an empty response.');
    return data;
  } catch (error) {
    throw new Error(getApiError(error));
  }
}

function responseText(data) {
  if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
  const text = [];
  const sources = [];
  for (const item of data?.output || []) {
    if (item?.type !== 'message') continue;
    for (const content of item.content || []) {
      if (content?.type === 'output_text' && content.text) {
        text.push(content.text);
        for (const annotation of content.annotations || []) {
          const citation = annotation?.type === 'url_citation' ? annotation : annotation?.url_citation;
          if (citation?.url) sources.push({ title: citation.title || citation.url, url: citation.url });
        }
      }
    }
  }
  const answer = text.join('\n').trim();
  if (!answer) throw new Error('OpenAI returned an empty text response. Try again or check the selected model.');
  const unique = [...new Map(sources.map(s => [s.url, s])).values()];
  return answer + (unique.length ? `\n\nSources:\n${unique.slice(0, 8).map(s => `• ${s.title}: ${s.url}`).join('\n')}` : '');
}

async function answer(prompt, options = {}) {
  const text = String(prompt || '').trim();
  if (!text) throw new Error('Please enter a prompt.');
  if (text.length > 30000) throw new Error('AI input is limited to 30,000 characters per request.');
  const chosenModel = options.model || model(options.webSearch ? 'AI_SEARCH_MODEL' : options.image ? 'AI_VISION_MODEL' : 'AI_MODEL', 'gpt-6-luna');
  const body = {
    model: chosenModel,
    instructions: options.instructions || 'You are the TALKLESS TECH XMD assistant. Answer accurately, clearly, and helpfully. If unsure, say so. Keep answers suitable for a WhatsApp chat.',
    max_output_tokens: Math.max(256, Math.min(6000, parseInt(process.env.AI_MAX_OUTPUT_TOKENS, 10) || 1800)),
    input: options.image ? [{
      role: 'user',
      content: [
        { type: 'input_text', text },
        { type: 'input_image', image_url: `data:${options.image.mime || 'image/jpeg'};base64,${Buffer.from(options.image.buffer).toString('base64')}` }
      ]
    }] : text
  };
  if (options.webSearch) {
    body.tools = [{ type: 'web_search' }];
    body.include = ['web_search_call.action.sources'];
  }
  if (options.reasoning !== false && /^(gpt-6|o[1-9])/i.test(chosenModel)) body.reasoning = { effort: 'low' };
  const data = await postJson('/responses', body, options.webSearch ? 120000 : 90000);
  return { text: responseText(data), raw: data };
}

function imageMime(buffer, hinted = '') {
  const b = Buffer.from(buffer || []);
  const hint = String(hinted || '').split(';')[0].trim().toLowerCase();
  if (hint.startsWith('image/')) return hint;
  if (b.length >= 8 && b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return 'image/png';
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b.length >= 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  if (b.length >= 6 && /^GIF8[79]a$/.test(b.toString('ascii', 0, 6))) return 'image/gif';
  throw new Error('The downloaded file is not a supported image. Use PNG, JPEG, or WebP.');
}

function isPrivateAddress(address) {
  const ip = String(address || '').toLowerCase();
  const family = net.isIP(ip);
  if (family === 4) {
    const p = ip.split('.').map(Number);
    return p[0] === 0 || p[0] === 10 || p[0] === 127 ||
      (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
      (p[0] === 169 && p[1] === 254) ||
      (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 192 && (p[1] === 168 || p[1] === 0)) ||
      (p[0] === 198 && (p[1] === 18 || p[1] === 19 || p[1] === 51)) ||
      (p[0] === 203 && p[1] === 0 && p[2] === 113) || p[0] >= 224;
  }
  if (family === 6) {
    return ip === '::' || ip === '::1' || ip.startsWith('::ffff:') ||
      /^f[cd]/i.test(ip) || /^fe[89ab]/i.test(ip) || /^ff/i.test(ip);
  }
  return true;
}

async function assertPublicHttps(url) {
  let parsed;
  try { parsed = new URL(url); } catch (_) { throw new Error('Provide a valid public HTTPS media URL.'); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new Error('Media URLs must use public HTTPS links.');
  const host = parsed.hostname.toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) throw new Error('Private or local media URLs are not allowed.');
  let addresses;
  if (net.isIP(host)) addresses = [{ address: host }];
  else {
    try { addresses = await dns.lookup(host, { all: true, verbatim: true }); }
    catch (_) { throw new Error('Could not resolve the public media URL.'); }
  }
  if (!addresses.length || addresses.some(a => isPrivateAddress(a.address))) throw new Error('Private or local media URLs are not allowed.');
  return parsed.toString();
}

async function downloadMediaUrl(url, kind = 'image') {
  const limit = kind === 'audio' ? MAX_AUDIO_BYTES : MAX_IMAGE_BYTES;
  let current = String(url || '').trim();
  for (let redirects = 0; redirects <= 4; redirects++) {
    current = await assertPublicHttps(current);
    let response;
    try {
      response = await axios.get(current, {
        responseType: 'arraybuffer', timeout: 30000, maxContentLength: limit, maxBodyLength: limit,
        maxRedirects: 0, validateStatus: status => status >= 200 && status < 400,
        headers: { Accept: kind === 'audio' ? 'audio/*,application/octet-stream' : 'image/*', 'User-Agent': 'TALKLESS-TECH-XMD/2.0' }
      });
    } catch (error) {
      throw new Error(error?.response ? `Media download failed (HTTP ${error.response.status}).` : `Media download failed: ${error.message}`);
    }
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers?.location;
      if (!location || redirects === 4) throw new Error('The media URL redirected too many times.');
      current = new URL(location, current).toString();
      continue;
    }
    const buffer = Buffer.from(response.data || []);
    if (!buffer.length || buffer.length > limit) throw new Error(`Downloaded ${kind} file is empty or too large.`);
    let mime = String(response.headers?.['content-type'] || '').split(';')[0].toLowerCase();
    if (kind === 'image') mime = imageMime(buffer, mime);
    else if (!mime.startsWith('audio/')) {
      if (buffer.subarray(0, 4).toString('ascii') === 'OggS') mime = 'audio/ogg';
      else if (buffer.subarray(0, 3).toString('ascii') === 'ID3') mime = 'audio/mpeg';
      else if (buffer.subarray(0, 4).toString('ascii') === 'RIFF') mime = 'audio/wav';
      else if (buffer.length > 12 && buffer.toString('ascii', 4, 8) === 'ftyp') mime = 'audio/mp4';
      else throw new Error('The downloaded file is not a supported audio file.');
    }
    return { buffer, mime, url: current };
  }
  throw new Error('Could not download the media URL.');
}

function imageModel(edit = false) {
  return model(edit ? 'AI_IMAGE_EDIT_MODEL' : 'AI_IMAGE_MODEL', edit ? 'gpt-image-2.5-sunburst' : 'gpt-image-2.5-flare');
}

async function imageResult(data) {
  const entry = data?.data?.[0];
  if (entry?.b64_json) return Buffer.from(entry.b64_json, 'base64');
  if (entry?.url) return (await downloadMediaUrl(entry.url, 'image')).buffer;
  throw new Error('OpenAI returned no image. Check model access and image-generation limits.');
}

async function generateImage(prompt) {
  const text = String(prompt || '').trim();
  if (!text) throw new Error('Please enter an image prompt.');
  let data;
  try {
    data = await postJson('/images/generations', {
      model: imageModel(false), prompt: text, size: '1024x1024', quality: 'medium', output_format: 'png', n: 1
    }, 180000);
  } catch (error) { throw new Error(error.message); }
  return imageResult(data);
}

function fileExtension(mime) {
  if (mime === 'image/png') return 'png';
  if (mime === 'image/webp') return 'webp';
  if (mime === 'image/gif') return 'gif';
  return 'jpg';
}

async function editImage(buffer, mime, prompt, options = {}) {
  const image = Buffer.from(buffer || []);
  if (!image.length || image.length > MAX_IMAGE_BYTES) throw new Error('Image is empty or exceeds the 20 MB edit limit.');
  const contentType = imageMime(image, mime);
  const form = new FormData();
  form.append('model', imageModel(true));
  form.append('prompt', String(prompt || '').trim());
  form.append('size', '1024x1024');
  form.append('quality', 'medium');
  form.append('output_format', options.outputFormat || 'png');
  if (options.background) form.append('background', options.background);
  form.append('image', image, { filename: `input.${fileExtension(contentType)}`, contentType });
  let data;
  try {
    const response = await axios.post(`${BASE_URL}/images/edits`, form, {
      timeout: 180000, maxBodyLength: MAX_IMAGE_BYTES + 1024 * 1024,
      headers: headers(form.getHeaders())
    });
    data = response.data;
  } catch (error) { throw new Error(getApiError(error)); }
  return imageResult(data);
}

async function synthesizeSpeech(text) {
  const input = String(text || '').trim();
  if (!input) throw new Error('Please enter text to speak.');
  if (input.length > 4000) throw new Error('Text-to-speech input is limited to 4,000 characters.');
  const payload = {
    model: model('AI_TTS_MODEL', 'gpt-4o-mini-tts'),
    voice: model('AI_TTS_VOICE', 'nova'),
    input,
    instructions: 'Speak clearly and naturally. This is AI-generated speech.',
    response_format: 'mp3'
  };
  try {
    const response = await axios.post(`${BASE_URL}/audio/speech`, payload, {
      responseType: 'arraybuffer', timeout: 120000,
      headers: headers({ 'Content-Type': 'application/json', Accept: 'audio/mpeg' }),
      maxContentLength: MAX_AUDIO_BYTES
    });
    const buffer = Buffer.from(response.data || []);
    if (!buffer.length) throw new Error('OpenAI returned empty audio.');
    return buffer;
  } catch (error) { throw new Error(getApiError(error)); }
}

async function transcribeAudio(buffer, mime, filename = 'audio.ogg') {
  const audio = Buffer.from(buffer || []);
  if (!audio.length || audio.length > MAX_AUDIO_BYTES) throw new Error('Audio must be non-empty and no larger than 25 MB.');
  const form = new FormData();
  form.append('model', model('AI_TRANSCRIBE_MODEL', 'gpt-transcribe'));
  form.append('file', audio, { filename, contentType: mime || 'audio/ogg' });
  try {
    const response = await axios.post(`${BASE_URL}/audio/transcriptions`, form, {
      timeout: 180000, maxBodyLength: MAX_AUDIO_BYTES + 1024 * 1024,
      headers: headers(form.getHeaders())
    });
    const text = response.data?.text || (typeof response.data === 'string' ? response.data : '');
    if (!text.trim()) throw new Error('OpenAI returned an empty transcript.');
    return text.trim();
  } catch (error) { throw new Error(getApiError(error)); }
}

module.exports = {
  answer,
  generateImage,
  editImage,
  synthesizeSpeech,
  transcribeAudio,
  downloadMediaUrl,
  imageMime,
  getApiError,
  model
};
