/**
 * Native WhatsApp sticker packs (no Baileys fork needed)
 *
 * Official Baileys cannot send `stickerPackMessage`, so this module does it directly:
 *   1. zips the stickers (store-only) together with a tray icon,
 *   2. encrypts the zip as WhatsApp media type "sticker-pack"
 *      (HKDF info "WhatsApp Sticker Pack Keys", upload path /mms/sticker-pack),
 *   3. uploads the zip and a JPEG thumbnail (same mediaKey, "...Thumbnail Keys"),
 *   4. relays a StickerPackMessage, which WhatsApp shows as ONE pack card
 *      with an "Open / Add" button.
 *
 * It also decrypts received packs (used by .takepack) and keeps the per-user
 * collection used by .packadd / .packsend.
 *
 * There is NO silent fallback to single stickers: sendPack() only sends singles
 * when the caller explicitly asks (forceSingle).
 */
const crypto = require('crypto');
const zlib = require('zlib');

const PACK_LIMIT = 60;                          // stickers per WhatsApp pack
const delay = ms => new Promise(r => setTimeout(r, ms));

const INFO_PACK = 'WhatsApp Sticker Pack Keys';
const INFO_THUMB = 'WhatsApp Sticker Pack Thumbnail Keys';
const PATH_PACK = '/mms/sticker-pack';
const PATH_THUMB = '/mms/thumbnail-sticker-pack';

const sha256 = b => crypto.createHash('sha256').update(b).digest();

// ───────────────────────── zip (store-only) ─────────────────────────
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(buf) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(buf) >>> 0;
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function buildZip(entries) {
  const locals = [], centrals = [];
  let offset = 0;
  for (const { name, data } of entries) {
    const nameBuf = Buffer.from(name, 'utf8');
    const crc = crc32(data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(0, 8);
    lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12);               // 1980-01-01
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(data.length, 22);
    lh.writeUInt16LE(nameBuf.length, 26); lh.writeUInt16LE(0, 28);
    locals.push(lh, nameBuf, data);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(0, 10);
    ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(data.length, 24);
    ch.writeUInt16LE(nameBuf.length, 28); ch.writeUInt32LE(offset, 42);
    centrals.push(ch, nameBuf);
    offset += 30 + nameBuf.length + data.length;
  }
  const cd = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, end]);
}

// ───────────────────────── WhatsApp media crypto ─────────────────────────
const expandKey = (mediaKey, info) => Buffer.from(crypto.hkdfSync('sha256', mediaKey, Buffer.alloc(0), info, 112));

function encryptMedia(plain, mediaKey, info) {
  const k = expandKey(mediaKey, info);
  const iv = k.subarray(0, 16), cipherKey = k.subarray(16, 48), macKey = k.subarray(48, 80);
  const c = crypto.createCipheriv('aes-256-cbc', cipherKey, iv);
  const enc = Buffer.concat([c.update(plain), c.final()]);
  const mac = crypto.createHmac('sha256', macKey).update(iv).update(enc).digest().subarray(0, 10);
  const file = Buffer.concat([enc, mac]);
  return { file, fileSha256: sha256(plain), fileEncSha256: sha256(file), fileLength: plain.length };
}

function decryptMedia(file, mediaKey, info) {
  const k = expandKey(mediaKey, info);
  const iv = k.subarray(0, 16), cipherKey = k.subarray(16, 48), macKey = k.subarray(48, 80);
  const enc = file.subarray(0, file.length - 10), mac = file.subarray(file.length - 10);
  const expect = crypto.createHmac('sha256', macKey).update(iv).update(enc).digest().subarray(0, 10);
  if (!crypto.timingSafeEqual(mac, expect)) throw new Error('media MAC mismatch');
  const d = crypto.createDecipheriv('aes-256-cbc', cipherKey, iv);
  return Buffer.concat([d.update(enc), d.final()]);
}

const b64url = b => encodeURIComponent(Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''));

async function uploadEncrypted(sock, file, fileEncSha256, mediaPath) {
  const fetch = require('node-fetch');
  const token = b64url(fileEncSha256);
  if (typeof sock.refreshMediaConn !== 'function') throw new Error('this Baileys build exposes no media connection (refreshMediaConn)');
  let lastErr;
  for (const force of [false, true]) {
    const conn = await sock.refreshMediaConn(force);
    for (const host of conn.hosts || []) {
      try {
        const res = await fetch(`https://${host.hostname}${mediaPath}/${token}?auth=${encodeURIComponent(conn.auth)}&token=${token}`, {
          method: 'POST', body: file, timeout: 120000,
          headers: { 'Content-Type': 'application/octet-stream', Origin: 'https://web.whatsapp.com' }
        });
        const json = await res.json();
        if (json && json.direct_path) return { directPath: json.direct_path, url: json.url };
        lastErr = new Error(`upload rejected: ${JSON.stringify(json).slice(0, 120)}`);
      } catch (e) { lastErr = e; }
    }
  }
  throw lastErr || new Error('upload failed');
}

// ───────────────────────── building and sending ─────────────────────────
const isAnimatedWebp = b => b.length > 30 && b.includes(Buffer.from('ANIM'), 0);

async function makeTray(first) {
  try {
    const sharp = require('sharp');
    const tray = await sharp(first, { animated: false }).resize(96, 96, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp({ quality: 80 }).toBuffer();
    const thumb = await sharp(first, { animated: false }).resize(252, 252, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 1 } }).jpeg({ quality: 70 }).toBuffer();
    return { tray, thumb, thumbW: 252, thumbH: 252 };
  } catch (_) {
    return { tray: first, thumb: null };
  }
}

async function sendNativePack(sock, jid, { name, publisher, description = '', stickers, quoted }) {
  if (!stickers.length) throw new Error('no stickers to send');
  if (typeof sock.relayMessage !== 'function') throw new Error('relayMessage is not available');
  const packId = crypto.randomBytes(16).toString('hex').toUpperCase();

  const entries = [], metas = [];
  stickers.forEach((s, i) => {
    const fileName = `${String(i).padStart(2, '0')}_${encodeURIComponent(sha256(s.data).toString('base64'))}.webp`;
    entries.push({ name: fileName, data: s.data });
    metas.push({
      fileName, isAnimated: isAnimatedWebp(s.data), isLottie: false, mimetype: 'image/webp',
      emojis: s.emojis && s.emojis.length ? s.emojis : ['🙂'], accessibilityLabel: ''
    });
  });
  const { tray, thumb, thumbW, thumbH } = await makeTray(stickers[0].data);
  const trayIconFileName = `${packId}.webp`;
  entries.push({ name: trayIconFileName, data: tray });

  const zip = buildZip(entries);
  const mediaKey = crypto.randomBytes(32);
  const enc = encryptMedia(zip, mediaKey, INFO_PACK);
  const up = await uploadEncrypted(sock, enc.file, enc.fileEncSha256, PATH_PACK);

  const msg = {
    stickerPackId: packId, name, publisher: publisher || 'TALKLESS', packDescription: description,
    stickers: metas, trayIconFileName,
    fileLength: enc.fileLength, fileSha256: enc.fileSha256, fileEncSha256: enc.fileEncSha256,
    mediaKey, directPath: up.directPath, mediaKeyTimestamp: Math.floor(Date.now() / 1000),
    stickerPackSize: zip.length, stickerPackOrigin: 2        // 2 = USER_CREATED
  };

  if (thumb) {                                               // same mediaKey, thumbnail HKDF
    try {
      const te = encryptMedia(thumb, mediaKey, INFO_THUMB);
      const tu = await uploadEncrypted(sock, te.file, te.fileEncSha256, PATH_THUMB);
      Object.assign(msg, {
        thumbnailDirectPath: tu.directPath, thumbnailSha256: te.fileSha256, thumbnailEncSha256: te.fileEncSha256,
        thumbnailHeight: thumbH, thumbnailWidth: thumbW, imageDataHash: sha256(thumb).toString('base64')
      });
    } catch (e) { console.warn('[STICKERPACK] thumbnail upload skipped:', e && e.message); }
  }

  if (quoted?.key && quoted.message) {
    msg.contextInfo = { stanzaId: quoted.key.id, participant: quoted.key.participant || quoted.key.remoteJid, quotedMessage: quoted.message };
  }

  let genId;
  try { const B = require('@whiskeysockets/baileys'); genId = B.generateMessageIDV2 || B.generateMessageID; } catch (_) {}
  const messageId = genId ? genId(sock.user && sock.user.id) : undefined;
  await sock.relayMessage(jid, { stickerPackMessage: msg }, messageId ? { messageId } : {});
  return { packId, zipBytes: zip.length };
}

// Single stickers, ONLY when explicitly requested (.tgs <pack> single)
async function embedExif(webpBuffer, { packId, packName, publisher, emojis }) {
  const webp = require('node-webpmux');
  const img = new webp.Image();
  await img.load(webpBuffer);
  const json = {
    'sticker-pack-id': packId || crypto.randomBytes(16).toString('hex'),
    'sticker-pack-name': packName || '', 'sticker-pack-publisher': publisher || '',
    emojis: emojis && emojis.length ? emojis : ['🙂']
  };
  const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
  const jsonBuf = Buffer.from(JSON.stringify(json), 'utf8');
  const exif = Buffer.concat([exifAttr, jsonBuf]);
  exif.writeUIntLE(jsonBuf.length, 14, 4);
  img.exif = exif;
  return img.save(null);
}

/**
 * @param stickers [{ data: Buffer(webp), emojis?: string[] }]
 * @returns { mode, packs, sent, error? }   error is set (and sending stops) if a native pack fails
 */
async function sendPack(sock, jid, { name, publisher, description = '', stickers, quoted, forceSingle = false, onProgress }) {
  const chunks = [];
  for (let i = 0; i < stickers.length; i += PACK_LIMIT) chunks.push(stickers.slice(i, i + PACK_LIMIT));
  let sent = 0;

  for (let ci = 0; ci < chunks.length; ci++) {
    const part = chunks[ci];
    const label = chunks.length > 1 ? `${name} (${ci + 1}/${chunks.length})` : name;

    if (!forceSingle) {
      try {
        await sendNativePack(sock, jid, { name: label, publisher, description, stickers: part, quoted });
        sent += part.length;
        if (onProgress) await onProgress(sent, ci + 1, chunks.length);
        await delay(1200);
      } catch (e) {
        console.error('[STICKERPACK] native pack failed:', e && e.stack || e);
        return { mode: 'pack', packs: chunks.length, sent, error: (e && e.message) || String(e) };
      }
      continue;
    }

    const packId = crypto.randomBytes(16).toString('hex');
    for (const s of part) {
      try {
        const buf = await embedExif(s.data, { packId, packName: label, publisher, emojis: s.emojis });
        await sock.sendMessage(jid, { sticker: buf });
        sent++;
        await delay(450);
      } catch (e) { console.warn('[STICKERPACK] sticker send failed:', e && e.message); }
    }
    await delay(800);
  }
  return { mode: forceSingle ? 'single' : 'pack', packs: chunks.length, sent };
}

// ───────────────────────── receiving a pack (.takepack) ─────────────────────────
function parseZip(buf) {
  const files = new Map();
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0; i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('not a zip file');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
    const lho = buf.readUInt32LE(p + 42);
    const name = buf.subarray(p + 46, p + 46 + nlen).toString('utf8');
    const dataStart = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(dataStart, dataStart + csize);
    files.set(name, method === 8 ? zlib.inflateRawSync(raw) : Buffer.from(raw));
    p += 46 + nlen + elen + clen;
  }
  return files;
}

/** Download + decrypt a received stickerPackMessage → { name, stickers:[{data,emojis}] } */
async function readReceivedPack(pm) {
  const fetch = require('node-fetch');
  const url = pm.url || `https://mmg.whatsapp.net${pm.directPath}`;
  if (!pm.directPath && !pm.url) throw new Error('the pack has no download path');
  const res = await fetch(url, { timeout: 120000, headers: { Origin: 'https://web.whatsapp.com' } });
  if (!res.ok) throw new Error(`download failed (HTTP ${res.status})`);
  const zip = decryptMedia(await res.buffer(), Buffer.from(pm.mediaKey), INFO_PACK);
  const files = parseZip(zip);
  const stickers = [];
  for (const st of pm.stickers || []) {
    const data = files.get(st.fileName);
    if (data) stickers.push({ data, emojis: st.emojis && st.emojis.length ? st.emojis : ['🙂'] });
  }
  if (!stickers.length) for (const [n, d] of files) if (/\.webp$/i.test(n) && n !== pm.trayIconFileName) stickers.push({ data: d, emojis: ['🙂'] });
  return { name: pm.name, stickers };
}

// ───────────────────────── per-user collection ─────────────────────────
const collections = new Map();
const MAX_COLLECTION = 120;
const keyOf = (sock, sender) => `${String(sock?.user?.id || '').split(':')[0]}|${String(sender).split('@')[0].split(':')[0]}`;
function getCollection(sock, sender) {
  const k = keyOf(sock, sender);
  if (!collections.has(k)) collections.set(k, []);
  return collections.get(k);
}
function clearCollection(sock, sender) { collections.delete(keyOf(sock, sender)); }

module.exports = {
  sendPack, sendNativePack, embedExif, readReceivedPack, getCollection, clearCollection,
  PACK_LIMIT, MAX_COLLECTION, delay,
  _internal: { buildZip, parseZip, encryptMedia, decryptMedia, INFO_PACK, INFO_THUMB }
};
