'use strict';

const axios = require('axios');
const ANILIST_URL = 'https://graphql.anilist.co';
const JIKAN_BASE = 'https://api.jikan.moe/v4';
const PURRBOT_BASE = 'https://api.purrbot.site/v2';
const HTTP_TIMEOUT = 10000;
const APP_AGENT = 'TALKLESS-TECH-XMD/2.0';
const SAFE_IMAGE_PATHS = {
  neko: 'neko',
  waifu: 'holo',
  husbando: 'okami',
  kitsune: 'kitsune',
  megumin: 'holo'
};

const MEDIA_FIELDS = `id idMal siteUrl title { romaji english native } format status episodes duration averageScore seasonYear startDate { year } genres description coverImage { extraLarge large }`;

function cleanText(value) {
  return String(value || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&#039;/g, "'").replace(/&quot;/g, '"').trim();
}

function mapAniList(item) {
  if (!item) return null;
  const title = item.title?.english || item.title?.romaji || item.title?.native || 'Unknown anime';
  return {
    id: item.id,
    idMal: item.idMal || null,
    title,
    nativeTitle: item.title?.native || '',
    year: item.seasonYear || item.startDate?.year || '',
    format: item.format || '',
    episodes: item.episodes || null,
    duration: item.duration || null,
    status: item.status || '',
    score: item.averageScore ? (item.averageScore / 10).toFixed(1) : '',
    genres: Array.isArray(item.genres) ? item.genres : [],
    synopsis: cleanText(item.description),
    image: item.coverImage?.extraLarge || item.coverImage?.large || '',
    url: item.siteUrl || (item.id ? `https://anilist.co/anime/${item.id}` : '')
  };
}

function mapJikan(item) {
  if (!item) return null;
  const title = item.title_english || item.title || item.title_japanese || 'Unknown anime';
  return {
    id: item.mal_id || null,
    idMal: item.mal_id || null,
    title,
    nativeTitle: item.title_japanese || '',
    year: item.year || item.aired?.prop?.from?.year || '',
    format: item.type || '',
    episodes: item.episodes || null,
    duration: item.duration || '',
    status: item.status || '',
    score: item.score ? Number(item.score).toFixed(1) : '',
    genres: (item.genres || []).map(g => g.name).filter(Boolean),
    synopsis: item.synopsis || '',
    image: item.images?.jpg?.large_image_url || item.images?.jpg?.image_url || '',
    url: item.url || (item.mal_id ? `https://myanimelist.net/anime/${item.mal_id}` : '')
  };
}

async function anilist(query, variables = {}) {
  const { data } = await axios.post(ANILIST_URL, { query, variables }, {
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': APP_AGENT },
    timeout: HTTP_TIMEOUT
  });
  if (data?.errors?.length) throw new Error(data.errors[0].message || 'AniList query failed');
  if (!data?.data) throw new Error('AniList returned no anime data');
  return data.data;
}

async function jikan(path, params = {}) {
  const { data } = await axios.get(`${JIKAN_BASE}${path}`, {
    params,
    headers: { Accept: 'application/json', 'User-Agent': APP_AGENT },
    timeout: HTTP_TIMEOUT
  });
  if (!data || data.status >= 400) throw new Error(data?.message || 'Jikan request failed');
  return data.data;
}

const SEARCH_QUERY = `query ($search: String, $page: Int) { Page(page: $page, perPage: 5) { media(type: ANIME, search: $search, sort: SEARCH_MATCH, isAdult: false) { ${MEDIA_FIELDS} } } }`;
const TOP_QUERY = `query ($page: Int) { Page(page: $page, perPage: 10) { media(type: ANIME, sort: SCORE_DESC, isAdult: false) { ${MEDIA_FIELDS} } } }`;
const RANDOM_QUERY = `query ($page: Int) { Page(page: $page, perPage: 20) { media(type: ANIME, sort: POPULARITY_DESC, isAdult: false) { ${MEDIA_FIELDS} } } }`;
const DETAIL_SEARCH_QUERY = `query ($search: String) { Media(search: $search, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} } }`;
const DETAIL_ID_QUERY = `query ($id: Int, $idMal: Int) { Media(id: $id, idMal: $idMal, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} } }`;

function nonAdultJikan(items) {
  return (items || []).filter(x => !/\bRx\b|Hentai/i.test(x.rating || ''));
}

async function searchAnime(query, page = 1) {
  const q = String(query || '').trim();
  if (!q) throw new Error('Enter an anime title to search.');
  try {
    const data = await anilist(SEARCH_QUERY, { search: q, page: Math.max(1, Number(page) || 1) });
    const results = data.Page?.media || [];
    if (results.length) return results.map(mapAniList).filter(Boolean);
  } catch (_) {}
  const data = await jikan('/anime', { q, page: Math.max(1, Number(page) || 1), limit: 5, sfw: true });
  return nonAdultJikan(data).map(mapJikan).filter(Boolean);
}

async function getTopAnime(page = 1) {
  try {
    const data = await anilist(TOP_QUERY, { page: Math.max(1, Number(page) || 1) });
    const results = data.Page?.media || [];
    if (results.length) return results.map(mapAniList).filter(Boolean);
  } catch (_) {}
  const data = await jikan('/top/anime', { page: Math.max(1, Number(page) || 1), limit: 10, filter: 'bypopularity', sfw: true });
  return nonAdultJikan(data).map(mapJikan).filter(Boolean);
}

async function getRandomAnime() {
  try {
    const page = 1 + Math.floor(Math.random() * 300);
    const data = await anilist(RANDOM_QUERY, { page });
    const results = (data.Page?.media || []).map(mapAniList).filter(Boolean);
    if (results.length) return results[Math.floor(Math.random() * results.length)];
  } catch (_) {}
  const item = await jikan('/random/anime');
  if (item && !/\bRx\b|Hentai/i.test(item.rating || '')) return mapJikan(item);
  const safe = await getTopAnime(1);
  if (!safe.length) throw new Error('Anime API returned no safe anime results.');
  return safe[Math.floor(Math.random() * safe.length)];
}

function parseAnimeId(input) {
  const raw = String(input || '').trim();
  const anilistId = raw.match(/anilist\.co\/anime\/(\d+)/i)?.[1];
  const malId = raw.match(/(?:myanimelist\.net\/anime\/|^)(\d+)/i)?.[1];
  let query = raw;
  if (anilistId) {
    try {
      const parts = new URL(raw).pathname.split('/').filter(Boolean);
      const slug = parts[2] || '';
      if (slug) query = decodeURIComponent(slug).replace(/[-_]+/g, ' ').trim();
    } catch (_) {}
  }
  return { anilistId: anilistId ? Number(anilistId) : null, malId: malId ? Number(malId) : null, query };
}

async function getAnimeInfo(input) {
  const parsed = parseAnimeId(input);
  if (!parsed.query) throw new Error('Enter an anime title, AniList ID, or MyAnimeList ID.');
  try {
    let data;
    if (parsed.anilistId || parsed.malId) {
      data = await anilist(DETAIL_ID_QUERY, { id: parsed.anilistId || null, idMal: parsed.malId || null });
    } else {
      data = await anilist(DETAIL_SEARCH_QUERY, { search: parsed.query });
    }
    const item = data.Media;
    if (item) return mapAniList(item);
  } catch (_) {}
  let item;
  if (parsed.malId) item = await jikan(`/anime/${parsed.malId}/full`);
  else {
    const found = await jikan('/anime', { q: parsed.query, limit: 1, sfw: true });
    item = nonAdultJikan(found)[0];
    if (item?.mal_id) item = await jikan(`/anime/${item.mal_id}/full`);
  }
  return mapJikan(item);
}

async function purrbotImage(category) {
  const mapped = SAFE_IMAGE_PATHS[category] || 'neko';
  const { data } = await axios.get(`${PURRBOT_BASE}/img/sfw/${mapped}/img`, {
    headers: { Accept: 'application/json', 'User-Agent': APP_AGENT }, timeout: HTTP_TIMEOUT
  });
  if (data?.error || !/^https:\/\//i.test(data?.link || '')) throw new Error(data?.message || 'SFW image API returned no image');
  return data.link;
}

async function downloadImage(url) {
  const { data, headers } = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { Accept: 'image/*', 'User-Agent': APP_AGENT },
    timeout: HTTP_TIMEOUT,
    maxContentLength: 8 * 1024 * 1024
  });
  const buffer = Buffer.from(data || []);
  const contentType = String(headers?.['content-type'] || '').toLowerCase();
  if (!buffer.length || (contentType && !contentType.startsWith('image/'))) throw new Error('Image source returned invalid media');
  if (buffer.length > 8 * 1024 * 1024) throw new Error('Image exceeds the 8 MB upload limit');
  return buffer;
}

async function getRandomImage(category = 'neko') {
  try {
    const imageUrl = await purrbotImage(category);
    return { buffer: await downloadImage(imageUrl), imageUrl };
  } catch (primaryError) {
    // If the image endpoint is unavailable, a safe anime cover from AniList/Jikan remains usable.
    try {
      const anime = await getRandomAnime();
      if (!anime.image) throw new Error('Anime metadata did not include a cover image.');
      return { buffer: await downloadImage(anime.image), imageUrl: anime.image };
    } catch (fallbackError) {
      throw new Error(`Could not fetch a safe anime image: ${fallbackError.message || primaryError.message}`);
    }
  }
}

function createImageCommand({ name, aliases = [], category = 'anime', description, usage, imageCategory = 'neko', caption = '🌸 *Random SFW Anime Image*', emoji = '🌸' }) {
  return {
    name, aliases, category, description, usage: usage || `.${name}`,
    async execute(sock, msg, args, extra = {}) {
      try {
        if (typeof extra.react === 'function') await extra.react(emoji);
        const { buffer } = await getRandomImage(imageCategory);
        await sock.sendMessage(msg.key.remoteJid, { image: buffer, caption }, { quoted: msg });
        if (typeof extra.react === 'function') await extra.react('✅');
      } catch (error) {
        if (typeof extra.react === 'function') await extra.react('❌');
        if (typeof extra.reply === 'function') await extra.reply(`❌ ${error.message}`);
      }
    }
  };
}

function formatAnime(item, rank = null) {
  if (!item) return 'No anime found.';
  const rows = [];
  rows.push(`🎌 *${item.title || 'Unknown anime'}*`);
  if (item.nativeTitle && item.nativeTitle !== item.title) rows.push(`🇯🇵 ${item.nativeTitle}`);
  if (rank) rows.push(`🏆 Rank: #${rank}`);
  if (item.year) rows.push(`📅 Year: ${item.year}`);
  if (item.format) rows.push(`📺 Type: ${item.format}`);
  if (item.episodes) rows.push(`🔢 Episodes: ${item.episodes}`);
  if (item.duration) rows.push(`⏱️ Episode duration: ${item.duration}`);
  if (item.status) rows.push(`📍 Status: ${item.status}`);
  if (item.score) rows.push(`⭐ Score: ${item.score}/10`);
  if (item.genres?.length) rows.push(`🏷️ Genres: ${item.genres.join(', ')}`);
  if (item.synopsis) rows.push(`\n📝 ${item.synopsis.slice(0, 1000)}`);
  if (item.url) rows.push(`\n🔗 ${item.url}`);
  return rows.join('\n');
}

module.exports = { searchAnime, getTopAnime, getRandomAnime, getAnimeInfo, getRandomImage, formatAnime, createImageCommand };
