'use strict';

const axios = require('axios');
const animeApi = require('./animeApi');
const CINEMETA = 'https://v3-cinemeta.strem.io';
const TMDB = 'https://api.themoviedb.org/3';
const TMDB_IMAGE = 'https://image.tmdb.org/t/p/w500';
const TIMEOUT = 12000;

function tmdbToken() {
  return String(process.env.TMDB_ACCESS_TOKEN || '').trim();
}

async function tmdb(path, params = {}) {
  const token = tmdbToken();
  if (!token) return null;
  const { data } = await axios.get(`${TMDB}${path}`, {
    params: { language: 'en-US', ...params },
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
    timeout: TIMEOUT
  });
  if (!data || data.success === false) throw new Error(data?.status_message || 'TMDB request failed');
  return data;
}

async function cinemeta(path) {
  const { data } = await axios.get(`${CINEMETA}${path}`, {
    headers: { Accept: 'application/json' }, timeout: TIMEOUT
  });
  return data;
}

async function cinemetaCatalog(type, query = '', page = 1) {
  const skip = Math.max(0, (page - 1) * 50);
  const path = query
    ? `/catalog/${type}/top/search=${encodeURIComponent(query)}.json`
    : `/catalog/${type}/top.json?skip=${skip}`;
  const data = await cinemeta(path);
  return Array.isArray(data?.metas) ? data.metas : [];
}

function imageUrl(path) {
  return path ? `${TMDB_IMAGE}${path}` : '';
}

function mapTmdb(item, type = 'movie') {
  const title = item.title || item.name || 'Untitled';
  const date = item.release_date || item.first_air_date || '';
  const id = item.id;
  return {
    id,
    title,
    name: title,
    type,
    year: date ? date.slice(0, 4) : '',
    releaseInfo: date ? date.slice(0, 4) : '',
    rating: Number.isFinite(Number(item.vote_average)) ? Number(item.vote_average).toFixed(1) : '',
    overview: item.overview || '',
    description: item.overview || '',
    image: imageUrl(item.poster_path),
    poster: imageUrl(item.poster_path),
    url: `https://www.themoviedb.org/${type === 'tv' ? 'tv' : 'movie'}/${id}`
  };
}

function mapCinemeta(item, type) {
  const imdbId = item.imdb_id || (/^tt\d+$/.test(item.id || '') ? item.id : '');
  return {
    id: imdbId || item.id,
    imdbId: imdbId || '',
    title: item.name || item.title || 'Untitled',
    name: item.name || item.title || 'Untitled',
    type: type === 'series' ? 'TV' : type,
    year: item.releaseInfo || '',
    releaseInfo: item.releaseInfo || '',
    rating: item.imdbRating || item.rating || '',
    overview: item.description || '',
    description: item.description || '',
    image: item.poster || '',
    poster: item.poster || '',
    url: imdbId ? `https://www.imdb.com/title/${imdbId}/` : ''
  };
}

async function tmdbOrCinemetaSearch(kind, query, page = 1) {
  const isMovie = kind === 'movie';
  const type = isMovie ? 'movie' : 'series';
  try {
    const data = await tmdb(isMovie ? '/search/movie' : '/search/tv', { query, page });
    if (data) return (data.results || []).map(item => mapTmdb(item, isMovie ? 'movie' : 'tv'));
  } catch (_) {
    // If a configured TMDB token is expired/invalid, use the public metadata fallback.
  }
  const metas = await cinemetaCatalog(type, query, page);
  return metas.map(item => mapCinemeta(item, type));
}

async function tmdbOrCinemetaTrending(kind, page = 1) {
  const isMovie = kind === 'movie';
  const type = isMovie ? 'movie' : 'series';
  try {
    const path = isMovie ? '/trending/movie/week' : '/trending/tv/week';
    const data = await tmdb(path, { page });
    if (data) return (data.results || []).map(item => mapTmdb(item, isMovie ? 'movie' : 'tv'));
  } catch (_) {}
  const metas = await cinemetaCatalog(type, '', page);
  return metas.map(item => mapCinemeta(item, type));
}

async function searchPeople(query) {
  try {
    const data = await tmdb('/search/person', { query, page: 1 });
    if (data) return (data.results || []).slice(0, 10).map(person => ({
      name: person.name,
      image: imageUrl(person.profile_path),
      knownFor: (person.known_for || []).map(x => x.title || x.name).filter(Boolean).slice(0, 3).join(', '),
      detailUrl: `https://www.themoviedb.org/person/${person.id}`
    }));
  } catch (_) {}
  const { data } = await axios.get('https://api.tvmaze.com/search/people', {
    params: { q: query }, timeout: TIMEOUT, headers: { Accept: 'application/json' }
  });
  return (Array.isArray(data) ? data : []).slice(0, 10).map(({ person }) => ({
    name: person?.name || 'Unknown',
    image: person?.image?.medium || '',
    knownFor: [person?.country?.name, person?.birthday].filter(Boolean).join(' · '),
    detailUrl: person?.url || ''
  }));
}

function queryFromInput(input) {
  const raw = String(input || '').trim();
  const imdb = raw.match(/tt\d{7,10}/i)?.[0];
  if (imdb) return { imdb };
  const tmdbPath = raw.match(/\/(?:movie|tv)\/(\d+)/i)?.[1];
  if (tmdbPath) return { numericId: tmdbPath };
  if (/^\d+$/.test(raw)) return { numericId: raw };
  try {
    const u = new URL(raw);
    const slug = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '');
    return { query: slug.replace(/\.(?:html?|php)$/i, '').replace(/[-_]+/g, ' ').trim() || raw };
  } catch (_) {
    return { query: raw };
  }
}

async function tmdbDetail(kind, input) {
  const isMovie = kind === 'movie';
  const endpointKind = isMovie ? 'movie' : 'tv';
  const inputInfo = queryFromInput(input);
  try {
    let id = inputInfo.numericId || null;
    if (inputInfo.imdb) {
      const found = await tmdb(`/find/${inputInfo.imdb}`, { external_source: 'imdb_id' });
      const list = isMovie ? found?.movie_results : found?.tv_results;
      id = list?.[0]?.id || null;
    }
    if (!id && inputInfo.query) {
      const found = await tmdb(isMovie ? '/search/movie' : '/search/tv', { query: inputInfo.query, page: 1 });
      id = found?.results?.[0]?.id || null;
    }
    if (id) {
      const item = await tmdb(`/${endpointKind}/${id}`, { append_to_response: 'videos,credits' });
      if (item) {
        const mapped = mapTmdb(item, endpointKind);
        const trailers = (item.videos?.results || []).filter(v => v.site === 'YouTube' && v.key && /trailer/i.test(v.type || ''));
        mapped.trailerUrl = trailers[0] ? `https://www.youtube.com/watch?v=${trailers[0].key}` : '';
        mapped.cast = (item.credits?.cast || []).slice(0, 8).map(p => p.name);
        return mapped;
      }
    }
  } catch (_) {}

  const type = isMovie ? 'movie' : 'series';
  let imdb = inputInfo.imdb;
  let meta = null;
  if (imdb) {
    const data = await cinemeta(`/meta/${type}/${imdb}.json`);
    meta = data?.meta || null;
  } else {
    const query = inputInfo.query || inputInfo.numericId || String(input || '');
    const results = await cinemetaCatalog(type, query, 1);
    meta = results[0] || null;
    imdb = meta?.imdb_id || (/^tt\d+$/.test(meta?.id || '') ? meta.id : '');
    if (imdb) {
      const data = await cinemeta(`/meta/${type}/${imdb}.json`);
      meta = data?.meta || meta;
    }
  }
  if (!meta) return null;
  const mapped = mapCinemeta(meta, type);
  mapped.trailerUrl = meta.trailers?.[0]?.source
    ? `https://www.youtube.com/watch?v=${meta.trailers[0].source}`
    : '';
  mapped.url = imdb ? `https://www.imdb.com/title/${imdb}/` : mapped.url;
  return mapped;
}

async function fallback(endpoint, params = {}) {
  const page = Math.max(1, parseInt(params.page, 10) || 1);
  if (endpoint === '/iboxmovies') {
    const items = await tmdbOrCinemetaTrending('movie', page);
    return { trending: items.slice(0, 8), items: [], page, totalPages: '?' };
  }
  if (endpoint === '/iboxtv') {
    const items = await tmdbOrCinemetaTrending('tv', page);
    return { trending: items.slice(0, 8), items: [], page, totalPages: '?' };
  }
  if (endpoint === '/iboxanime') {
    const items = await animeApi.getTopAnime(page);
    return { trending: items.slice(0, 8).map(item => ({ title: item.title, year: item.year, rating: item.score, url: item.url })), items: [], page, totalPages: '?' };
  }
  if (endpoint === '/iboxmovies/search' || endpoint === '/moviebox/search') {
    const items = await tmdbOrCinemetaSearch('movie', String(params.q || ''), page);
    if (endpoint === '/moviebox/search') return { results: items };
    return items;
  }
  if (endpoint === '/iboxtv/search') return tmdbOrCinemetaSearch('tv', String(params.q || ''), page);
  if (endpoint === '/iboxanime/search') {
    return animeApi.searchAnime(String(params.q || ''), page);
  }
  if (endpoint === '/actor/search') return searchPeople(String(params.q || ''));
  if (endpoint === '/iboxmovies/detail') return tmdbDetail('movie', params.url);
  if (endpoint === '/iboxtv/detail') return tmdbDetail('tv', params.url);
  if (endpoint === '/iboxanime/detail') {
    const item = await animeApi.getAnimeInfo(params.url);
    return item ? { title: item.title, year: item.year, rating: item.score, overview: item.synopsis, image: item.image, url: item.url } : null;
  }
  if (endpoint === '/movie/trailer') {
    const details = await tmdbDetail('movie', params.q);
    if (!details) return null;
    const trailerUrl = details.trailerUrl || `https://www.youtube.com/results?search_query=${encodeURIComponent(`${details.title} official trailer`)}`;
    return { title: details.title, description: details.overview, thumbnail: details.image, trailerUrl, url: details.url };
  }
  throw new Error(`No fallback metadata API is available for ${endpoint}`);
}

module.exports = { fallback };
