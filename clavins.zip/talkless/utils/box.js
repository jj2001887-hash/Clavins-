/**
 * Reply formatter (frameless).
 *
 * The old big ╔═══╗ frames are gone. box()/boxChunks() now return a bold title
 * followed by the body; the "> POWERED BY TALKLESS" quote is added once, at the
 * very bottom of every command reply, by helper/cleanText.js.
 */
const BOX_CHARS = /(?:^|\n)\s*(?:╔|┏|╭|╓|┌)/;

/** Kept for compatibility: wraps a single line only when a width is passed explicitly. */
function wrapLine(line, max = Infinity) {
  if (!isFinite(max) || [...line].length <= max) return [line];
  const out = []; let cur = '';
  for (const w of line.split(' ')) {
    const next = cur ? cur + ' ' + w : w;
    if ([...next].length > max && cur) { out.push(cur); cur = w; } else cur = next;
  }
  if (cur) out.push(cur);
  return out;
}

/** No forced line breaks any more: WhatsApp wraps text to the screen by itself. */
function wrapText(text) { return String(text); }

function box(title, body = '', footer = '') {
  const lines = String(body || '').split('\n');
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  const out = [];
  if (title) out.push(`*${String(title).replace(/^\*+|\*+$/g, '')}*`);
  if (title && lines.length) out.push('');
  out.push(...lines);
  if (footer) out.push('', String(footer));
  return out.join('\n');
}

/** Plain text stays plain. */
function autoBox(text) { return text; }

/** Split a long body into several messages (WhatsApp ~4k char limit). */
function boxChunks(title, body, limit = 3500) {
  const chunks = [];
  let cur = '';
  for (const line of String(body).split('\n')) {
    if ((cur + line + '\n').length > limit && cur) { chunks.push(cur); cur = ''; }
    cur += line + '\n';
  }
  if (cur.trim()) chunks.push(cur);
  if (!chunks.length) chunks.push('_No data available_');
  return chunks.map((c, i) => box(chunks.length > 1 ? `${title} (${i + 1}/${chunks.length})` : title, c));
}

module.exports = { box, autoBox, boxChunks, BOX_CHARS, wrapLine, wrapText };
