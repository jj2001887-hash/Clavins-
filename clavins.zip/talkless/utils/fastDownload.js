/**
 * Fast audio resolver: asks the providers at the same time and uses the
 * first one that answers instead of waiting through serial retries.
 * Results are cached so repeat requests are instant.
 */
const axios = require('axios');

const TTL = 30 * 60 * 1000;
const cache = new Map(); // key -> { at, value }
const inflight = new Map();

const H = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36', Accept: 'application/json, */*' };
const get = (url, ms) => axios.get(url, { timeout: ms, headers: H }).then(r => r.data);

const enc = encodeURIComponent;
const PROVIDERS = [
  // Documented OmegaTech audio endpoint. It returns short-lived MP3/M4A URLs.
  async (u, ms) => {
    const d = await get(`https://api.omegatech.app/api/download/YouTube?action=download&url=${enc(u)}&type=audio&bitrate=128`, ms);
    const data = d?.data;
    const audio = data?.audio?.mp3?.downloadUrl || data?.audio?.m4a?.downloadUrl;
    if (!d?.success || !audio) throw new Error('omegatech: no audio URL');
    return { download: audio, title: data.title, thumbnail: data.thumbnail };
  },
  async (u, ms) => {
    const d = await get(`https://yt-dl.officialhectormanuel.workers.dev/?url=${enc(u)}`, ms);
    if (!d?.audio) throw new Error('hector: no url');
    return { download: d.audio, title: d.title, thumbnail: d.thumbnail };
  }
];

function any(promises) {
  return new Promise((resolve, reject) => {
    let left = promises.length;
    const errs = [];
    promises.forEach(p => p.then(resolve, e => { errs.push(e.message); if (--left === 0) reject(new Error('All providers failed: ' + errs.join(' | '))); }));
  });
}

function resolveAudio(videoUrl, timeoutMs = 20000) {
  const hit = cache.get(videoUrl);
  if (hit && Date.now() - hit.at < TTL) return Promise.resolve(hit.value);
  if (inflight.has(videoUrl)) return inflight.get(videoUrl);
  const p = any(PROVIDERS.map(fn => fn(videoUrl, timeoutMs)))
    .then(v => { cache.set(videoUrl, { at: Date.now(), value: v }); return v; })
    .finally(() => inflight.delete(videoUrl));
  inflight.set(videoUrl, p);
  return p;
}

// ── Search (cached) ──────────────────────────────────────────────────────────
const searchCache = new Map();
async function ytSearch(query) {
  const key = query.toLowerCase().trim();
  const hit = searchCache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.value;
  let v;
  try {
    const d = await get(`https://api.omegatech.app/api/Search/yt-mp3?query=${enc(query)}&limit=5`, 12000);
    const item = d?.results?.[0];
    if (d?.success && item?.url) {
      const duration = String(item.duration || '');
      const seconds = duration.split(':').reduce((n, part) => n * 60 + (Number(part) || 0), 0);
      v = {
        ...item,
        videoId: item.id || (item.url.match(/[?&]v=([\w-]{11})/) || [])[1],
        timestamp: duration,
        seconds,
        views: item.views || 0,
        author: { name: item.channel || '' },
        thumbnail: item.thumbnail || ''
      };
    }
  } catch (_) {}
  if (!v) {
    const yts = require('yt-search');
    const r = await yts(query);
    v = r?.videos?.[0];
  }
  if (!v?.url) throw new Error('No results found');
  searchCache.set(key, { at: Date.now(), value: v });
  return v;
}

module.exports = { resolveAudio, ytSearch, any };
