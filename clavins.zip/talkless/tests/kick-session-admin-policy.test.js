'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const kick = require('../commands/admin/kick');

test('kick uses the invoking session group-admin policy, not paired-owner-only authorization', () => {
  assert.equal(kick.pairedOnly, undefined, 'kick must not stop at the paired-owner gate');
  assert.equal(kick.ownerOnly, undefined, 'kick is not owner-only');
  assert.equal(kick.groupOnly, true, 'kick is limited to group chats');
  assert.equal(kick.adminOnly, true, 'the invoking participant must be a current group admin');
  assert.equal(kick.botAdminNeeded, true, 'the paired bot session must also be a current group admin');
});
