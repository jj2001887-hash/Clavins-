'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const projectDir = path.resolve(__dirname, '..');
const configPath = path.join(projectDir, 'config.js');
const databasePath = path.join(projectDir, 'database.js');
const sessionCtxPath = path.join(projectDir, 'utils', 'sessionCtx.js');
const sessionCtx = require(sessionCtxPath);

async function withMockDatabase(database, run) {
  const oldConfig = require.cache[configPath];
  const oldDatabase = require.cache[databasePath];
  delete require.cache[configPath];
  require.cache[databasePath] = {
    id: databasePath,
    filename: databasePath,
    loaded: true,
    exports: database,
    children: [],
    paths: []
  };

  try {
    return await run(require(configPath));
  } finally {
    delete require.cache[configPath];
    if (oldConfig) require.cache[configPath] = oldConfig;
    if (oldDatabase) require.cache[databasePath] = oldDatabase;
    else delete require.cache[databasePath];
  }
}

test('config properties resolve independently in interleaved AsyncLocalStorage sessions', async () => {
  const settings = new Map([
    ['session-a', { ownerNumber: '111', ownerName: 'Alpha', prefix: '' }],
    ['session-b', { ownerNumber: '222', ownerName: 'Beta', prefix: '0' }]
  ]);
  const database = {
    getBotSetting(key) {
      return settings.get(sessionCtx.current())?.[key];
    }
  };

  await withMockDatabase(database, async config => {
    await Promise.all([
      sessionCtx.run('session-a', async () => {
        await new Promise(resolve => setImmediate(resolve));
        assert.deepEqual(config.ownerNumber, ['111']);
        assert.deepEqual(config.ownerName, ['Alpha']);
        assert.equal(config.prefix, '');
        await new Promise(resolve => setImmediate(resolve));
        assert.equal(config.prefix, '');
      }),
      sessionCtx.run('session-b', async () => {
        await new Promise(resolve => setImmediate(resolve));
        assert.deepEqual(config.ownerNumber, ['222']);
        assert.deepEqual(config.ownerName, ['Beta']);
        assert.equal(config.prefix, '0');
        await new Promise(resolve => setImmediate(resolve));
        assert.equal(config.prefix, '0');
      })
    ]);
  });
});

test('undefined settings and no context use stable global defaults; falsy prefixes remain settings', async () => {
  let values;
  const database = { getBotSetting: key => values && values[key] };

  await withMockDatabase(database, async config => {
    const defaults = {
      ownerNumber: config.ownerNumber,
      ownerName: config.ownerName,
      prefix: config.prefix,
      botName: config.botName
    };
    assert.ok(Array.isArray(defaults.ownerNumber));
    assert.ok(Array.isArray(defaults.ownerName));
    assert.equal(typeof defaults.prefix, 'string');
    assert.equal(typeof defaults.botName, 'string');

    assert.deepEqual(config.ownerNumber, defaults.ownerNumber);
    assert.deepEqual(config.ownerName, defaults.ownerName);
    assert.equal(config.prefix, defaults.prefix);

    values = { ownerNumber: '333', ownerName: 'Gamma', prefix: 0 };
    sessionCtx.run('session-zero', () => {
      assert.deepEqual(config.ownerNumber, ['333']);
      assert.deepEqual(config.ownerName, ['Gamma']);
      assert.equal(config.prefix, 0);
    });

    values = { prefix: '' };
    sessionCtx.run('session-empty', () => {
      assert.equal(config.prefix, '');
      assert.deepEqual(config.ownerNumber, defaults.ownerNumber);
      assert.deepEqual(config.ownerName, defaults.ownerName);
    });

    values = { prefix: '.', botName: 'Session A' };
    sessionCtx.run('name-a', () => assert.equal(config.botName, 'Session A'));
    values = { prefix: '!', botName: 'Session B' };
    sessionCtx.run('name-b', () => assert.equal(config.botName, 'Session B'));
    values = { prefix: '!' };
    sessionCtx.run('55550000', () => {
      assert.deepEqual(config.ownerNumber, ['55550000']);
    });
    assert.equal(config.prefix, defaults.prefix, 'without a session, do not read shared DB settings');

    // Assignments made by legacy code must not replace immutable global defaults.
    values = undefined;
    config.prefix = 'temporary';
    assert.equal(config.prefix, defaults.prefix);
  });
});

test('database can read config while its exports are still initializing', async () => {
  const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'talkless-config-cycle-'));
  const fixtureUtils = path.join(fixture, 'utils');
  fs.mkdirSync(fixtureUtils, { recursive: true });
  fs.copyFileSync(configPath, path.join(fixture, 'config.js'));
  fs.copyFileSync(sessionCtxPath, path.join(fixtureUtils, 'sessionCtx.js'));

  const sourceDatabase = fs.readFileSync(databasePath, 'utf8');
  const initializationProbe = 'const config = require("./config");\nvoid config.prefix;';
  assert.ok(sourceDatabase.includes('const config = require("./config");'));
  fs.writeFileSync(
    path.join(fixture, 'database.js'),
    sourceDatabase.replace('const config = require("./config");', initializationProbe)
  );

  const fixtureConfigPath = path.join(fixture, 'config.js');
  const fixtureDatabasePath = path.join(fixture, 'database.js');
  const fixtureSessionCtxPath = path.join(fixtureUtils, 'sessionCtx.js');
  try {
    const database = require(fixtureDatabasePath);
    const config = require(fixtureConfigPath);
    const isolatedSessionCtx = require(fixtureSessionCtxPath);

    isolatedSessionCtx.run('initialization-session', () => {
      database.setBotSetting('prefix', '');
      database.setBotSetting('ownerNumber', '444');
      database.setBotSetting('ownerName', 'Delta');
      assert.equal(config.prefix, '');
      assert.deepEqual(config.ownerNumber, ['444']);
      assert.deepEqual(config.ownerName, ['Delta']);
    });
    await new Promise(resolve => setImmediate(resolve));
  } finally {
    delete require.cache[fixtureConfigPath];
    delete require.cache[fixtureDatabasePath];
    delete require.cache[fixtureSessionCtxPath];
    fs.rmSync(fixture, { recursive: true, force: true });
  }
});
