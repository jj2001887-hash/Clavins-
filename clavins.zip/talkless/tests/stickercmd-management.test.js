'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('node:module');
const commandPath = require.resolve('../commands/owner/stickercmd');
const commandMap = new Map([
  ['ping', { name: 'ping' }],
  ['yta', { name: 'play' }],
]);
let aliases = {};
const stickerStore = {
  getMap: () => ({ ...aliases }),
  saveMap: map => { aliases = { ...map }; },
  stickerFromMessage: message => message?.sticker || message?.quotedSticker || null,
  hashSticker: sticker => sticker?.hash || '',
};
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (parent?.filename === commandPath) {
    if (request === '../../utils/commandLoader') return { loadCommands: () => commandMap };
    if (request === '../../utils/stickerCommandStore') return stickerStore;
  }
  return originalLoad.call(this, request, parent, isMain);
};
const command = require(commandPath);
Module._load = originalLoad;

function replyRecorder() {
  const messages = [];
  return { messages, reply: async message => { messages.push(String(message)); } };
}

test('setstickercmd uses per-session owner authorization instead of fromMe-only paired authorization', () => {
  assert.ok(command.aliases.includes('setstickercmd'));
  assert.equal(command.ownerOnly, true);
  assert.equal(command.pairedOnly, undefined);
  assert.match(command.usage, /\.setstickercmd/);
});

test('setstickercmd binds a replied sticker to the canonical command name', async () => {
  aliases = {};
  const { messages, reply } = replyRecorder();
  await command.execute({}, { quotedSticker: { hash: 'sticker-hash' } }, ['set', 'yta'], { reply });
  assert.deepEqual(aliases, { 'sticker-hash': 'play' });
  assert.match(messages[0], /sending this sticker will run \.play/);
});

test('setstickercmd lists, removes, and clears sticker command aliases', async () => {
  aliases = { 'sticker-hash': 'ping', 'another-hash': 'play' };
  const listed = replyRecorder();
  await command.execute({}, {}, ['list'], { reply: listed.reply });
  assert.match(listed.messages[0], /Sticker command aliases \(2\)/);
  assert.match(listed.messages[0], /\.ping/);

  const removed = replyRecorder();
  await command.execute({}, { sticker: { hash: 'sticker-hash' } }, ['remove'], { reply: removed.reply });
  assert.deepEqual(aliases, { 'another-hash': 'play' });
  assert.match(removed.messages[0], /Removed the sticker alias for \.ping/);

  const cleared = replyRecorder();
  await command.execute({}, {}, ['clear'], { reply: cleared.reply });
  assert.deepEqual(aliases, {});
  assert.match(cleared.messages[0], /Removed all 1 sticker command alias/);
});

test('setstickercmd explains missing stickers and unknown commands without saving', async () => {
  aliases = {};
  const noSticker = replyRecorder();
  await command.execute({}, {}, ['set', 'ping'], { reply: noSticker.reply });
  assert.match(noSticker.messages[0], /Reply to a sticker/);
  assert.deepEqual(aliases, {});

  const unknown = replyRecorder();
  await command.execute({}, { sticker: { hash: 'sticker-hash' } }, ['set', 'not-a-command'], { reply: unknown.reply });
  assert.match(unknown.messages[0], /could not find the command/);
  assert.deepEqual(aliases, {});
});
