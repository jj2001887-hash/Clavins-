'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const kickall = require('../commands/admin/kickall');

function makeFixture({ count = 25, failOnCall = 0 } = {}) {
  const updates = [];
  const sent = [];
  const targets = Array.from({ length: count }, (_, index) => `${52000 + index}@s.whatsapp.net`);
  const metadata = {
    owner: '51001@s.whatsapp.net',
    creator: '51001@s.whatsapp.net',
    participants: [
      { id: '51000:1@s.whatsapp.net', admin: 'admin' },
      { id: '51001@s.whatsapp.net', admin: 'superadmin' },
      ...targets.map(id => ({ id, admin: null })),
    ],
  };
  const sock = {
    user: { id: '51000:1@s.whatsapp.net' },
    async groupMetadata(groupId) {
      assert.equal(groupId, '51002@g.us');
      return metadata;
    },
    async groupParticipantsUpdate(groupId, participants, action) {
      updates.push({ groupId, participants: [...participants], action });
      if (failOnCall && updates.length === failOnCall) throw new Error('simulated batch failure');
      return participants.map(jid => ({ jid, status: 200 }));
    },
    async sendMessage(...args) { sent.push(args); },
  };
  return { sock, updates, sent, targets };
}

const extra = { from: '51002@g.us', sender: '51000@s.whatsapp.net', reply: async () => {} };

test('kickall uses group-admin authorization, not paired-owner-only authorization', () => {
  assert.equal(kickall.pairedOnly, undefined);
  assert.equal(kickall.ownerOnly, undefined);
  assert.equal(kickall.groupOnly, true);
  assert.equal(kickall.adminOnly, true);
  assert.equal(kickall.botAdminNeeded, true);
});

test('kickall sends eligible members in sequential batches of at most ten', async () => {
  const { sock, updates, sent, targets } = makeFixture();
  await kickall.execute(sock, {}, [], extra);
  assert.deepEqual(updates.map(update => update.participants.length), [10, 10, 5]);
  assert.ok(updates.every(update => update.action === 'remove' && update.groupId === extra.from));
  assert.deepEqual(updates.flatMap(update => update.participants), targets);
  assert.match(sent.at(-1)[1].text, /Removed 25 eligible member\(s\)/);
  assert.doesNotMatch(sent.at(-1)[1].text, /Mission ended with members remaining/);
});

test('kickall reports failed and unattempted members if a batch errors', async () => {
  const { sock, updates, sent } = makeFixture({ failOnCall: 2 });
  await kickall.execute(sock, {}, [], extra);
  assert.equal(updates.length, 2, 'stop issuing removals after the first failed batch');
  assert.match(sent.at(-1)[1].text, /Removed 10 of 25 eligible member\(s\)/);
  assert.match(sent.at(-1)[1].text, /10 member\(s\) failed or could not be confirmed/);
  assert.match(sent.at(-1)[1].text, /5 member\(s\) were not attempted/);
});
