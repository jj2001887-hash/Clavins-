'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const sessionCtx = require('../utils/sessionCtx');
const database = require('../database');
const store = require('../utils/stickerCommandStore');

test('sticker command aliases are isolated by paired session', () => {
  const originalGet = database.getBotSetting;
  const originalSet = database.setBotSetting;
  const values = new Map();
  database.getBotSetting = key => values.get(`${sessionCtx.current()}|${key}`);
  database.setBotSetting = (key, value) => values.set(`${sessionCtx.current()}|${key}`, value);
  try {
    sessionCtx.run('paired-one', () => store.saveMap({ abc: 'ping' }));
    sessionCtx.run('paired-two', () => store.saveMap({ abc: 'menu' }));
    assert.deepEqual(sessionCtx.run('paired-one', () => store.getMap()), { abc: 'ping' });
    assert.deepEqual(sessionCtx.run('paired-two', () => store.getMap()), { abc: 'menu' });
    assert.deepEqual(sessionCtx.run('paired-three', () => store.getMap()), {});
  } finally {
    database.getBotSetting = originalGet;
    database.setBotSetting = originalSet;
  }
});
