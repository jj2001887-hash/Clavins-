'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('node:module');
const commandPath = require.resolve('../commands/general/take');
let sent;
const stickerPack = {
  async readReceivedPack() { return { name: 'Original', stickers: [{ data: Buffer.from('one'), emojis: ['🙂'] }, { data: Buffer.from('two'), emojis: ['🔥'] }] }; },
  async embedExif(data, options) { return Buffer.concat([data, Buffer.from(`|${options.packName}|${options.publisher}`)]); },
  async sendPack(_sock, _jid, options) { sent = options; return { sent: options.stickers.length, error: null }; }
};
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (parent?.filename === commandPath) {
    if (request === '@whiskeysockets/baileys') return { downloadMediaMessage: async () => Buffer.from('single') };
    if (request === 'node-webpmux') return { Image: class {} };
    if (request === '../../utils/stickerPack') return stickerPack;
  }
  return originalLoad.call(this, request, parent, isMain);
};
const command = require(commandPath);
Module._load = originalLoad;

test('.take talkless applies the requested name to every sticker in the replied pack', async () => {
  sent = null;
  const replies = [];
  const msg = {
    pushName: 'Alice',
    message: { extendedTextMessage: { contextInfo: { stanzaId: 'quoted-1', quotedMessage: { stickerPackMessage: { name: 'Original' } } } } }
  };
  await command.execute({}, msg, ['talkless'], { from: 'chat', sender: '12345@s.whatsapp.net', reply: async value => replies.push(value) });
  assert.equal(sent.name, 'talkless');
  assert.equal(sent.stickers.length, 2);
  assert.ok(sent.stickers.every(sticker => sticker.data.toString().includes('|talkless|Alice')));
  assert.match(replies[0], /2\/2 stickers sent with the requested pack name/);
});
