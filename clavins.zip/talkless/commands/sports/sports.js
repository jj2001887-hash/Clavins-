/**
 * TALKLESS XMD Sport Commands — public fallback providers with an optional configured API.
 */

const axios = require('axios');
const BASE = String(process.env.SPORTS_API_BASE_URL || '').replace(/\/+$/, '');
const { fallback } = require('../../utils/sportsFallback');
const { box, boxChunks } = require('../../utils/box');

const cache = new Map();           // endpoint+params -> { at, value }
const CACHE_MS = 45 * 1000;        // repeat requests within 45s are instant
const sportsAbort = ms => ({ timeout: ms });

async function primaryRaw(endpoint, params) {
  const { data } = await axios.get(`${BASE}${endpoint}`, { params, ...sportsAbort(8000) });
  if (!data) throw new Error('No response from API');
  if (data.status === false) throw new Error(data.error || data.message || 'API error');
  const r = data.result !== undefined ? data.result : data;
  const empty = r == null || (Array.isArray(r) && !r.length);
  if (empty) throw new Error('empty result');
  return r;
}

/**
 * Use a configured provider only when SPORTS_API_BASE_URL is set; otherwise
 * go straight to the public fallbacks (ESPN / TheSportsDB).
 */
async function sportsApi(endpoint, params = {}) {
  const key = endpoint + JSON.stringify(params);
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.value;
  let value;
  if (BASE) {
    try {
      value = await primaryRaw(endpoint, params);
    } catch (e) {
      console.warn(`[sports] configured provider ${endpoint} failed: ${e.message}`);
    }
  }
  if (value === undefined) {
    try {
      value = await fallback(endpoint, params);
    } catch (e) {
      console.warn(`[sports] ${endpoint}: fallback failed (${e.message})`);
      throw new Error('Sports data is temporarily unavailable. Please try again later.');
    }
    if (value == null) {
      if (endpoint.endsWith('/scorers')) {
        throw new Error('Top-scorer data is not available from the current free sources.');
      }
      if (endpoint === '/bet') {
        throw new Error('Betting tips are unavailable because no verified odds provider is configured.');
      }
      throw new Error('No data is available for this sports command right now.');
    }
    console.log(`[sports] ${endpoint}: served by public fallback provider`);
  }
  cache.set(key, { at: Date.now(), value });
  return value;
}

// ── Helpers ────────────────────────────────────────────────────────────────────

const react = (sock, msg, emoji) => sock.sendMessage(msg.key.remoteJid, {
  react: {
    text: emoji,
    key: msg.key
  }
});
const send = (sock, msg, text) => sock.sendMessage(msg.key.remoteJid, {
  text
}, {
  quoted: msg
});
async function sendLong(sock, msg, header, body) {
  // header looks like "┏━━『 title 』━━" -> pull the title out for the box
  const title = (header.match(/『\s*(.*?)\s*』/) || [, header])[1];
  const boxes = boxChunks(title, body || '_No data available_');
  for (let i = 0; i < boxes.length; i++) {
    await sock.sendMessage(msg.key.remoteJid, { text: boxes[i] }, { quoted: i === 0 ? msg : undefined });
    if (i < boxes.length - 1) await new Promise(r => setTimeout(r, 600));
  }
}

// ── Formatters ─────────────────────────────────────────────────────────────────

function fmtPlayers(result) {
  const arr = Array.isArray(result) ? result : [];
  if (!arr.length) return '_No players found_';
  return arr.slice(0, 10).map((p, i) => {
    let t = `*${i + 1}. ${p.name || p.strPlayer || 'Unknown'}*\n`;
    if (p.team) t += `   🏟️ Team: ${p.team}\n`;
    if (p.sport) t += `   🏅 Sport: ${p.sport}\n`;
    if (p.nationality) t += `   🌍 Nationality: ${p.nationality}\n`;
    if (p.position) t += `   📍 Position: ${p.position}\n`;
    if (p.birthDate) t += `   🎂 Born: ${p.birthDate}\n`;
    if (p.status) t += `   ✅ Status: ${p.status}\n`;
    return t;
  }).join('\n');
}
function fmtTeams(result) {
  const arr = Array.isArray(result) ? result : [];
  if (!arr.length) return '_No teams found_';
  return arr.slice(0, 5).map((t, i) => {
    let s = `*${i + 1}. ${t.name || 'Unknown'}*\n`;
    if (t.league) s += `   🏆 League: ${t.league}\n`;
    if (t.sport) s += `   🏅 Sport: ${t.sport}\n`;
    if (t.stadium) s += `   🏟️ Stadium: ${t.stadium}\n`;
    if (t.stadiumCapacity) s += `   👥 Capacity: ${Number(t.stadiumCapacity).toLocaleString()}\n`;
    if (t.location) s += `   📍 Location: ${t.location}\n`;
    if (t.country) s += `   🌍 Country: ${t.country}\n`;
    if (t.formedYear) s += `   📅 Founded: ${t.formedYear}\n`;
    if (t.social?.website) s += `   🌐 ${t.social.website}\n`;
    if (t.description) s += `   📝 ${String(t.description).slice(0, 200).trim()}...\n`;
    return s;
  }).join('\n');
}
function fmtVenues(result) {
  const arr = Array.isArray(result) ? result : [];
  if (!arr.length) return '_No venues found_';
  return arr.slice(0, 5).map((v, i) => {
    let s = `*${i + 1}. ${v.name || 'Unknown'}*\n`;
    if (v.sport) s += `   🏅 Sport: ${v.sport}\n`;
    if (v.capacity) s += `   👥 Capacity: ${Number(v.capacity).toLocaleString()}\n`;
    if (v.location) s += `   📍 Location: ${v.location}\n`;
    if (v.country) s += `   🌍 Country: ${v.country}\n`;
    if (v.description) s += `   📝 ${String(v.description).slice(0, 200).trim()}...\n`;
    return s;
  }).join('\n');
}
function fmtGameEvents(result) {
  const arr = Array.isArray(result) ? result : [];
  if (!arr.length) return '_No events found_';
  return arr.slice(0, 10).map(e => {
    const home = e.teams?.home?.name || e.homeTeam || '?';
    const away = e.teams?.away?.name || e.awayTeam || '?';
    const hs = e.teams?.home?.score;
    const as_ = e.teams?.away?.score;
    const date = e.dateTime?.date || e.date || '';
    const time = e.dateTime?.time?.slice(0, 5) || '';
    const venue = e.venue?.name || '';
    const status = e.status || '';
    const season = e.season || '';
    let s = `┏ *${home}* vs *${away}*\n`;
    if (hs !== null && hs !== undefined && as_ !== null && as_ !== undefined) s += `┃ 📊 Score: ${hs} - ${as_}\n`;
    if (date) s += `┃ 📅 ${date}${time ? ' ' + time : ''}\n`;
    if (venue) s += `┃ 🏟️ ${venue}\n`;
    if (status) s += `┃ 🔄 ${status}\n`;
    if (season) s += `┃ 📋 Season: ${season}\n`;
    s += `┗━━━━━━━━━━━━━━━\n`;
    return s;
  }).join('\n');
}
function fmtStandings(result) {
  const arr = result?.standings || (Array.isArray(result) ? result : []);
  if (!arr.length) return '_No standings data available_';
  const comp = result?.competition ? `${result.competition}\n\n` : '';
  const rows = arr.slice(0, 25).map(r => {
    const pos = String(r.position || '').padStart(2);
    const team = (r.team || r.name || '?').padEnd(28);
    const p = r.played ?? r.mp ?? 0;
    const w = r.won ?? r.w ?? 0;
    const d = r.draw ?? r.drawn ?? r.d ?? 0;
    const l = r.lost ?? r.l ?? 0;
    const pts = r.points ?? r.pts ?? 0;
    const gd = r.goalDifference ?? r.gd ?? '';
    return `${pos}. ${team} P${p} W${w} D${d} L${l}${gd !== '' ? ' GD' + gd : ''} | *${pts}pts*`;
  });
  return comp + rows.join('\n');
}
function fmtScorers(result) {
  const arr = result?.topScorers || result?.scorers || (Array.isArray(result) ? result : []);
  if (!arr.length) return '_No scorers data available_';
  const comp = result?.competition ? `${result.competition}\n\n` : '';
  const rows = arr.slice(0, 20).map((s, i) => {
    const rank = s.rank || s.position || i + 1;
    const player = s.player || s.name || s.strPlayer || '?';
    const team = s.team || s.club || '';
    const goals = s.goals ?? s.scored ?? s.numberOfGoals ?? '?';
    const assists = s.assists ?? '';
    let t = `*${rank}.* ⚽ ${player}${team ? ` (${team})` : ''}\n`;
    t += `    Goals: *${goals}*${s.matches !== undefined ? ` │ Apps: ${s.matches}` : ''}${assists !== '' ? ` │ Assists: ${assists}` : ''}\n`;
    return t;
  });
  return comp + rows.join('');
}
function fmtMatches(result) {
  const matches = result?.upcomingMatches || result?.matches || result?.fixtures || (Array.isArray(result) ? result : []);
  if (!matches.length) return '_No matches data available_';
  const comp = result?.competition ? `${result.competition}\n\n` : '';
  const rows = matches.slice(0, 15).map(m => {
    const home = m.homeTeam || m.home || m.team1 || '?';
    const away = m.awayTeam || m.away || m.team2 || '?';
    const score = m.score || (m.homeScore !== undefined ? `${m.homeScore} - ${m.awayScore}` : null);
    const date = m.date || m.utcDate || '';
    const day = m.matchday ? `MD${m.matchday}` : '';
    let s = `┏ ${home} vs ${away}\n`;
    if (score) s += `┃ 📊 ${score}\n`;
    if (day) s += `┃ 📋 ${day}\n`;
    if (date) s += `┃ 📅 ${date}\n`;
    s += `┗━━━━━━━━━━━━━━━\n`;
    return s;
  });
  return comp + rows.join('\n');
}
function fmtFifaUpcoming(result) {
  const matches = result?.upcomingMatches || (Array.isArray(result) ? result : []);
  if (!matches.length) return '_No upcoming FIFA World Cup matches found_';
  const comp = result?.competition ? `🌍 *${result.competition}*\n\n` : '';
  const rows = matches.map((m, i) => {
    const home = m.homeTeam || 'TBD';
    const away = m.awayTeam || 'TBD';
    const day = m.matchday && m.matchday !== 'N/A' ? `MD${m.matchday}` : '';
    const date = m.date || '';
    let s = `┏ *Match ${i + 1}*\n`;
    s += `┃ ⚔️ ${home} vs ${away}\n`;
    if (date) s += `┃ 📅 ${date}\n`;
    if (day) s += `┃ 📋 ${day}\n`;
    s += `┗━━━━━━━━━━━━━━━\n`;
    return s;
  });
  return comp + rows.join('\n');
}
function fmtFifaMatches(result) {
  const matches = result?.matches || (Array.isArray(result) ? result : []);
  if (!matches.length) return '_No FIFA World Cup match results found_';
  const comp = result?.competition ? `🌍 *${result.competition}*\n\n` : '';
  const rows = matches.map((m, i) => {
    const home = m.homeTeam || 'TBD';
    const away = m.awayTeam || 'TBD';
    const day = m.matchday ? `MD${m.matchday}` : '';
    const score = m.score || '';
    const status = m.status || '';
    const winner = m.winner || '';
    let s = `┏ *Match ${i + 1}*\n`;
    s += `┃ ⚔️ ${home} vs ${away}\n`;
    if (score) s += `┃ 📊 Score: *${score}*\n`;
    if (day) s += `┃ 📋 ${day}\n`;
    if (status) s += `┃ 🔄 ${status}\n`;
    if (winner) s += `┃ 🏆 ${winner === 'Draw' ? 'Draw' : `Winner: ${winner}`}\n`;
    s += `┗━━━━━━━━━━━━━━━\n`;
    return s;
  });
  return comp + rows.join('\n');
}
function fmtFifaStandings(result) {
  const standings = result?.standings || (Array.isArray(result) ? result : []);
  if (!standings.length) return '_No FIFA World Cup standings found_';
  const comp = result?.competition ? `🌍 *${result.competition}*\n\n` : '';
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let body = '';
  for (let i = 0; i < standings.length; i += 4) {
    const group = standings.slice(i, i + 4);
    const label = standings.length > 4 ? `🔷 *GROUP ${letters[Math.floor(i / 4)]}*\n` : '';
    body += label;
    body += `${'─'.repeat(46)}\n`;
    body += `  Team                   MP  W  D  L GF GA GD Pts\n`;
    body += `${'─'.repeat(46)}\n`;
    group.forEach((t, idx) => {
      const mark = idx < 2 ? '✅' : '❌';
      const name = (t.team || '?').padEnd(20);
      const mp = String(t.played ?? 0).padStart(2);
      const w = String(t.won ?? 0).padStart(2);
      const d = String(t.draw ?? 0).padStart(2);
      const l = String(t.lost ?? 0).padStart(2);
      const gf = String(t.goalsFor ?? 0).padStart(3);
      const ga = String(t.goalsAgainst ?? 0).padStart(3);
      const gd = String(t.goalDifference ?? 0).padStart(3);
      const pts = String(t.points ?? 0).padStart(3);
      body += `${mark} ${name}${mp} ${w} ${d} ${l}${gf}${ga}${gd}${pts}\n`;
    });
    body += '\n';
  }
  return comp + body.trim();
}
function fmtFifaScorers(result) {
  const scorers = result?.topScorers || (Array.isArray(result) ? result : []);
  if (!scorers.length) return '_No FIFA World Cup top scorers found_';
  const comp = result?.competition ? `🌍 *${result.competition}*\n\n` : '';
  const rows = scorers.map((s, i) => {
    const rank = s.rank || i + 1;
    const player = s.player || '?';
    const team = s.team || '';
    const goals = s.goals ?? '?';
    const assists = s.assists;
    const penalties = s.penalties;
    let t = `*${rank}.* ⚽ ${player}${team ? ` (${team})` : ''}\n`;
    t += `    Goals: *${goals}*`;
    if (assists !== undefined && assists !== 'N/A') t += ` │ Assists: ${assists}`;
    if (penalties !== undefined && penalties !== 'N/A') t += ` │ Penalties: ${penalties}`;
    t += '\n';
    return t;
  });
  return comp + rows.join('');
}
function fmtLivescore(result) {
  const gamesObj = result?.games || result;
  let games = Array.isArray(gamesObj) ? gamesObj : Object.values(gamesObj || {});
  if (!games.length) return '_No live games right now_';
  return games.slice(0, 20).map(g => {
    const home = g.homeTeam || g.p1 || g.home || '?';
    const away = g.awayTeam || g.p2 || g.away || '?';
    const s1 = g.teams?.home?.score ?? g.R?.r1 ?? g.homeScore ?? '';
    const s2 = g.teams?.away?.score ?? g.R?.r2 ?? g.awayScore ?? '';
    const status = g.status?.shortDetail || g.status || g.R?.st || '';
    const date = g.dateTime?.date || g.date || g.dt || '';
    const time = g.dateTime?.time?.slice(0, 5) || g.tm || '';
    let s = `┏ ${home} *${s1}* - *${s2}* ${away}\n`;
    if (status) s += `┃ ⏱ ${status}\n`;
    if (date) s += `┃ 📅 ${date}${time ? ' ' + time : ''}\n`;
    s += `┗━━━━━━━━━━━━━━━\n`;
    return s;
  }).join('\n');
}
function fmtLivescore2(result) {
  const list = result?.data?.list || result?.list || (Array.isArray(result) ? result : []);
  if (!list.length) return '_No live highlights right now_';
  return list.slice(0, 15).map(g => {
    const t1 = g.team1?.name || '?';
    const t2 = g.team2?.name || '?';
    const s1 = g.team1?.score ?? '';
    const s2 = g.team2?.score ?? '';
    const status = g.status || '';
    let s = `┏ ${t1} *${s1}* - *${s2}* ${t2}\n`;
    if (status) s += `┃ 🔴 ${status}\n`;
    if (g.playPath) s += `┃ 🎬 ${g.playPath}\n`;
    s += `┗━━━━━━━━━━━━━━━\n`;
    return s;
  }).join('\n');
}
function fmtNews(result) {
  const items = result?.data?.items || result?.items || (Array.isArray(result) ? result : []);
  if (!items.length) return '_No news available_';
  return items.slice(0, 10).map((n, i) => {
    const title = n.title || n.headline || '';
    const summary = n.summary || n.description || '';
    const date = n.date || (n.createdAt ? new Date(Number(n.createdAt)).toLocaleDateString() : '');
    let s = `*${i + 1}. ${title}*\n`;
    if (date) s += `📅 ${date}\n`;
    if (summary) s += `${String(summary).slice(0, 250)}\n`;
    return s + '\n';
  }).join('');
}
function fmtBet(result) {
  const arr = Array.isArray(result) ? result : result?.tips || result?.bets || [];
  if (!arr.length) return '_No bet tips available right now. Try again later._';
  return arr.slice(0, 15).map((b, i) => {
    const match = b.match || b.game || b.fixture || `Match ${i + 1}`;
    const tip = b.tip || b.prediction || b.pick || '';
    const odds = b.odds || b.odd || '';
    const conf = b.confidence || b.probability || '';
    let s = `*${i + 1}. ${match}*\n`;
    if (tip) s += `   🎯 Tip: ${tip}\n`;
    if (odds) s += `   💰 Odds: ${odds}\n`;
    if (conf) s += `   📊 Confidence: ${conf}\n`;
    return s;
  }).join('\n');
}

// ── League sub-command handler ─────────────────────────────────────────────────

async function leagueHandler(sock, msg, args, extra, label, endpoints) {
  const sub = (args[0] || '').toLowerCase();
  const validSubs = Object.keys(endpoints);
  if (!sub || !validSubs.includes(sub)) {
    return send(sock, msg, box(label, `Usage: .${extra.command} <option>\n\nOptions:\n` + validSubs.map(s => `• *${s}*`).join('\n')));
  }
  await react(sock, msg, '⏳');
  try {
    const {
      endpoint,
      format,
      title
    } = endpoints[sub];
    const result = await sportsApi(endpoint);
    const body = format(result);
    await sendLong(sock, msg, `┏━━『 ${label} — ${title} 』━━`, body);
    await react(sock, msg, '✅');
  } catch (err) {
    console.error(`[${label}/${sub}]`, err.message);
    await react(sock, msg, '❌');
    extra.reply(`❌ ${label} ${sub} failed: ${err.message}`);
  }
}

// ── Commands ───────────────────────────────────────────────────────────────────

module.exports = [
// ── 1. Player Search ───────────────────────────────────────────────────────
{
  name: 'playersearch',
  aliases: ['psearch', 'kplayer'],
  category: 'sports',
  description: 'Search for any sport player',
  usage: '.playersearch <player name>',
  async execute(sock, msg, args, extra) {
    const q = args.join(' ').trim();
    if (!q) return await extra.reply('❌ Provide a player name.\n\nExample: *.playersearch Bukayo Saka*');
    await react(sock, msg, '🔍');
    try {
      const result = await sportsApi('/sport/playersearch', {
        q
      });
      await sendLong(sock, msg, `┏━━『 🔍 Player Search: "${q}" 』━━`, fmtPlayers(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Search failed: ${err.message}`);
    }
  }
},
// ── 2. Team Search ─────────────────────────────────────────────────────────
{
  name: 'kteamsearch',
  aliases: ['tsearch', 'kteam'],
  category: 'sports',
  description: 'Search for any sport team',
  usage: '.kteamsearch <team name>',
  async execute(sock, msg, args, extra) {
    const q = args.join(' ').trim();
    if (!q) return await extra.reply('❌ Provide a team name.\n\nExample: *.kteamsearch Arsenal*');
    await react(sock, msg, '🔍');
    try {
      const result = await sportsApi('/sport/teamsearch', {
        q
      });
      await sendLong(sock, msg, `┏━━『 🔍 Team Search: "${q}" 』━━`, fmtTeams(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Search failed: ${err.message}`);
    }
  }
},
// ── 3. Venue Search ────────────────────────────────────────────────────────
{
  name: 'venuesearch',
  aliases: ['stadium', 'findvenue'],
  category: 'sports',
  description: 'Search for a stadium/venue',
  usage: '.venuesearch <venue name>',
  async execute(sock, msg, args, extra) {
    const q = args.join(' ').trim();
    if (!q) return await extra.reply('❌ Provide a venue name.\n\nExample: *.venuesearch Emirates*');
    await react(sock, msg, '🔍');
    try {
      const result = await sportsApi('/sport/venuesearch', {
        q
      });
      await sendLong(sock, msg, `┏━━『 🏟️ Venue Search: "${q}" 』━━`, fmtVenues(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Search failed: ${err.message}`);
    }
  }
},
// ── 4. Game Events / H2H ───────────────────────────────────────────────────
{
  name: 'gameevents',
  aliases: ['matchhistory', 'h2h'],
  category: 'sports',
  description: 'Game events/history between two teams',
  usage: '.gameevents <team vs team>',
  async execute(sock, msg, args, extra) {
    const q = args.join(' ').trim();
    if (!q) return await extra.reply('❌ Provide a match query.\n\nExample: *.gameevents Arsenal vs Chelsea*');
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/sport/gameevents', {
        q
      });
      await sendLong(sock, msg, `┏━━『 📋 Game Events: "${q}" 』━━`, fmtGameEvents(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed: ${err.message}`);
    }
  }
},
// ── 5. FIFA World Cup — Upcoming Matches ─────────────────────────────────
{
  name: 'fifaupcoming',
  aliases: ['wcupcoming', 'fifafixtures', 'worldcupfixtures'],
  category: 'sports',
  description: 'FIFA World Cup — upcoming matches',
  usage: '.fifaupcoming',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/fifa/upcomingmatches');
      await sendLong(sock, msg, `┏━━『 🌍 FIFA World Cup — Upcoming Matches 』━━`, fmtFifaUpcoming(result));
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[fifaupcoming]', err.message);
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed to fetch upcoming FIFA matches: ${err.message}`);
    }
  }
},
// ── 6. FIFA World Cup — Match Results ────────────────────────────────────
{
  name: 'fifamatches',
  aliases: ['wcmatches', 'fifaresults', 'worldcupresults'],
  category: 'sports',
  description: 'FIFA World Cup — match results',
  usage: '.fifamatches',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/fifa/matches');
      await sendLong(sock, msg, `┏━━『 🌍 FIFA World Cup — Match Results 』━━`, fmtFifaMatches(result));
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[fifamatches]', err.message);
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed to fetch FIFA match results: ${err.message}`);
    }
  }
},
// ── 7. FIFA World Cup — Standings ────────────────────────────────────────
{
  name: 'fifastandings',
  aliases: ['wcstandings', 'fifatable', 'worldcupstandings'],
  category: 'sports',
  description: 'FIFA World Cup — group standings',
  usage: '.fifastandings',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/fifa/standings');
      await sendLong(sock, msg, `┏━━『 🌍 FIFA World Cup — Standings 』━━`, fmtFifaStandings(result));
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[fifastandings]', err.message);
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed to fetch FIFA standings: ${err.message}`);
    }
  }
},
// ── 8. FIFA World Cup — Top Scorers ──────────────────────────────────────
{
  name: 'fifascorers',
  aliases: ['wcscorers', 'fifatopscorers', 'worldcupscorers'],
  category: 'sports',
  description: 'FIFA World Cup — top scorers',
  usage: '.fifascorers',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/fifa/scorers');
      await sendLong(sock, msg, `┏━━『 🌍 FIFA World Cup — Top Scorers 』━━`, fmtFifaScorers(result));
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[fifascorers]', err.message);
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed to fetch FIFA top scorers: ${err.message}`);
    }
  }
},
// ── 9. Live Score ─────────────────────────────────────────────────────────
{
  name: 'livescore',
  aliases: ['live', 'liveresults'],
  category: 'sports',
  description: 'Get current football live scores',
  usage: '.livescore',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/livescore');
      await sendLong(sock, msg, `┏━━『 🔴 LIVE SCORES 』━━`, fmtLivescore(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed: ${err.message}`);
    }
  }
},
// ── 10. Live Score + Highlights ────────────────────────────────────────────
{
  name: 'livehighlights',
  aliases: ['livescore2', 'livehl'],
  category: 'sports',
  description: 'Get live scores and available match highlight links',
  usage: '.livehighlights',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/livescore2');
      await sendLong(sock, msg, `┏━━『 🔴 LIVE SCORES + HIGHLIGHTS 』━━`, fmtLivescore2(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed: ${err.message}`);
    }
  }
},
// ── 11. Premier League ───────────────────────────────────────────────────
{
  name: 'epl',
  aliases: ['premierleague', 'pl'],
  category: 'sports',
  description: 'EPL — upcoming, matches, standings, scorers',
  usage: '.epl <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '⚽ Premier League', {
      upcoming: {
        endpoint: '/epl/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/epl/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/epl/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/epl/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 12. Bundesliga ───────────────────────────────────────────────────────
{
  name: 'bundesliga',
  aliases: ['bund', 'germansoccer'],
  category: 'sports',
  description: 'Bundesliga — upcoming, matches, standings, scorers',
  usage: '.bundesliga <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '🇩🇪 Bundesliga', {
      upcoming: {
        endpoint: '/bundesliga/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/bundesliga/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/bundesliga/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/bundesliga/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 13. Euros ────────────────────────────────────────────────────────────
{
  name: 'euros',
  aliases: ['eurocup', 'euro'],
  category: 'sports',
  description: 'Euros — upcoming, matches, standings, scorers',
  usage: '.euros <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '🏆 Euros', {
      upcoming: {
        endpoint: '/euros/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/euros/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/euros/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/euros/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 14. La Liga ──────────────────────────────────────────────────────────
{
  name: 'laliga',
  aliases: ['ll', 'spanishleague'],
  category: 'sports',
  description: 'La Liga — upcoming, matches, standings, scorers',
  usage: '.laliga <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '🇪🇸 La Liga', {
      upcoming: {
        endpoint: '/laliga/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/laliga/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/laliga/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/laliga/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 15. Ligue 1 ──────────────────────────────────────────────────────────
{
  name: 'ligue1',
  aliases: ['ligue', 'frenchleague'],
  category: 'sports',
  description: 'Ligue 1 — upcoming, matches, standings, scorers',
  usage: '.ligue1 <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '🇫🇷 Ligue 1', {
      upcoming: {
        endpoint: '/ligue1/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/ligue1/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/ligue1/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/ligue1/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 16. Serie A ──────────────────────────────────────────────────────────
{
  name: 'seriea',
  aliases: ['seria', 'italianleague'],
  category: 'sports',
  description: 'Serie A — upcoming, matches, standings, scorers',
  usage: '.seriea <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '🇮🇹 Serie A', {
      upcoming: {
        endpoint: '/seriea/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/seriea/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/seriea/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/seriea/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 17. UCL Champions League ─────────────────────────────────────────────
{
  name: 'ucl',
  aliases: ['championsleague', 'cl'],
  category: 'sports',
  description: 'UCL Champions League — upcoming, matches, standings, scorers',
  usage: '.ucl <upcoming|matches|standings|scorers>',
  async execute(sock, msg, args, extra) {
    await leagueHandler(sock, msg, args, extra, '🏆 UCL Champions League', {
      upcoming: {
        endpoint: '/ucl/upcomingmatches',
        format: fmtMatches,
        title: 'Upcoming Matches'
      },
      matches: {
        endpoint: '/ucl/matches',
        format: fmtMatches,
        title: 'Matches'
      },
      standings: {
        endpoint: '/ucl/standings',
        format: fmtStandings,
        title: 'Standings'
      },
      scorers: {
        endpoint: '/ucl/scorers',
        format: fmtScorers,
        title: 'Top Scorers'
      }
    });
  }
},
// ── 18. Sure Bet Tips ────────────────────────────────────────────────────
{
  name: 'bet',
  aliases: ['surebets', 'bettips', 'betodds'],
  category: 'sports',
  description: 'Get betting tips when a verified odds provider is configured',
  usage: '.bet',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/bet');
      await sendLong(sock, msg, `┏━━『 🎰 Betting Tips 』━━`, fmtBet(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed: ${err.message}`);
    }
  }
},
// ── 19. Football News ────────────────────────────────────────────────────
{
  name: 'footballnews',
  aliases: ['fnews', 'sportnews'],
  category: 'sports',
  description: 'Get latest football news',
  usage: '.footballnews',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '⏳');
    try {
      const result = await sportsApi('/football/news');
      await sendLong(sock, msg, `┏━━『 📰 Football News 』━━`, fmtNews(result));
      await react(sock, msg, '✅');
    } catch (err) {
      await react(sock, msg, '❌');
      await extra.reply(`❌ Failed: ${err.message}`);
    }
  }
}];
