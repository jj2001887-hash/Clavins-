const axios = require('axios');
const { igdl } = require('ruhend-scraper');
const config = require('../../config');
const processedMessages = new Set();
const INSTAGRAM_URL = /https?:\/\/(?:www\.|m\.)?(?:instagram\.com|instagr\.am)\/(?:p|reel|reels|tv)\/[A-Za-z0-9_-]+[^\s]*/i;
const BRAND = 'TALKLESS XMD';

function uniqueMedia(items) {
  const seen = new Set();
  return (items || []).filter(item => {
    const url = typeof item === 'string' ? item : item?.url;
    if (!url || seen.has(url)) return false;
    seen.add(url);
    return true;
  }).map(item => typeof item === 'string' ? { url: item } : item);
}

async function fetchApiFallback(postUrl) {
  const providers = [
    async () => {
      const { data } = await axios.get('https://www.sankavollerei.web.id/download/instagram', {
        params: { apikey: process.env.INSTAGRAM_API_KEY || '', url: postUrl }, timeout: 15000
      });
      const media = data?.result?.media;
      if (!data?.status || !Array.isArray(media) || !media.length) return null;
      return { title: data.result.caption || '', items: media.map(item => ({ url: item.url, type: item.type })) };
    },
    async () => {
      const { data } = await axios.get('https://api.siputzx.my.id/api/d/igdl', {
        params: { url: postUrl }, timeout: 15000
      });
      const raw = Array.isArray(data?.data) ? data.data : (data?.data ? [data.data] : []);
      const items = raw.map(item => ({ url: item?.url || item?.download_url, type: item?.type, title: item?.title || item?.caption }));
      return items.some(item => item.url) ? { items } : null;
    },
    async () => {
      const { data } = await axios.get('https://api-faa.my.id/faa/igdl', { params: { url: postUrl }, timeout: 15000 });
      const link = data?.result?.hd || data?.result?.sd || data?.result?.download || data?.result?.url;
      return link ? { title: data.result.title || '', items: [{ url: link, type: 'video' }] } : null;
    },
    async () => {
      const { data } = await axios.get('https://api.azbry.com/api/download/ig', { params: { url: postUrl }, timeout: 15000 });
      const link = data?.result?.download || data?.result?.url;
      return link ? { title: data.result.title || '', items: [{ url: link, type: 'video' }] } : null;
    }
  ];
  for (const provider of providers) {
    try {
      const result = await provider();
      if (result?.items?.some(item => item.url)) return result;
    } catch (error) {
      console.warn('[instagram] fallback provider failed:', error.message);
    }
  }
  return null;
}

module.exports = {
  name: 'instagram',
  aliases: ['ig', 'insta', 'igdl', 'reels'],
  category: 'media',
  description: 'Download Instagram photos, videos, and reels',
  usage: '.ig <Instagram URL>',
  async execute(sock, msg, args, extra) {
    const chatId = extra.from;
    if (processedMessages.has(msg.key.id)) return;
    processedMessages.add(msg.key.id);
    setTimeout(() => processedMessages.delete(msg.key.id), 5 * 60 * 1000);
    const messageText = [args.join(' '), msg.message?.conversation, msg.message?.extendedTextMessage?.text].filter(Boolean).join(' ');
    const postUrl = messageText.match(INSTAGRAM_URL)?.[0];
    if (!postUrl) return extra.reply(`❌ Provide a public Instagram post, reel, or TV link.\nExample: ${config.prefix || '.'}ig https://www.instagram.com/reel/...`);
    await extra.react?.('📥');
    try {
      let result = null;
      try {
        const scraped = await igdl(postUrl);
        const items = uniqueMedia(scraped?.data || []);
        if (items.length) result = { items };
      } catch (error) {
        console.warn('[instagram] primary scraper failed:', error.message);
      }
      if (!result) result = await fetchApiFallback(postUrl);
      if (!result?.items?.length) throw new Error('No downloadable media found; the post may be private, removed, or unsupported.');
      const items = uniqueMedia(result.items).slice(0, 20);
      for (let index = 0; index < items.length; index++) {
        const item = items[index];
        const url = item.url || item.download_url;
        if (!url) continue;
        const isVideo = item.type === 'video' || /\.(mp4|mov|webm)(?:\?|$)/i.test(url) || /\/(reel|reels|tv)\//i.test(postUrl);
        const caption = `*DOWNLOADED BY ${BRAND}*${result.title ? `\n${result.title}` : ''}`;
        await sock.sendMessage(chatId, isVideo
          ? { video: { url }, mimetype: 'video/mp4', caption }
          : { image: { url }, caption }, { quoted: msg });
        if (index < items.length - 1) await new Promise(resolve => setTimeout(resolve, 800));
      }
      await extra.react?.('✅');
    } catch (error) {
      console.error('[instagram] download error:', error.message);
      await extra.react?.('❌');
      await extra.reply(`❌ Instagram download failed. ${error.message}`);
    }
  }
};
