/**
 * TALKLESS XMD MUSIC — .play <song name | YouTube link>
 *
 * Fast path:
 *   1. search (Omegatech + YouTube asked at the same time, first answer wins)
 *   2. song card (thumbnail + title) is sent immediately
 *   3. every download provider is asked at once, first one wins (cached 30 min)
 *   4. audio is sent by URL (no temp file); falls back to a buffer, then a document
 */
const axios = require('axios');
const config = require('../../config');
const { resolveAudio, ytSearch, any } = require('../../utils/fastDownload');
const { box } = require('../../utils/box');

const SEARCH_API = 'https://api.omegatech.app/api/Search/searchthatsong';
const MAX_SECONDS = 30 * 60;   // keep it quick: skip anything longer than 30 min

async function searchOmegatech(query) {
  const r = await axios.get(SEARCH_API, { params: { action: 'search', query }, timeout: 5000 });
  const d = r.data;
  if (!d?.success || !d?.data?.youtubeUrl) throw new Error('omegatech: no result');
  return { url: d.data.youtubeUrl, title: d.data.song || query, artist: d.data.artist || '', preview: d.data.previewUrl || null };
}

const ytId = u => (String(u).match(/(?:youtu\.be\/|v=|shorts\/)([A-Za-z0-9_-]{11})/) || [])[1];

async function findSong(query) {
  const id = ytId(query);
  if (/^https?:\/\//i.test(query) && id) {
    try {
      const yts = require('yt-search');
      const v = await yts({ videoId: id });
      if (v?.title) return { url: `https://youtu.be/${id}`, title: v.title, artist: v.author?.name || '', duration: v.timestamp || '', seconds: v.seconds || 0, thumb: v.thumbnail };
    } catch (_) {}
    const r = await axios.get('https://api.omegatech.app/api/download/YouTube', {
      params: { action: 'resolve', url: query, type: 'audio' },
      timeout: 20000
    });
    const data = r.data?.data;
    if (!r.data?.success || !data?.title) throw new Error('Could not read that link');
    return { url: `https://youtu.be/${id}`, title: data.title, artist: data.channel || '', duration: data.durationLabel || '', seconds: Number(data.duration) || 0, thumb: data.thumbnail || '' };
  }
  return any([
    searchOmegatech(query),
    ytSearch(query).then(v => ({ url: v.url, title: v.title, artist: v.author?.name || '', duration: v.timestamp || '', seconds: v.seconds || 0, thumb: v.thumbnail }))
  ]);
}

async function sendAudio(sock, chatId, url, title, msg) {
  try {
    await sock.sendMessage(chatId, { audio: { url }, mimetype: 'audio/mpeg', ptt: false, fileName: `${title}.mp3` }, { quoted: msg });
    return;
  } catch (e) { /* link not fetchable by WhatsApp: pull it ourselves */ }
  const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 60000, headers: { 'User-Agent': 'Mozilla/5.0' } });
  const buf = Buffer.from(r.data);
  try {
    await sock.sendMessage(chatId, { audio: buf, mimetype: 'audio/mpeg', ptt: false }, { quoted: msg });
  } catch (_) {
    await sock.sendMessage(chatId, { document: buf, mimetype: 'audio/mpeg', fileName: `${title.replace(/[^\w\s.-]/g, '').slice(0, 80)}.mp3` }, { quoted: msg });
  }
}

async function fallbackSpotifyAudio(song) {
  const query = [song.artist, song.title].filter(Boolean).join(' - ');
  if (!query) throw new Error('No track title for Spotify fallback');
  const response = await axios.get('https://api.nexray.eu.cc/downloader/spotifyplay', {
    params: { q: query },
    timeout: 45000,
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const result = response.data?.result;
  if (!response.data?.status || !result?.download_url) {
    throw new Error('Spotify fallback returned no audio URL');
  }
  return { download: result.download_url, title: result.title || song.title };
}

module.exports = {
  name: 'play',
  aliases: ['song', 'yta', 'music', 'tmusic'],
  category: 'media',
  description: 'TALKLESS XMD MUSIC: search a song and get it fast',
  usage: '.play <song name or YouTube link>',
  async execute(sock, msg, args, extra) {
    const chatId = extra.from;
    const prefix = config.prefix || '.';
    let query = args.join(' ').trim();
    if (!query) {
      const q = extra?.quoted;
      query = q?.conversation || q?.extendedTextMessage?.text || '';
    }
    if (!query) {
      return extra.reply(box('🎵 TALKLESS XMD MUSIC', `Type a song name\ne.g. ${prefix}play faded\n\nYouTube links work too.`));
    }
    if (query.length > 200) return extra.reply('📝 That is too long (max 200 characters).');

    await extra.react?.('🎼');
    try {
      const song = await findSong(query).catch(() => null);
      if (!song) {
        await extra.react?.('❌');
        return extra.reply(box('🎵 TALKLESS XMD MUSIC', 'No song found.\nTry the title + artist.'));
      }
      if (song.seconds && song.seconds > MAX_SECONDS) {
        await extra.react?.('❌');
        return extra.reply(box('🎵 TALKLESS XMD MUSIC', 'That track is over 30 min.\nPick a shorter one.'));
      }

      // start downloading NOW, while the card is being sent
      const audioP = resolveAudio(song.url);
      audioP.catch(() => {});

      const id = ytId(song.url);
      const thumb = song.thumb || (id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : null);
      const rows = [`🎶 ${song.title}`];
      if (song.artist) rows.push(`👤 ${song.artist}`);
      if (song.duration) rows.push(`⏱️ ${song.duration}`);
      rows.push('⬇️ Sending audio…');
      const card = box('🎵 TALKLESS XMD MUSIC', rows.join('\n'), `Powered by ${config.poweredBy || 'TALKLESS TECH'}`);
      const cardP = (thumb
        ? sock.sendMessage(chatId, { image: { url: thumb }, caption: card }, { quoted: msg }).catch(() => sock.sendMessage(chatId, { text: card }, { quoted: msg }))
        : sock.sendMessage(chatId, { text: card }, { quoted: msg })).catch(() => {});

      let audio = await audioP.catch(() => null);
      // Use a separate music source if the YouTube audio providers fail.
      if (!audio?.download) {
        audio = await fallbackSpotifyAudio(song).catch(error => {
          console.warn('[TALKLESS XMD MUSIC] Spotify fallback failed:', error.message);
          return null;
        });
      }
      await cardP;
      if (!audio?.download) {
        await extra.react?.('❌');
        return extra.reply(box('🎵 TALKLESS XMD MUSIC', 'Song found but the download\nfailed. Please try again.'));
      }
      await sendAudio(sock, chatId, audio.download, audio.title || song.title, msg);
      await extra.react?.('✅');
    } catch (e) {
      console.error('[TALKLESS XMD MUSIC] error:', e.message);
      await extra.react?.('❌');
      await extra.reply(box('🎵 TALKLESS XMD MUSIC', 'Something went wrong.\nTry another search.'));
    }
  }
};
