const axios = require('axios');
const config = require('../../config');

const SEARCH_API = 'https://api.omegatech.app/api/Search/searchthatsong';
module.exports = {
  name: 'songsearch',
  aliases: ['findsong', 'musicsearch'],
  category: 'media',
  description: 'Find song details, a preview, and matching lyric excerpts',
  usage: '.songsearch <song, artist, or lyric phrase>',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply(`🎵 Usage: ${config.prefix || '.'}songsearch <song, artist, or lyric phrase>`);
    try {
      const response = await axios.get(SEARCH_API, {
        params: { action: 'search', query },
        timeout: 20000
      });
      const body = response.data;
      const song = body?.success ? body.data : null;
      if (!song) return extra.reply('❌ No matching song was found. Try a shorter title or lyric phrase.');
      const source = song.webSources?.[0];
      const caption = [
        `🎵 *${song.song || 'Unknown song'}*`,
        `👤 *Artist:* ${song.artist || 'Unknown'}`,
        song.album ? `💿 *Album:* ${song.album}` : null,
        song.year && song.year !== 'n/a' ? `📅 *Year:* ${song.year}` : null,
        song.queryType ? `🔎 *Match:* ${song.queryType.replace(/_/g, ' ')}` : null,
        song.relevantChunk ? `\n📝 *Matching lyric excerpt:*\n_${song.relevantChunk}_` : null,
        source?.url ? `\n🔗 *Source:* ${source.url}` : null,
        song.youtubeUrl ? `▶️ *YouTube:* ${song.youtubeUrl}` : null,
        `\n_Found by ${config.botName}_`
      ].filter(Boolean).join('\n');
      if (song.albumArtwork) {
        await sock.sendMessage(extra.from, { image: { url: song.albumArtwork }, caption }, { quoted: msg });
      } else {
        await sock.sendMessage(extra.from, { text: caption }, { quoted: msg });
      }
      if (song.previewUrl) {
        await sock.sendMessage(extra.from, {
          audio: { url: song.previewUrl },
          mimetype: 'audio/mpeg',
          ptt: false,
          caption: '🎧 Song preview'
        }, { quoted: msg });
      }
    } catch (error) {
      console.error('[songsearch] error:', error.message);
      await extra.reply('❌ Song search is unavailable right now. Please try again later.');
    }
  }
};
