'use strict';

const { createImageCommand } = require('../../utils/animeApi');

module.exports = [
  createImageCommand({
    name: 'waifu', aliases: ['randomwaifu'], imageCategory: 'waifu', emoji: '✨',
    description: 'Get a random SFW anime waifu image', usage: '.waifu', caption: '✨ *Random SFW Anime Art*'
  }),
  createImageCommand({
    name: 'neko', aliases: ['catgirl', 'nekogirl'], imageCategory: 'neko', emoji: '🐱',
    description: 'Get a random SFW neko image', usage: '.neko', caption: '🐱 *Random SFW Neko*'
  }),
  createImageCommand({
    name: 'loli', aliases: ['animeloli'], imageCategory: 'neko', emoji: '🌸',
    description: 'Get a random SFW anime image', usage: '.loli', caption: '🌸 *Random SFW Anime Image*'
  }),
  createImageCommand({
    name: 'shota', aliases: ['animeshota'], imageCategory: 'neko', emoji: '🌸',
    description: 'Get a random SFW anime image', usage: '.shota', caption: '🌸 *Random SFW Anime Image*'
  }),
  createImageCommand({
    name: 'husby', aliases: ['husband', 'husbando'], imageCategory: 'husbando', emoji: '💙',
    description: 'Get a random SFW anime husbando image', usage: '.husby', caption: '💙 *Random SFW Anime Art*'
  })
];
