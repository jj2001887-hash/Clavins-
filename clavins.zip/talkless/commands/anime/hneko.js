'use strict';
const { createImageCommand } = require('../../utils/animeApi');
module.exports = createImageCommand({
  name: 'hneko', aliases: ['hnekonsfw'], imageCategory: 'neko', emoji: '🐱',
  description: 'Get a random SFW neko anime image', usage: '.hneko', caption: '🐱 *Random SFW Neko*'
});
