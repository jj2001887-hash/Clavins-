'use strict';
const { createImageCommand } = require('../../utils/animeApi');
module.exports = createImageCommand({
  name: 'konachan', aliases: ['konachansfw'], imageCategory: 'kitsune', emoji: '🦊',
  description: 'Get a random SFW anime illustration', usage: '.konachan', caption: '🦊 *Random SFW Anime Illustration*'
});
