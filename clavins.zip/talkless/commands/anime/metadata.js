'use strict';

const animeApi = require('../../utils/animeApi');
const send = (sock, msg, text) => sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });

module.exports = [
  {
    name: 'animeinfo', aliases: ['anime'], category: 'anime',
    description: 'Get anime details by title or ID', usage: '.animeinfo <title|ID|URL>',
    async execute(sock, msg, args, extra = {}) {
      if (!args.length) return send(sock, msg, 'Usage: .animeinfo <title|AniList ID|MyAnimeList ID>\nExample: .animeinfo Frieren');
      try {
        if (typeof extra.react === 'function') await extra.react('🔎');
        const item = await animeApi.getAnimeInfo(args.join(' ').trim());
        if (!item) throw new Error('No matching anime was found.');
        const text = animeApi.formatAnime(item);
        if (item.image) {
          try { await sock.sendMessage(msg.key.remoteJid, { image: { url: item.image }, caption: text }, { quoted: msg }); }
          catch (_) { await send(sock, msg, text); }
        } else await send(sock, msg, text);
        if (typeof extra.react === 'function') await extra.react('✅');
      } catch (error) {
        if (typeof extra.react === 'function') await extra.react('❌');
        if (typeof extra.reply === 'function') await extra.reply(`❌ Anime lookup failed: ${error.message}`);
      }
    }
  },
  {
    name: 'animefind', aliases: ['animequery'], category: 'anime',
    description: 'Search anime titles', usage: '.animefind <title>',
    async execute(sock, msg, args, extra = {}) {
      if (!args.length) return send(sock, msg, 'Usage: .animefind <title>\nExample: .animefind Frieren');
      const query = args.join(' ').trim();
      try {
        if (typeof extra.react === 'function') await extra.react('🔎');
        const results = await animeApi.searchAnime(query);
        if (!results.length) return send(sock, msg, `No anime found for “${query}”.`);
        const lines = results.slice(0, 5).map((item, i) => {
          const parts = [`${i + 1}. *${item.title}*`];
          if (item.year) parts.push(`📅 ${item.year}`);
          if (item.format) parts.push(`📺 ${item.format}`);
          if (item.score) parts.push(`⭐ ${item.score}/10`);
          let line = parts.join(' · ');
          if (item.url) line += `\n${item.url}`;
          return line;
        });
        await send(sock, msg, `🔎 *Anime search: ${query}*\n\n${lines.join('\n\n')}\n\nUse .animeinfo <title> for details.`);
        if (typeof extra.react === 'function') await extra.react('✅');
      } catch (error) {
        if (typeof extra.react === 'function') await extra.react('❌');
        if (typeof extra.reply === 'function') await extra.reply(`❌ Anime search failed: ${error.message}`);
      }
    }
  },
  {
    name: 'topanime', aliases: ['animetop'], category: 'anime',
    description: 'List top-rated anime', usage: '.topanime [page]',
    async execute(sock, msg, args, extra = {}) {
      const page = Math.max(1, Math.min(100, parseInt(args[0], 10) || 1));
      try {
        if (typeof extra.react === 'function') await extra.react('🏆');
        const results = await animeApi.getTopAnime(page);
        if (!results.length) throw new Error('The anime API returned no top anime.');
        const lines = results.slice(0, 10).map((item, i) => {
          const rank = (page - 1) * 10 + i + 1;
          return `${rank}. *${item.title}*${item.year ? ` (${item.year})` : ''}${item.score ? ` — ⭐ ${item.score}/10` : ''}${item.url ? `\n   ${item.url}` : ''}`;
        });
        await send(sock, msg, `🏆 *Top Anime — Page ${page}*\n\n${lines.join('\n\n')}`);
        if (typeof extra.react === 'function') await extra.react('✅');
      } catch (error) {
        if (typeof extra.react === 'function') await extra.react('❌');
        if (typeof extra.reply === 'function') await extra.reply(`❌ Top anime lookup failed: ${error.message}`);
      }
    }
  }
];
