'use strict';
const { createImageCommand } = require('../../utils/animeApi');
module.exports = createImageCommand({
  name: 'milf', aliases: ['milfnsfw'], imageCategory: 'waifu', emoji: '🌸',
  description: 'Get a random SFW anime woman illustration', usage: '.milf', caption: '🌸 *Random SFW Anime Art*'
});
