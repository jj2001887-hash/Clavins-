'use strict';
const { createImageCommand } = require('../../utils/animeApi');
module.exports = createImageCommand({
  name: 'megumin', aliases: ['meguminnsfw'], imageCategory: 'megumin', emoji: '💥',
  description: 'Get a random SFW anime image', usage: '.megumin', caption: '💥 *Random SFW Anime Art*'
});
