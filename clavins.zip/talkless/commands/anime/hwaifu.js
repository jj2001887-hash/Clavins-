'use strict';
const { createImageCommand } = require('../../utils/animeApi');
module.exports = createImageCommand({
  name: 'hwaifu', aliases: ['hwaifunsfw'], imageCategory: 'waifu', emoji: '✨',
  description: 'Get a random SFW anime waifu image', usage: '.hwaifu', caption: '✨ *Random SFW Anime Art*'
});
