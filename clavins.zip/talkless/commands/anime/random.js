'use strict';

const animeApi = require('../../utils/animeApi');

module.exports = {
  name: 'random',
  aliases: ['animerandom', 'randomanime'],
  category: 'anime',
  description: 'Show a random non-adult anime from AniList/Jikan',
  usage: '.random',
  async execute(sock, msg, args, extra = {}) {
    try {
      if (typeof extra.react === 'function') await extra.react('🎲');
      const anime = await animeApi.getRandomAnime();
      const caption = animeApi.formatAnime(anime);
      if (anime.image) {
        try {
          await sock.sendMessage(msg.key.remoteJid, { image: { url: anime.image }, caption }, { quoted: msg });
        } catch (_) {
          await sock.sendMessage(msg.key.remoteJid, { text: caption }, { quoted: msg });
        }
      } else {
        await sock.sendMessage(msg.key.remoteJid, { text: caption }, { quoted: msg });
      }
      if (typeof extra.react === 'function') await extra.react('✅');
    } catch (error) {
      if (typeof extra.react === 'function') await extra.react('❌');
      if (typeof extra.reply === 'function') await extra.reply(`❌ Could not get random anime: ${error.message}`);
    }
  }
};
