// Keep the legacy general-category path, but use the single hardened fun handler.
// Re-exporting the same command object prevents cross-category alias collisions.
module.exports = require('../fun/memesearch');
