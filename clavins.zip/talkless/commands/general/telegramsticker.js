const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const ffmpegPath = require('../../utils/ffmpegPath');
const config = require('../../config');
const { getTempDir, deleteTempFile } = require('../../utils/tempManager');
const { sendPack, PACK_LIMIT, delay } = require('../../utils/stickerPack');

let appSettings = {};
try { appSettings = require('../../../settings'); } catch (_) {}
const TG_TOKEN = () => String(process.env.TELEGRAM_TOKEN || appSettings.TELEGRAM_TOKEN || config.telegramToken || '').trim();

const CONCURRENCY = 4;
const MAX_STICKERS = 250;
const MAX_WEBP_BYTES = 900 * 1024;           // WhatsApp rejects animated stickers around 1 MB

/** Accepts t.me/addstickers/X, t.me/addemoji/X, tg://addstickers?set=X or just the pack name. */
function parsePackName(input) {
  const s = String(input || '').trim();
  let m = s.match(/(?:t\.me|telegram\.me|telegram\.dog)\/(?:addstickers|addemoji)\/([A-Za-z0-9_]+)/i);
  if (m) return m[1];
  m = s.match(/^tg:\/\/(?:addstickers|addemoji)\?set=([A-Za-z0-9_]+)/i);
  if (m) return m[1];
  if (/^[A-Za-z0-9_]{3,64}$/.test(s)) return s;
  return null;
}

async function tgApi(method, params = {}, tries = 4) {
  const token = TG_TOKEN();
  if (!token) throw new Error('Telegram bot token is not configured (TELEGRAM_TOKEN).');
  const qs = new URLSearchParams(params).toString();
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/${method}?${qs}`, { timeout: 30000 });
      const data = await res.json();
      if (data.ok) return data.result;
      if (data.error_code === 429) { await delay(((data.parameters && data.parameters.retry_after) || 2) * 1000 + 300); continue; }
      throw new Error(data.description || `Telegram error ${data.error_code}`);
    } catch (e) {
      lastErr = e;
      if (/not found|invalid|bad request/i.test(e.message)) break;
      await delay(600 * (i + 1));
    }
  }
  throw lastErr;
}

async function downloadFile(fileId) {
  const info = await tgApi('getFile', { file_id: fileId });
  const url = `https://api.telegram.org/file/bot${TG_TOKEN()}/${info.file_path}`;
  let lastErr;
  for (let i = 0; i < 3; i++) {
    try {
      const res = await fetch(url, { timeout: 45000 });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return { buf: await res.buffer(), filePath: info.file_path || '' };
    } catch (e) { lastErr = e; await delay(700 * (i + 1)); }
  }
  throw lastErr;
}

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    const ff = spawn(ffmpegPath, args);
    const errs = [];
    ff.stderr.on('data', d => errs.push(d));
    ff.on('error', reject);
    ff.on('close', code => code === 0 ? resolve() : reject(new Error(Buffer.concat(errs).toString().slice(-200))));
  });
}

/** Static image → 512x512 transparent-padded webp. */
async function staticToWebp(buf) {
  try {
    const sharp = require('sharp');
    return await sharp(buf).resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp({ quality: 85 }).toBuffer();
  } catch (_) {
    return buf;                               // Telegram static stickers are already webp
  }
}

/** .webm video sticker → animated webp under the WhatsApp size limit. */
async function videoToWebp(buf, tmpDir, id) {
  const input = path.join(tmpDir, `tg_in_${id}.webm`);
  const output = path.join(tmpDir, `tg_out_${id}.webp`);
  fs.writeFileSync(input, buf);
  try {
    for (const [q, fps] of [[65, 15], [45, 12], [30, 10], [20, 8]]) {
      await runFfmpeg(['-y', '-c:v', 'libvpx-vp9', '-i', input, '-vf',
        `scale=512:512:force_original_aspect_ratio=decrease,fps=${fps},pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000`,
        '-c:v', 'libwebp', '-lossless', '0', '-q:v', String(q), '-loop', '0', '-vsync', '0', '-pix_fmt', 'yuva420p', '-an', '-t', '6', output])
        .catch(() => runFfmpeg(['-y', '-i', input, '-vf',
          `scale=512:512:force_original_aspect_ratio=decrease,fps=${fps},pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000`,
          '-c:v', 'libwebp', '-lossless', '0', '-q:v', String(q), '-loop', '0', '-vsync', '0', '-pix_fmt', 'yuva420p', '-an', '-t', '6', output]));
      const out = fs.readFileSync(output);
      if (out.length <= MAX_WEBP_BYTES) return out;
    }
    throw new Error('animated sticker too large after compression');
  } finally {
    try { deleteTempFile(input); } catch (_) {}
    try { deleteTempFile(output); } catch (_) {}
  }
}

async function mapPool(items, limit, fn) {
  const results = new Array(items.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) { const i = next++; results[i] = await fn(items[i], i); }
  }));
  return results;
}

module.exports = {
  name: 'telegramsticker',
  aliases: ['tgs', 'tgms', 'tgsticker', 'tgpack', 'tgstickers'],
  category: 'general',
  description: 'Fetch a whole Telegram sticker pack and send it as a WhatsApp sticker pack',
  usage: '.tgs <t.me/addstickers/PackName | PackName> [single]',
  async execute(sock, msg, args, extra) {
    const { from, reply } = extra;
    const forceSingle = args.slice(1).some(a => /^(single|one|each|separate)$/i.test(a));
    const packName = parsePackName(args[0]);

    if (!args[0]) {
      return reply(`📦 *Telegram Sticker Pack*\n\nFetches the *whole* pack and sends it as WhatsApp sticker pack(s) of up to ${PACK_LIMIT} stickers.\n\n*Usage*\n.tgs https://t.me/addstickers/PackName\n.tgs PackName\n.tgs PackName single  (send them one by one)`);
    }
    if (!packName) return reply('❌ That is not a Telegram sticker pack link.\nUse: _https://t.me/addstickers/PackName_');
    if (!TG_TOKEN()) return reply('❌ Telegram token is not configured on this bot (set TELEGRAM_TOKEN).');

    let set;
    try { set = await tgApi('getStickerSet', { name: packName }); }
    catch (e) { return reply(`❌ Could not fetch that pack.\n${e.message}\n\nCheck that the link is correct and the pack is public.`); }

    const title = set.title || packName;
    const list = set.stickers.slice(0, MAX_STICKERS);
    const total = list.length;
    const lottie = list.filter(s => s.is_animated && !s.is_video).length;

    const sent0 = await sock.sendMessage(from, {
      text: `📦 *${title}*\n🎯 ${total} stickers found${set.stickers.length > MAX_STICKERS ? ` (first ${MAX_STICKERS})` : ''}\n⏳ Downloading…`
    }, { quoted: msg });
    const statusKey = sent0 && sent0.key;
    const editStatus = async text => {
      if (!statusKey) return;
      try { await sock.sendMessage(from, { edit: statusKey, text }); } catch (_) {}
    };

    const tmpDir = getTempDir();
    let done = 0, failed = 0, previews = 0;
    const stamp = Date.now();

    const converted = await mapPool(list, CONCURRENCY, async (st, i) => {
      try {
        let fileId = st.file_id, asPreview = false;
        if (st.is_animated && !st.is_video) {            // Lottie .tgs can't be rendered: use Telegram's static preview
          const th = st.thumbnail || st.thumb;
          if (!th) throw new Error('no preview for animated sticker');
          fileId = th.file_id; asPreview = true;
        }
        const { buf, filePath } = await downloadFile(fileId);
        const isVideo = !asPreview && (st.is_video || /\.webm$/i.test(filePath));
        const data = isVideo ? await videoToWebp(buf, tmpDir, `${stamp}_${i}`) : await staticToWebp(buf);
        if (asPreview) previews++;
        return { data, emojis: [st.emoji || '🙂'] };
      } catch (e) {
        failed++;
        console.error(`[TGS] sticker ${i + 1} failed:`, e.message);
        return null;
      } finally {
        done++;
        if (done % 10 === 0 || done === total) await editStatus(`📦 *${title}*\n⬇️ Downloaded ${done}/${total}${failed ? `  ⚠️ ${failed} failed` : ''}`);
      }
    });

    const stickers = converted.filter(Boolean);
    if (!stickers.length) {
      await editStatus(`❌ *${title}*\nNo sticker could be converted.`);
      return;
    }

    await editStatus(`📦 *${title}*\n📤 Building sticker pack (${stickers.length} stickers)…`);
    const publisher = msg.pushName || config.botName || 'TALKLESS XMD';
    const result = await sendPack(sock, from, {
      name: title, publisher, description: `From Telegram: ${packName}`,
      stickers, quoted: msg, forceSingle
    });

    if (result.error) {
      await editStatus(
        `❌ *${title}* could not be sent as a sticker pack\n` +
        `Reason: ${result.error}\n\n` +
        `Nothing was sent as single stickers. To get them one by one anyway, use:\n.tgs ${packName} single`
      );
      return;
    }
    await editStatus(
      `✅ *${title}* is ready\n` +
      `📊 ${result.sent}/${total} stickers in ${result.packs} ${result.mode === 'pack' ? `sticker pack${result.packs > 1 ? 's' : ''} (tap Open to add)` : 'single stickers'}\n` +
      (previews ? `🖼 ${previews} animated (Lottie) stickers were sent as static previews\n` : '') +
      (failed ? `⚠️ ${failed} could not be converted\n` : '')
    );
  }
};
