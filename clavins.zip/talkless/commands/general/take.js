/**
 * Take Command
 * Re-label a single sticker or a complete sticker pack with a requested name.
 * Example: .take talkless (reply to a sticker or sticker pack)
 */
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const webp = require('node-webpmux');
const crypto = require('crypto');
const { readReceivedPack, sendPack, embedExif } = require('../../utils/stickerPack');

module.exports = {
  name: 'take',
  aliases: ['steal'],
  description: 'Take a sticker or sticker pack and apply a custom name',
  usage: '.take <pack name> (reply to a sticker or sticker pack)',
  category: 'general',
  async execute(sock, msg, args, extra) {
    const ctxInfo = msg.message?.extendedTextMessage?.contextInfo
      || msg.message?.imageMessage?.contextInfo
      || msg.message?.videoMessage?.contextInfo;
    let targetMessage = msg;
    if (ctxInfo?.quotedMessage) {
      let quotedMessage = ctxInfo.quotedMessage;
      if (quotedMessage.ephemeralMessage?.message) quotedMessage = quotedMessage.ephemeralMessage.message;
      if (quotedMessage.viewOnceMessage?.message) quotedMessage = quotedMessage.viewOnceMessage.message;
      targetMessage = {
        key: { remoteJid: extra.from, id: ctxInfo.stanzaId, participant: ctxInfo.participant },
        message: quotedMessage
      };
    }

    const content = targetMessage.message || {};
    const requestedName = args.join(' ').trim();
    const publisher = msg.pushName || extra.sender.split('@')[0] || 'TALKLESS';
    const packName = requestedName || publisher || 'TALKLESS';

    try {
      if (content.stickerPackMessage) {
        const receivedPack = await readReceivedPack(content.stickerPackMessage);
        if (!receivedPack.stickers.length) {
          return extra.reply('❌ That sticker pack has no readable stickers.');
        }
        const packId = crypto.randomBytes(16).toString('hex');
        const stickers = await Promise.all(receivedPack.stickers.map(async sticker => ({
          ...sticker,
          data: await embedExif(sticker.data, {
            packId,
            packName,
            publisher,
            emojis: sticker.emojis
          })
        })));
        const result = await sendPack(sock, extra.from, {
          name: packName,
          publisher,
          description: `Taken by ${publisher}`,
          stickers,
          quoted: msg
        });
        if (result.error) throw new Error(result.error);
        return extra.reply(`✅ *${packName}* taken\n📊 ${result.sent}/${stickers.length} stickers sent with the requested pack name.`);
      }

      if (!content.stickerMessage) {
        return extra.reply('🎭 Reply to a sticker or sticker pack with `.take talkless` to apply that name.');
      }
      const mediaBuffer = await downloadMediaMessage(targetMessage, 'buffer', {}, {
        logger: undefined,
        reuploadRequest: sock.updateMediaMessage
      });
      if (!mediaBuffer) return extra.reply('❌ Failed to download sticker. Please try again.');

      const img = new webp.Image();
      await img.load(mediaBuffer);
      const json = {
        'sticker-pack-id': crypto.randomBytes(32).toString('hex'),
        'sticker-pack-name': packName,
        'sticker-pack-publisher': publisher,
        emojis: ['🤖']
      };
      const exifAttr = Buffer.from([0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
      const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
      const exif = Buffer.concat([exifAttr, jsonBuffer]);
      exif.writeUIntLE(jsonBuffer.length, 14, 4);
      img.exif = exif;
      const finalBuffer = await img.save(null);
      await sock.sendMessage(extra.from, { sticker: finalBuffer }, { quoted: msg });
    } catch (error) {
      console.error('[take] Sticker/pack relabel failed:', error);
      await extra.reply(`❌ Failed to take the sticker or pack: ${error.message || 'Please try again.'}`);
    }
  }
};
