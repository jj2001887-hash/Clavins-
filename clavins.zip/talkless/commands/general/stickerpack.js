/**
 * Sticker-pack commands (WhatsApp)
 *
 *  .takepack [new name]   reply to a sticker PACK  -> re-sends the whole pack under your name
 *                         reply to a single sticker -> adds it to your collection (same as .packadd)
 *  .packadd               reply to any sticker to add it to your collection (shows the count with no reply)
 *  .packsend [name]       send your collection as a real WhatsApp sticker pack
 *  .packclear             empty your collection
 */
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const config = require('../../config');
const { sendPack, readReceivedPack, embedExif, getCollection, clearCollection, PACK_LIMIT, MAX_COLLECTION } = require('../../utils/stickerPack');

function quotedOf(msg, from) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo
    || msg.message?.imageMessage?.contextInfo
    || msg.message?.videoMessage?.contextInfo
    || msg.message?.stickerMessage?.contextInfo;
  if (!ctx?.quotedMessage) return null;
  let qm = ctx.quotedMessage;
  if (qm.ephemeralMessage) qm = qm.ephemeralMessage.message;
  if (qm.viewOnceMessage) qm = qm.viewOnceMessage.message;
  return { key: { remoteJid: from, id: ctx.stanzaId, participant: ctx.participant }, message: qm };
}

const publisherOf = (msg, extra) => msg.pushName || extra.sender.split('@')[0];

async function grabSticker(sock, target) {
  const buf = await downloadMediaMessage(target, 'buffer', {}, { logger: undefined, reuploadRequest: sock.updateMediaMessage });
  if (!buf) throw new Error('download failed');
  return { data: buf, emojis: ['🙂'] };
}

const takepack = {
  name: 'takepack',
  aliases: ['stealpack', 'takepk', 'tpack'],
  category: 'general',
  description: 'Take a whole WhatsApp sticker pack and re-send it under your name',
  usage: '.takepack talkless  (reply to a sticker pack)',
  async execute(sock, msg, args, extra) {
    const { from, reply } = extra;
    const target = quotedOf(msg, from);
    if (!target) {
      return reply('📦 *Take a sticker pack*\n\nReply to a *sticker pack* with `.takepack talkless` to re-send every sticker with that pack name.\n\nCan\'t reply to a pack? Reply to stickers one by one with `.packadd`, then run `.packsend talkless`.');
    }
    if (target.message.stickerMessage) {          // single sticker -> collection
      return packadd.execute(sock, msg, args, extra);
    }
    if (!target.message.stickerPackMessage) {
      return reply('⚠️ Reply to a *sticker pack* (or a sticker) with `.takepack`.');
    }
    try {
      await extra.react?.('⏳');
      const pack = await readReceivedPack(target.message.stickerPackMessage);
      if (!pack.stickers.length) throw new Error('no stickers found inside the pack');
      const name = args.join(' ').trim() || pack.name || 'My Pack';
      const publisher = publisherOf(msg, extra);
      const stickers = await Promise.all(pack.stickers.map(async sticker => ({
        ...sticker,
        data: await embedExif(sticker.data, { packName: name, publisher, emojis: sticker.emojis })
      })));
      const res = await sendPack(sock, from, {
        name, publisher, description: `Taken by ${publisher}`,
        stickers, quoted: msg
      });
      if (res.error) throw new Error(res.error);
      await extra.react?.('✅');
      return reply(`✅ *${name}* taken\n📊 ${res.sent}/${pack.stickers.length} stickers sent as a sticker pack`);
    } catch (e) {
      console.error('[TAKEPACK]', e);
      await extra.react?.('❌');
      return reply(`❌ Couldn't take that pack: ${e.message}\n\nWorkaround: reply to its stickers one by one with \`.packadd\`, then \`.packsend\`.`);
    }
  }
};

const packadd = {
  name: 'packadd',
  aliases: ['padd', 'addtopack'],
  category: 'general',
  description: 'Add a sticker to your personal pack collection',
  usage: '.packadd (reply to a sticker)',
  async execute(sock, msg, args, extra) {
    const { from, sender, reply } = extra;
    const list = getCollection(sock, sender);
    const target = quotedOf(msg, from);
    if (!target) {
      return reply(`🗂 Your collection has *${list.length}* sticker${list.length === 1 ? '' : 's'}.\n\nReply to a sticker with \`.packadd\` to add it, then \`.packsend My Pack\` to get the pack.`);
    }
    if (!target.message.stickerMessage) return reply('⚠️ Reply to a *sticker* with `.packadd`.');
    if (list.length >= MAX_COLLECTION) return reply(`⚠️ Collection is full (${MAX_COLLECTION}). Send it with \`.packsend\` or empty it with \`.packclear\`.`);
    try {
      list.push(await grabSticker(sock, target));
      return reply(`➕ Added. Your collection now has *${list.length}* sticker${list.length === 1 ? '' : 's'}.`);
    } catch (e) {
      return reply('❌ Could not download that sticker, try again.');
    }
  }
};

const packsend = {
  name: 'packsend',
  aliases: ['packmake', 'mypack', 'psend'],
  category: 'general',
  description: 'Send your sticker collection as a WhatsApp sticker pack',
  usage: '.packsend talkless',
  async execute(sock, msg, args, extra) {
    const { from, sender, reply } = extra;
    const list = getCollection(sock, sender);
    if (!list.length) return reply('🗂 Your collection is empty. Reply to stickers with `.packadd` first.');
    const name = args.join(' ').trim() || `${publisherOf(msg, extra)}'s pack`;
    try {
      const res = await sendPack(sock, from, {
        name, publisher: publisherOf(msg, extra), description: `Made by ${publisherOf(msg, extra)}`,
        stickers: list.slice(), quoted: msg
      });
      if (res.error) return reply(`❌ Could not send the pack: ${res.error}`);
      return reply(`✅ *${name}* sent: ${res.sent} sticker${res.sent === 1 ? '' : 's'} in ${res.packs} pack${res.packs > 1 ? 's' : ''} (up to ${PACK_LIMIT} each).\nUse \`.packclear\` to start a new one.`);
    } catch (e) {
      return reply(`❌ Could not send the pack: ${e.message}`);
    }
  }
};

const packclear = {
  name: 'packclear',
  aliases: ['pclear', 'clearpack'],
  category: 'general',
  description: 'Empty your sticker collection',
  usage: '.packclear',
  async execute(sock, msg, args, extra) {
    clearCollection(sock, extra.sender);
    return extra.reply('🗑 Collection cleared.');
  }
};

module.exports = [takepack, packadd, packsend, packclear];
