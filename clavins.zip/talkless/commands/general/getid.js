'use strict';

const CHANNEL_JID_RE = /^\d{5,}@newsletter$/i;
const ID_COMMANDS = new Set(['getid', 'id', 'jid', 'chatid', 'getchatid', 'groupid', 'getgroupid', 'channelid', 'getchannelid']);

function findChannelJids(value) {
  const found = new Set();
  const seen = new Set();
  const visit = (node, depth = 0) => {
    if (!node || depth > 12) return;
    if (typeof node === 'string') {
      const matches = node.match(/\b\d{5,}@newsletter\b/ig) || [];
      for (const jid of matches) found.add(jid);
      return;
    }
    if (typeof node !== 'object' || seen.has(node)) return;
    seen.add(node);
    if (Array.isArray(node)) {
      for (const item of node) visit(item, depth + 1);
      return;
    }
    for (const child of Object.values(node)) visit(child, depth + 1);
  };
  visit(value);
  return [...found];
}

function chatKind(jid) {
  if (!jid) return 'Unknown';
  if (jid === 'status@broadcast') return 'WhatsApp Status';
  if (jid.endsWith('@g.us')) return 'Group';
  if (jid.endsWith('@newsletter')) return 'Channel';
  if (jid.endsWith('@broadcast')) return 'Broadcast list';
  if (jid.endsWith('@s.whatsapp.net') || jid.endsWith('@lid')) return 'Private chat';
  return 'WhatsApp chat';
}

module.exports = {
  name: 'getid',
  aliases: ['id', 'jid', 'chatid', 'getchatid', 'groupid', 'getgroupid', 'channelid', 'getchannelid'],
  category: 'general',
  description: 'Get the current chat, group, or WhatsApp Channel ID',
  usage: '.id | .groupid | .channelid (reply to or forward a Channel post)',
  async execute(sock, msg, args, extra) {
    const reply = extra?.reply || (text => sock.sendMessage(extra?.from || msg.key.remoteJid, { text }, { quoted: msg }));
    const invoked = String(extra?.command || 'getid').toLowerCase();
    const requested = ['channelid', 'getchannelid'].includes(invoked)
      ? 'channel'
      : ['groupid', 'getgroupid'].includes(invoked)
        ? 'group'
        : ['chatid', 'getchatid'].includes(invoked)
          ? 'chat'
          : CHANNEL_JID_RE.test(String(args?.[0] || ''))
            ? 'channel'
            : String(args?.[0] || 'all').toLowerCase();
    const chatJid = extra?.from || msg?.key?.remoteJid || '';
    const senderJid = extra?.sender || msg?.key?.participant || msg?.key?.remoteJid || '';

    if (requested === 'channel' || requested === 'all') {
      const candidates = [
        ...findChannelJids(chatJid),
        ...findChannelJids(args || []),
        ...findChannelJids(msg)
      ];
      const currentChannel = chatJid.match(/\d{5,}@newsletter/i)?.[0];
      if (currentChannel) candidates.unshift(currentChannel);
      const channelIds = [...new Set(candidates.filter(jid => CHANNEL_JID_RE.test(jid)))];
      if (requested === 'channel') {
        if (!channelIds.length) {
          return reply('I could not find a Channel ID in this chat. Forward a post from the Channel to the bot in a private chat, then reply to that forwarded post with `.channelid`.');
        }
        return reply(`📰 *WhatsApp Channel ID*\n\n${channelIds.map(jid => `\`${jid}\``).join('\n')}`);
      }
      if (channelIds.length) {
        return reply(`🆔 *WhatsApp IDs*\nChat type: ${chatKind(chatJid)}\nChat ID: \`${chatJid}\`\nSender ID: \`${senderJid}\`\nChannel ID: \`${channelIds[0]}\``);
      }
    }

    if (requested === 'group') {
      if (!chatJid.endsWith('@g.us')) {
        return reply('Use `.groupid` inside the WhatsApp group whose ID you want.');
      }
      const subject = extra?.groupName || extra?.groupMetadata?.subject;
      return reply(`👥 *WhatsApp Group ID*${subject ? `\nGroup: ${subject}` : ''}\n\n\`${chatJid}\``);
    }

    if (requested !== 'all' && requested !== 'chat') {
      return reply('Use `.id`, `.chatid`, `.groupid`, or reply to/forward a Channel post and use `.channelid`.');
    }

    const type = chatKind(chatJid);
    const groupId = chatJid.endsWith('@g.us') ? `\nGroup ID: \`${chatJid}\`` : '';
    const channelId = chatJid.endsWith('@newsletter') ? `\nChannel ID: \`${chatJid}\`` : '';
    return reply(`🆔 *WhatsApp IDs*\nChat type: ${type}\nChat ID: \`${chatJid || 'unknown'}\`\nSender ID: \`${senderJid || 'unknown'}\`${groupId}${channelId}`);
  }
};
