/**
 * Pair Command - Generate a native WhatsApp pairing code for a number.
 */
module.exports = {
  name: 'pair',
  aliases: ['paircode', 'linkdevice'],
  category: 'general',
  description: 'Generate a TALKLESS pairing code for a WhatsApp number',
  usage: '.pair <number>  e.g. .pair 254712345678',
  async execute(sock, msg, args, extra) {
    const chatId = extra.from;
    const reply = text => sock.sendMessage(chatId, { text }, { quoted: msg });

    // Pairing codes authorize a new WhatsApp device. Never expose them in groups.
    if (extra.isGroup || !chatId || chatId.endsWith('@g.us')) {
      return reply('🔒 For your friend’s privacy, use .pair in a private chat with the bot.');
    }

    const rawNumber = args.join('').trim();
    const number = rawNumber.replace(/[^0-9]/g, '');
    if (!number || number.length < 7 || number.length > 15) {
      return reply('Usage: .pair <WhatsApp number with country code>\nExample: .pair 254712345678');
    }

    const requester = String(extra.sender || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    if (!requester) {
      return reply('❌ Could not identify your WhatsApp account. Please try again from a private chat.');
    }
    if (number === requester) {
      return reply('ℹ️ Enter your friend’s number, not the number you are chatting from.');
    }
    if (typeof global._pairWhatsAppNumber !== 'function') {
      return reply('⚠️ Pairing is not available right now. Please try again later.');
    }

    await reply(`⏳ Generating a TALKLESS pairing code for +${number}…`);
    try {
      await global._pairWhatsAppNumber(number, requester, async (code, error) => {
        if (error) {
          await reply(`❌ Pairing failed: ${error.message || 'Please try again later.'}`);
          return;
        }
        await reply(
          `🔐 *TALKLESS pairing code for +${number}*\n\n` +
          `\`${code}\`\n\n` +
          `On the friend’s phone: WhatsApp → Linked devices → Link a device → Link with phone number instead, then enter this code.\n\n` +
          `_Only share this code with the person who owns +${number}. It expires shortly._`
        );
      });
    } catch (error) {
      console.error('[PAIR] Native WhatsApp pairing failed:', error.message);
      await reply(error.message || '❌ Could not start pairing. Please try again later.');
    }
  }
};
