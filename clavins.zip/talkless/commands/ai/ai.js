/**
 * TALKLESS XMD AI commands with a configurable OpenAI-compatible text fallback.
 * All commands in a single array export.
 */

const aiProvider = require('../../utils/aiProvider');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// ── Shared send and result helpers ─────────────────────────────────────────────
const react = (sock, msg, emoji) => sock.sendMessage(msg.key.remoteJid, {
  react: { text: emoji, key: msg.key }
});
const send = (sock, msg, text) => sock.sendMessage(msg.key.remoteJid, {
  text: `*TALKLESS TECH XMD*\n\n${text}\n\n_OpenAI backend_`
}, { quoted: msg });

function cleanResult(result) {
  if (result == null) return '';
  if (typeof result === 'string') return result.trim();
  if (typeof result === 'number' || typeof result === 'boolean') return String(result);
  if (Array.isArray(result)) return result.map(cleanResult).filter(Boolean).join('\n\n');
  if (typeof result === 'object') {
    const candidate = result.text ?? result.message ?? result.response ?? result.answer ?? result.result ?? result.output ?? result.content ?? result.reply ?? null;
    if (candidate != null) return cleanResult(candidate);
    return Object.entries(result).filter(([, value]) => value != null && typeof value !== 'object').map(([key, value]) => `${key}: ${value}`).join('\n') || JSON.stringify(result);
  }
  return String(result);
}

function textPrompt(url, params = {}) {
  const route = String(url || '').toLowerCase();
  const q = String(params.q ?? params.query ?? '').trim();
  if (/lyricsgen/.test(route)) {
    return `Write original song lyrics (do not copy existing lyrics). Topic: ${params.topic || q || 'unspecified'}. Genre: ${params.genre || 'pop'}. Mood: ${params.mood || 'happy'}. Structure: ${String(params.structure || 'verse_chorus').replace(/[_-]/g, ' ')}. Language: ${params.language || 'English'}. Give clear section labels and a memorable chorus.`;
  }
  if (/speechwriter/.test(route)) {
    return `Write a complete ${params.length || 'short'} ${params.type || 'informative'} speech about: ${params.topic || q || 'the requested topic'}. Tone: ${params.tone || 'formal'}. Make it natural to speak aloud, with an opening, coherent main points, and a strong closing.`;
  }
  if (/dreamanalyzer/.test(route)) {
    return `Offer a gentle, non-clinical interpretation of this dream. Present possibilities rather than certainty; do not claim dreams predict the future or diagnose a condition. Dream: ${q}`;
  }
  if (/codegen/.test(route)) {
    return `Generate working, well-commented code for this request. State the language/framework, include necessary setup or run instructions, and avoid unexplained placeholders. Request: ${q}`;
  }
  if (/whatdoesthiscodedo/.test(route) || params.code) {
    return `Explain what this code does, step by step. Mention important inputs, side effects, and possible issues.\n\n${params.code || q}`;
  }
  if (q) return q;
  const fields = Object.entries(params).filter(([, value]) => value != null && typeof value !== 'object');
  return fields.map(([key, value]) => `${key}: ${value}`).join('\n');
}

async function ravenn(url, params = {}, options = {}) {
  const prompt = textPrompt(url, params);
  if (!prompt) throw new Error('No text prompt was provided.');
  if (prompt.length > 30000) throw new Error('AI input is limited to 30,000 characters per request.');
  return aiProvider.answer(prompt, options);
}

async function ravennBinary(_url, params = {}) {
  return aiProvider.generateImage(params.prompt || params.q || '');
}

function contextInfo(msg) {
  const content = msg?.message || {};
  return content.extendedTextMessage?.contextInfo || content.imageMessage?.contextInfo || content.videoMessage?.contextInfo || content.documentMessage?.contextInfo || null;
}

function unwrapQuoted(quoted) {
  let current = quoted;
  for (let i = 0; i < 5; i++) {
    if (current?.ephemeralMessage?.message) current = current.ephemeralMessage.message;
    else if (current?.viewOnceMessage?.message) current = current.viewOnceMessage.message;
    else if (current?.viewOnceMessageV2?.message) current = current.viewOnceMessageV2.message;
    else break;
  }
  return current;
}

async function quotedMediaBuffer(sock, msg, ctx, quotedMessage) {
  const target = {
    key: { remoteJid: msg.key.remoteJid, id: ctx?.stanzaId, participant: ctx?.participant },
    message: quotedMessage
  };
  const buffer = await downloadMediaMessage(target, 'buffer', {}, {
    logger: undefined,
    reuploadRequest: sock.updateMediaMessage
  });
  if (!buffer || !buffer.length) throw new Error('Could not download the replied-to media. Try sending it again.');
  return Buffer.from(buffer);
}

async function resolveImageInput(sock, msg, args = []) {
  if (args[0] && /^https?:\/\//i.test(args[0])) {
    const media = await aiProvider.downloadMediaUrl(args[0], 'image');
    return { ...media, remainingArgs: args.slice(1) };
  }
  const ctx = contextInfo(msg);
  const quoted = unwrapQuoted(ctx?.quotedMessage);
  const imageMessage = quoted?.imageMessage || quoted?.stickerMessage;
  if (!imageMessage) return { buffer: null, mime: null, remainingArgs: args };
  const buffer = await quotedMediaBuffer(sock, msg, ctx, quoted);
  return { buffer, mime: imageMessage.mimetype || 'image/jpeg', remainingArgs: args };
}

function audioExtension(mime) {
  const type = String(mime || '').toLowerCase();
  if (type.includes('mpeg') || type.includes('mp3')) return 'mp3';
  if (type.includes('wav')) return 'wav';
  if (type.includes('mp4') || type.includes('m4a')) return 'm4a';
  if (type.includes('webm')) return 'webm';
  if (type.includes('flac')) return 'flac';
  return 'ogg';
}

async function resolveAudioInput(sock, msg, args = []) {
  if (args[0] && /^https?:\/\//i.test(args[0])) {
    const media = await aiProvider.downloadMediaUrl(args[0], 'audio');
    return { ...media, filename: `audio.${audioExtension(media.mime)}`, remainingArgs: args.slice(1) };
  }
  const ctx = contextInfo(msg);
  const quoted = unwrapQuoted(ctx?.quotedMessage);
  const audioMessage = quoted?.audioMessage || (quoted?.documentMessage?.mimetype || '').startsWith('audio/') && quoted.documentMessage;
  if (!audioMessage) return { buffer: null, mime: null, filename: null, remainingArgs: args };
  const buffer = await quotedMediaBuffer(sock, msg, ctx, quoted);
  const mime = audioMessage.mimetype || 'audio/ogg';
  return { buffer, mime, filename: `audio.${audioExtension(mime)}`, remainingArgs: args };
}

// All model-backed commands now use the configured OpenAI account directly.
// Legacy apiskeith2 Railway URLs remain only as command metadata and are never called.

// ── Commands ──────────────────────────────────────────────────────────────────

module.exports = [
// ═══════════════════════════════════════════════════════════════════════════
// CHAT AI — text in, text out
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'ai',
  aliases: ['talklessai'],
  category: 'ai',
  description: 'Ask TALKLESS XMD AI a question',
  usage: '.ai <question>',
  apiUrl: 'openai://api/keithai',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .ai How does the internet work?');
    await react(sock, msg, '⚡');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `⚡ *TALKLESS XMD AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[talklessai]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ TALKLESS XMD AI error: ${err.message}`);
    }
  }
}, {
  name: 'chatgpt',
  aliases: ['gpt', 'gpt2', 'gptai'],
  category: 'ai',
  description: 'Ask GPT AI a question',
  usage: '.chatgpt <question>',
  apiUrl: 'openai://api/ai/gpt',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .chatgpt What is JavaScript?');
    await react(sock, msg, '🤖');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🤖 *ChatGPT*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[chatgpt]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ ChatGPT error: ${err.message}`);
    }
  }
}, {
  name: 'gpt4o',
  aliases: ['gpt4', 'chatgpt4', 'gpt4nano', 'gpt41nano'],
  category: 'ai',
  description: 'Ask GPT-4 a question',
  usage: '.gpt4o <question>',
  apiUrl: 'openai://api/ai/chatgpt4',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .gpt4o How does a black hole form?');
    await react(sock, msg, '🤖');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🤖 *GPT-4*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[gpt4o]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ GPT-4 error: ${err.message}`);
    }
  }
}, {
  name: 'claude',
  aliases: ['claudeai'],
  category: 'ai',
  description: 'Ask Claude AI a question',
  usage: '.claude <question>',
  apiUrl: 'openai://api/ai/claudeai',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .claude Explain recursion');
    await react(sock, msg, '🧠');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🧠 *Claude AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[claude]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Claude AI error: ${err.message}`);
    }
  }
}, {
  name: 'gemini',
  aliases: ['geminai'],
  category: 'ai',
  description: 'Ask Google Gemini a question',
  usage: '.gemini <question>',
  apiUrl: 'openai://api/ai/gemini',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .gemini Explain quantum physics');
    await react(sock, msg, '♊');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `♊ *Google Gemini*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[gemini]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Gemini error: ${err.message}`);
    }
  }
}, {
  name: 'mistral',
  aliases: ['mistralai'],
  category: 'ai',
  description: 'Ask Mistral AI a question',
  usage: '.mistral <question>',
  apiUrl: 'openai://api/ai/mistral',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .mistral What is machine learning?');
    await react(sock, msg, '🔍');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🔍 *Mistral AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[mistral]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Mistral AI error: ${err.message}`);
    }
  }
}, {
  name: 'copilot',
  aliases: ['microsoftai'],
  category: 'ai',
  description: 'Ask Microsoft Copilot a question',
  usage: '.copilot <question>',
  apiUrl: 'openai://api/ai/copilot',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .copilot How are you?');
    await react(sock, msg, '🪟');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🪟 *Microsoft Copilot*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[copilot]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Copilot error: ${err.message}`);
    }
  }
}, {
  name: 'metaai',
  aliases: ['meta', 'metalai'],
  category: 'ai',
  description: 'Ask Meta AI a question',
  usage: '.metaai <question>',
  apiUrl: 'openai://api/ai/metai',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .metaai Hello, how are you?');
    await react(sock, msg, '💭');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `💭 *Meta AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[metaai]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Meta AI error: ${err.message}`);
    }
  }
}, {
  name: 'aiLlama',
  aliases: ['llamaai', 'ilama', 'llama3'],
  category: 'ai',
  description: 'Ask Llama AI a question',
  usage: '.llama <question>',
  apiUrl: 'openai://api/ai/ilama',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .llama What is deep learning?');
    await react(sock, msg, '🦙');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🦙 *Llama AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[llama]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Llama AI error: ${err.message}`);
    }
  }
}, {
  name: 'blackbox',
  aliases: ['bb', 'blackboxai'],
  category: 'ai',
  description: 'Ask Blackbox AI a question',
  usage: '.blackbox <question>',
  apiUrl: 'openai://api/ai/blackbox',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .blackbox Explain recursion');
    await react(sock, msg, '📦');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `📦 *Blackbox AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[blackbox]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Blackbox AI error: ${err.message}`);
    }
  }
}, {
  name: 'bard',
  aliases: ['googlebard'],
  category: 'ai',
  description: 'Ask Google Bard a question',
  usage: '.bard <question>',
  apiUrl: 'openai://api/ai/bard',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .bard Explain black holes');
    await react(sock, msg, '✨');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `✨ *Google Bard*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[bard]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Bard error: ${err.message}`);
    }
  }
}, {
  name: 'perplexity',
  aliases: ['perplexai'],
  category: 'ai',
  description: 'Ask Perplexity AI a question',
  usage: '.perplexity <question>',
  apiUrl: 'openai://api/ai/perplexity',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .perplexity What is quantum computing?');
    await react(sock, msg, '🔎');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🔎 *Perplexity AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[perplexity]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Perplexity AI error: ${err.message}`);
    }
  }
}, {
  name: 'venice',
  aliases: ['vai', 'veniceai'],
  category: 'ai',
  description: 'Ask Venice AI a question',
  usage: '.venice <question>',
  apiUrl: 'openai://api/ai/venice',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .venice What is life?');
    await react(sock, msg, '🌊');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🌊 *Venice AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[venice]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Venice AI error: ${err.message}`);
    }
  }
}, {
  name: 'o3',
  aliases: ['o3ai', 'openai03'],
  category: 'ai',
  description: 'Ask O3 AI a question',
  usage: '.o3 <question>',
  apiUrl: 'openai://api/ai/o3',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .o3 What is consciousness?');
    await react(sock, msg, '🔵');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🔵 *O3 AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[o3]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ O3 AI error: ${err.message}`);
    }
  }
}, {
  name: 'grok',
  aliases: ['grokai', 'xai'],
  category: 'ai',
  description: 'Ask Grok AI a question',
  usage: '.grok <question>',
  apiUrl: 'openai://api/ai/grok',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .grok Explain dark matter');
    await react(sock, msg, '🚀');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🚀 *Grok AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[grok]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Grok AI error: ${err.message}`);
    }
  }
}, {
  name: 'deepseek',
  aliases: ['deepseekr1', 'think'],
  category: 'ai',
  description: 'Ask Deepseek R1 (reasoning model) a question',
  usage: '.deepseek <question>',
  apiUrl: 'openai://api/ai/deepseek',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .deepseek Analyze the trolley problem');
    await react(sock, msg, '🧠');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      // Strip <think>...</think> reasoning chain for cleaner output
      const clean = cleanResult(result).replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
      await send(sock, msg, `🧠 *Deepseek R1*\n\n${clean}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[deepseek]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Deepseek R1 error: ${err.message}`);
    }
  }
}, {
  name: 'deepseekv3',
  aliases: ['dsv3'],
  category: 'ai',
  description: 'Ask Deepseek V3 a question',
  usage: '.deepseekv3 <question>',
  apiUrl: 'openai://api/ai/deepseekV3',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .deepseekv3 Write a poem about rain');
    await react(sock, msg, '💙');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `💙 *Deepseek V3*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[deepseekv3]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Deepseek V3 error: ${err.message}`);
    }
  }
}, {
  name: 'qwen',
  aliases: ['qwenai', 'qwena'],
  category: 'ai',
  description: 'Ask Qwen AI a question',
  usage: '.qwen <question>',
  apiUrl: 'openai://api/ai/qwenai',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .qwen What is Alibaba?');
    await react(sock, msg, '🟣');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🟣 *Qwen AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[qwen]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Qwen AI error: ${err.message}`);
    }
  }
}, {
  name: 'wormgpt',
  aliases: ['wgpt', 'darkgpt'],
  category: 'ai',
  description: 'Ask WormGPT a question',
  usage: '.wormgpt <question>',
  apiUrl: 'openai://api/ai/wormgpt',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a question\n\nExample: .wormgpt hi');
    await react(sock, msg, '😈');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `😈 *WormGPT*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[wormgpt]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ WormGPT error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// SEARCH / WEB AI
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'searchai',
  aliases: ['compound', 'websearch', 'ainews', 'news'],
  category: 'ai',
  description: 'AI-powered web search — get detailed answers from the web',
  usage: '.searchai <query>',
  apiUrl: 'openai://api/ai/searchai',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a search query\n\nExample: .searchai latest AI news');
    await react(sock, msg, '🌐');
    try {
      const result = await ravenn(this.apiUrl, {
        query
      }, { webSearch: true });
      // result can be a string or array of search objects
      let text;
      if (typeof result === 'string') {
        text = result;
      } else if (Array.isArray(result)) {
        text = result.slice(0, 3).map((r, i) => {
          const ans = r?.question?.answer;
          const body = ans?.body || ans?.text || cleanResult(r);
          return `*${i + 1}.* ${body}`;
        }).join('\n\n');
      } else {
        text = cleanResult(result);
      }
      await send(sock, msg, `🌐 *AI Web Search*\n\n${text}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[searchai]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Search AI error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// SUMMARIZE / RESEARCH
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'summarize',
  aliases: ['summary'],
  category: 'ai',
  description: 'Summarize text using AI',
  usage: '.summarize <text>',
  apiUrl: 'openai://api/keithai',
  async execute(sock, msg, args, extra) {
    const text = args.join(' ').trim();
    if (!text) return extra.reply('❌ Please provide text to summarize\n\nExample: .summarize Paste your long text here');
    await react(sock, msg, '📝');
    try {
      const result = await ravenn(this.apiUrl, {
        q: `Summarize the following text concisely:\n\n${text}`
      });
      await send(sock, msg, `📝 *Summary*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[summarize]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Summarize error: ${err.message}`);
    }
  }
}, {
  name: 'scite',
  aliases: ['research', 'science'],
  category: 'ai',
  description: 'AI-powered academic/research question answering',
  usage: '.scite <research question>',
  apiUrl: 'openai://api/keithai',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please provide a research question\n\nExample: .scite Effects of caffeine on sleep');
    await react(sock, msg, '🔬');
    try {
      const result = await ravenn(this.apiUrl, {
        q: `Answer this academic/research question in detail: ${query}`
      }, { webSearch: true });
      await send(sock, msg, `🔬 *Research AI*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[scite]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Research AI error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// CODE AI
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'codegen',
  aliases: ['code', 'generatecode'],
  category: 'ai',
  description: 'Generate code in any language using AI',
  usage: '.codegen <description>',
  apiUrl: 'openai://api/ai/codegen',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please describe the code to generate\n\nExample: .codegen REST API in Node.js');
    await react(sock, msg, '💻');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `💻 *Code Generator*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[codegen]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Code Generator error: ${err.message}`);
    }
  }
}, {
  name: 'codedescribe',
  aliases: ['whatscode', 'explaincode'],
  category: 'ai',
  description: 'Explain what a piece of code does',
  usage: '.codedescribe <code>',
  apiUrl: 'openai://api/whatdoesthiscodedo',
  async execute(sock, msg, args, extra) {
    const code = args.join(' ').trim();
    if (!code) return extra.reply('❌ Please provide code to explain\n\nExample: .codedescribe console.log(\'hello\')');
    await react(sock, msg, '🔍');
    try {
      const result = await ravenn(this.apiUrl, {
        code
      });
      await send(sock, msg, `🔍 *Code Explained*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[codedescribe]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Code Describe error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// CREATIVE AI
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'lyricsgen',
  aliases: ['genlyrics', 'ailyrics'],
  category: 'ai',
  description: 'Generate song lyrics. Format: .lyricsgen topic | genre | mood | structure | language',
  usage: '.lyricsgen heartbreak | blues | sad | verse_chorus_bridge | en',
  apiUrl: 'openai://api/ai/lyricsgen',
  async execute(sock, msg, args, extra) {
    const input = args.join(' ').trim();
    if (!input) {
      return extra.reply(`🎵 *Lyrics Generator*\n\n` + `Format: _.lyricsgen topic | genre | mood | structure | language_\n\n` + `Example: _.lyricsgen heartbreak | blues | sad | verse_chorus_bridge | en_\n\n` + `*Defaults:* genre=pop, mood=happy, structure=verse_chorus, language=en`);
    }
    const parts = input.split('|').map(s => s.trim());
    const [topic = input, genre = 'pop', mood = 'happy', structure = 'verse_chorus', language = 'en'] = parts;
    await react(sock, msg, '🎵');
    try {
      const result = await ravenn(this.apiUrl, {
        topic,
        genre,
        mood,
        structure,
        language
      });
      await send(sock, msg, `🎵 *Generated Lyrics*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[lyricsgen]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Lyrics Generator error: ${err.message}`);
    }
  }
}, {
  name: 'speechwriter',
  aliases: ['writespeech', 'speech'],
  category: 'ai',
  description: 'Write a speech on any topic. Format: .speechwriter topic | length | type | tone',
  usage: '.speechwriter how to pass exams | short | dedication | serious',
  apiUrl: 'openai://api/ai/speechwriter',
  async execute(sock, msg, args, extra) {
    const input = args.join(' ').trim();
    if (!input) {
      return extra.reply(`🎤 *Speech Writer*\n\n` + `Format: _.speechwriter topic | length | type | tone_\n\n` + `Example: _.speechwriter climate change | medium | persuasive | serious_\n\n` + `*Lengths:* short, medium, long\n` + `*Types:* dedication, persuasive, informative, motivational\n` + `*Tones:* serious, casual, formal, inspirational`);
    }
    const parts = input.split('|').map(s => s.trim());
    const [topic = input, length = 'short', type = 'informative', tone = 'formal'] = parts;
    await react(sock, msg, '🎤');
    try {
      const result = await ravenn(this.apiUrl, {
        topic,
        length,
        type,
        tone
      });
      await send(sock, msg, `🎤 *Speech*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[speechwriter]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Speech Writer error: ${err.message}`);
    }
  }
}, {
  name: 'dreamanalyzer',
  aliases: ['dream', 'analyzedream'],
  category: 'ai',
  description: 'Interpret and analyze your dreams using AI',
  usage: '.dreamanalyzer <describe your dream>',
  apiUrl: 'openai://api/ai/dreamanalyzer',
  async execute(sock, msg, args, extra) {
    const query = args.join(' ').trim();
    if (!query) return extra.reply('❌ Please describe your dream\n\nExample: .dreamanalyzer I dreamt about flying over the ocean');
    await react(sock, msg, '🌙');
    try {
      const result = await ravenn(this.apiUrl, {
        q: query
      });
      await send(sock, msg, `🌙 *Dream Analysis*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[dreamanalyzer]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Dream Analyzer error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// VISION AI
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'vision',
  aliases: ['see', 'aiview', 'describe'],
  category: 'ai',
  description: 'Analyze an image using AI vision. Reply to an image or provide a URL.',
  usage: '.vision <question> (reply to image) | .vision <url> <question>',
  apiUrl: 'openai://api/ai/vision',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '👁️');
    try {
      const { buffer, mime, remainingArgs } = await resolveImageInput(sock, msg, args);
      if (!buffer) return extra.reply(`👁️ *AI Vision*\n\nReply to an image and ask a question, or provide a public HTTPS image URL:\n_Reply to image + .vision What is in this image?_`);
      const question = remainingArgs.join(' ').trim() || "Describe this image and its main details.";
      const result = await aiProvider.answer(question, {
        image: { buffer, mime },
        instructions: 'You are an image-analysis assistant. Describe only what is visible, distinguish uncertainty, and answer the user’s question clearly.'
      });
      await send(sock, msg, `👁️ *AI Vision*\n\n${cleanResult(result)}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[vision]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Vision AI error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// SPEECH / AUDIO AI
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'aitts',
  aliases: ['texttospeech', 'aispeech'],
  category: 'ai',
  description: 'Convert text to speech using AI voices',
  usage: '.tts <text>',
  apiUrl: 'openai://api/ai/tts',
  async execute(sock, msg, args, extra) {
    const text = args.join(' ').trim();
    if (!text) return extra.reply('❌ Please provide text. Example: .tts Hello, how are you today?');
    await react(sock, msg, '🔊');
    try {
      const audio = await aiProvider.synthesizeSpeech(text);
      await sock.sendMessage(msg.key.remoteJid, {
        audio,
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: msg });
      await send(sock, msg, '🔊 *Text to Speech*\n\nVoice: nova. This audio was generated by AI.');
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[tts]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ TTS error: ${err.message}`);
    }
  }
}, {
  name: 'whisper',
  aliases: ['speech2text', 'aistranscribe', 'transcribe'],
  category: 'ai',
  description: 'Transcribe audio using AI. Reply to a voice note/audio or provide a URL.',
  usage: '.whisper (reply to audio) | .whisper <audio url>',
  apiUrl: 'openai://api/ai/transcribe',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '🎙️');
    try {
      const { buffer, mime, filename } = await resolveAudioInput(sock, msg, args);
      if (!buffer) return extra.reply(`🎙️ *AI Transcribe*\n\nReply to a voice note/audio file and use .whisper, or provide a public HTTPS audio URL.`);
      const text = await aiProvider.transcribeAudio(buffer, mime, filename);
      await send(sock, msg, `🎙️ *Transcription*\n\n${text}`);
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[whisper]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Transcribe error: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// IMAGE GENERATION
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'magicstudio',
  aliases: ['magic', 'magicai'],
  category: 'ai',
  description: 'Generate an AI image using OpenAI',
  usage: '.magicstudio <prompt>',
  apiUrl: 'openai://api/ai/magicstudio',
  async execute(sock, msg, args, extra) {
    const prompt = args.join(' ').trim();
    if (!prompt) return extra.reply('❌ Please provide a prompt. Example: .magicstudio a futuristic city at sunset');
    await react(sock, msg, '✨');
    try {
      const buffer = await aiProvider.generateImage(prompt);
      await sock.sendMessage(msg.key.remoteJid, {
        image: buffer,
        caption: `✨ *AI Image*\n\n_Prompt:_ ${prompt}\n_Generated with OpenAI._`
      }, { quoted: msg });
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[magicstudio]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Image generation error: ${err.message}`);
    }
  }
}, {
  name: 'generate',
  aliases: ['genimage', 'aiimage', 'dalle', 'flux', 'fluxai'],
  category: 'ai',
  description: 'Generate an AI image using OpenAI',
  usage: '.generate <prompt>',
  apiUrl: 'openai://api/ai/flux',
  async execute(sock, msg, args, extra) {
    const prompt = args.join(' ').trim();
    if (!prompt) return extra.reply('❌ Please provide a prompt. Example: .generate sunset over mountains');
    await react(sock, msg, '🎨');
    try {
      const buffer = await aiProvider.generateImage(prompt);
      await sock.sendMessage(msg.key.remoteJid, {
        image: buffer,
        caption: `🎨 *AI Image*\n\n_Prompt:_ ${prompt}\n_Generated with OpenAI._`
      }, { quoted: msg });
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[generate]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Image generation failed: ${err.message}`);
    }
  }
},
// ═══════════════════════════════════════════════════════════════════════════
// IMAGE PROCESSING
// ═══════════════════════════════════════════════════════════════════════════

{
  name: 'removebg',
  aliases: ['rembg', 'removebackground', 'bgremove'],
  category: 'ai',
  description: 'Remove the background from an image. Reply to image or provide URL.',
  usage: '.removebg (reply to image) | .removebg <url>',
  apiUrl: 'openai://api/ai/removebg',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '✂️');
    try {
      const { buffer, mime } = await resolveImageInput(sock, msg, args);
      if (!buffer) return extra.reply('❌ Reply to an image or provide a public HTTPS image URL.');
      const result = await aiProvider.editImage(buffer, mime, 'Remove the background completely. Preserve the main subject accurately with clean edges and no added objects.', { background: 'transparent', outputFormat: 'png' });
      await sock.sendMessage(msg.key.remoteJid, {
        image: result,
        mimetype: 'image/png',
        caption: '✂️ *Background Removed*\n_Processed with OpenAI image editing._'
      }, { quoted: msg });
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[removebg]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Remove BG error: ${err.message}`);
    }
  }
}, {
  name: 'imagehd',
  aliases: ['enhanceimage', 'hd', 'aiupscale'],
  category: 'ai',
  description: 'Enhance an image to HD quality using AI. Reply to image or provide URL.',
  usage: '.imagehd (reply to image) | .imagehd <url>',
  apiUrl: 'openai://api/ai/hd',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '🔆');
    try {
      const { buffer, mime } = await resolveImageInput(sock, msg, args);
      if (!buffer) return extra.reply('❌ Reply to an image or provide a public HTTPS image URL.');
      const result = await aiProvider.editImage(buffer, mime, 'Enhance and restore this image: reduce noise and compression artifacts, improve sharpness and clarity, preserve the original subject, colors, composition, and identity, and do not add new content.', { outputFormat: 'png' });
      await sock.sendMessage(msg.key.remoteJid, {
        image: result,
        mimetype: 'image/png',
        caption: '🔆 *Image Enhanced*\n_Processed with OpenAI image editing._'
      }, { quoted: msg });
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[imagehd]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Image HD error: ${err.message}`);
    }
  }
}, {
  name: 'imageedit',
  aliases: ['editimage', 'aiedit', 'editimg'],
  category: 'ai',
  description: 'Edit an image with an AI instruction. Reply to image or provide URL.',
  usage: '.imageedit <instruction> (reply to image) | .imageedit <url> <instruction>',
  apiUrl: 'openai://api/ai/imageedit',
  async execute(sock, msg, args, extra) {
    await react(sock, msg, '🖌️');
    try {
      const { buffer, mime, remainingArgs } = await resolveImageInput(sock, msg, args);
      const instruction = remainingArgs.join(' ').trim();
      if (!buffer || !instruction) return extra.reply(`🖌️ *AI Image Editor*\n\nReply to an image and add an instruction, or use:\n_.imageedit https://example.com/image.jpg make it black and white_`);
      const result = await aiProvider.editImage(buffer, mime, instruction, { outputFormat: 'png' });
      await sock.sendMessage(msg.key.remoteJid, {
        image: result,
        mimetype: 'image/png',
        caption: `🖌️ *AI Edited Image*\n\n_Instruction:_ ${instruction}\n_Edited with OpenAI._`
      }, { quoted: msg });
      await react(sock, msg, '✅');
    } catch (err) {
      console.error('[imageedit]', err.message);
      await react(sock, msg, '❌');
      extra.reply(`❌ Image Edit error: ${err.message}`);
    }
  }
}];
