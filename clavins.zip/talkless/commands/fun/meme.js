const APIs = require('../../utils/api');
const axios = require('axios');

module.exports = {
  name: 'meme',
  aliases: ['memes'],
  category: 'fun',
  description: 'Get a random meme',
  usage: '.meme',
  async execute(sock, msg, args, extra) {
    try {
      const meme = await APIs.getMeme();
      if (!meme?.url || !/^https?:\/\//i.test(meme.url)) throw new Error('Meme provider returned an invalid link.');
      let response;
      try {
        response = await axios.get(meme.url, {
          responseType: 'arraybuffer',
          timeout: 20000,
          maxContentLength: 16 * 1024 * 1024,
          maxBodyLength: 16 * 1024 * 1024,
          validateStatus: status => status >= 200 && status < 300
        });
      } catch (_) {
        await extra.reply(`😂 *${meme.title || 'Random meme'}*\n\nThe image could not be previewed, but you can open it here:\n${meme.url}`);
        return;
      }
      const buffer = Buffer.from(response.data || []);
      const type = String(response.headers?.['content-type'] || '').split(';')[0].toLowerCase();
      const isPng = buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
      const isJpeg = buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
      const isWebp = buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP';
      const mime = isPng ? 'image/png' : isJpeg ? 'image/jpeg' : isWebp ? 'image/webp' : '';
      if (!buffer.length || !mime || type && !type.startsWith('image/') && type !== 'application/octet-stream') {
        await extra.reply(`😂 *${meme.title || 'Random meme'}*\n\nOpen the meme here:\n${meme.url}`);
        return;
      }
      const caption = `😂 *${meme.title || 'Random meme'}*\n\n📱 From: r/${meme.subreddit || 'memes'}\n👤 By: ${meme.author || 'unknown'}\n⬆️ Upvotes: ${Number(meme.ups) || 0}`;
      await sock.sendMessage(extra.from, { image: buffer, mimetype: mime, caption }, { quoted: msg });
    } catch (_) {
      await extra.reply('❌ Could not fetch a meme right now. Please try again later.');
    }
  }
};
