const { truth } = require('@bochilteam/scraper');
const { translate } = require('@vitalets/google-translate-api');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'truth',
  aliases: [],
  category: 'fun',
  description: 'Get a random truth question',
  usage: '.truth',
  async execute(sock, msg, args, extra) {
    let questionText = '';
    try {
      const result = await truth();
      const source = typeof result === 'string' ? result : result?.question || result?.text;
      if (typeof source !== 'string' || !source.trim()) throw new Error('No truth question returned');
      const translated = await translate(source.trim(), { to: 'en' });
      if (typeof translated?.text === 'string' && translated.text.trim()) questionText = translated.text.trim();
    } catch (_) {
      // Use an English question when scraping or translation is unavailable.
    }
    if (!questionText) questionText = fallback.truth();
    await extra.reply(`🎯 *Truth*\n\n${questionText}`);
  }
};
