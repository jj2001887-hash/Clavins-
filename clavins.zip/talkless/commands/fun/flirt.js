/** Flirt command with local fallback content. */
const axios = require('axios');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'flirt',
  aliases: ['pickup'],
  category: 'fun',
  description: 'Get a random flirty message',
  usage: '.flirt [@user]',
  async execute(sock, msg, args, extra) {
    let text = '';
    try {
      const { data } = await axios.get('https://api.shizo.top/quote/flirt?apikey=shizo', { timeout: 8000 });
      if (data?.status && typeof data.result === 'string' && data.result.trim()) text = data.result.trim();
    } catch (_) {
      // Local fallback below keeps the command available during API outages.
    }
    if (!text) text = fallback.flirt();
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    await sock.sendMessage(extra.from, { text, ...(mentioned.length ? { mentions: mentioned } : {}) }, { quoted: msg });
  }
};
