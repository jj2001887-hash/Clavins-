const axios = require('axios');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'wyr',
  aliases: ['wouldyourather'],
  category: 'fun',
  description: 'Get a would-you-rather question',
  usage: '.wyr',
  async execute(sock, msg, args, extra) {
    try { await extra.react('🤔'); } catch (_) {}
    let question = '';
    try {
      const { data } = await axios.get('https://api.truthordarebot.xyz/v1/wyr', { timeout: 8000 });
      if (typeof data?.question === 'string' && data.question.trim()) question = data.question.trim();
    } catch (_) {
      // Use a local question if the provider is unavailable.
    }
    let optA, optB;
    if (question) {
      const parts = question.split(/\s+or\s+/i);
      optA = parts[0]?.trim() || question;
      optB = parts.slice(1).join(' or ').trim();
    } else {
      ({ a: optA, b: optB } = fallback.wouldYouRather());
    }
    await extra.reply(`🤔 *Would You Rather?*\n\n🅰️ ${optA}\n\n*OR*\n\n🅱️ ${optB}`);
    try { await extra.react('✅'); } catch (_) {}
  }
};
