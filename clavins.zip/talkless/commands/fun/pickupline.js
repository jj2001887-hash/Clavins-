const axios = require('axios');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'pickupline',
  aliases: ['rizz'],
  category: 'fun',
  description: 'Get a random pickup line',
  usage: '.pickupline',
  async execute(sock, msg, args, extra) {
    try { await extra.react('😏'); } catch (_) {}
    let line = '';
    try {
      const { data } = await axios.get('https://api.jcwyt.com/pickup', { timeout: 8000 });
      const candidate = typeof data === 'string' ? data : data?.line ?? data?.pickup;
      if (typeof candidate === 'string' && candidate.trim()) line = candidate.trim();
    } catch (_) {
      // Use a local line if the upstream API is down.
    }
    if (!line) line = fallback.pickupLine();
    await extra.reply(`😏 *Pickup Line*\n\n_${line}_`);
    try { await extra.react('✅'); } catch (_) {}
  }
};
