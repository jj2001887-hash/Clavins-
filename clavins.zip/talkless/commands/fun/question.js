const axios = require('axios');
const fallback = require('../../utils/funFallbacks');

function decode(value) {
  return decodeURIComponent(String(value).replace(/\+/g, '%20'));
}

module.exports = {
  name: 'question',
  aliases: ['randomq'],
  category: 'fun',
  description: 'Get a random trivia question',
  usage: '.question',
  async execute(sock, msg, args, extra) {
    try { await extra.react('❓'); } catch (_) {}
    let item;
    try {
      const { data } = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple&encode=url3986', { timeout: 8000 });
      const candidate = data?.results?.[0];
      if (data?.response_code === 0 && typeof candidate?.question === 'string' && typeof candidate?.correct_answer === 'string' && Array.isArray(candidate?.incorrect_answers) && candidate.incorrect_answers.length === 3) {
        item = {
          category: decode(candidate.category || 'Trivia'),
          difficulty: decode(candidate.difficulty || 'easy'),
          question: decode(candidate.question),
          correct: decode(candidate.correct_answer),
          incorrect: candidate.incorrect_answers.map(decode)
        };
      }
    } catch (_) {
      // The local trivia set is used below when OpenTDB is offline or malformed.
    }
    if (!item) item = fallback.trivia();
    const options = [item.correct, ...item.incorrect];
    for (let i = options.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [options[i], options[j]] = [options[j], options[i]];
    }
    const labels = ['🅰️', '🅱️', '🅲️', '🅳️'];
    const optionList = options.map((option, i) => `${labels[i]} ${option}`).join('\n');
    const correctLabel = labels[options.indexOf(item.correct)];
    await extra.reply(`❓ *Random Question*\n\n📂 _${item.category}_ • 🔥 _${item.difficulty}_\n\n*${item.question}*\n\n${optionList}\n\n||✅ Answer: ${correctLabel} ${item.correct}||`);
    try { await extra.react('✅'); } catch (_) {}
  }
};
