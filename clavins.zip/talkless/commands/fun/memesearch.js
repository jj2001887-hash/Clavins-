/**
 * Meme Search Command - Search and get memes
 */

const axios = require('axios');
const APIs = require('../../utils/api');
const fs = require('fs');
const path = require('path');
const {
  exec
} = require('child_process');
const ffmpegPath = require('ffmpeg-static');
const {
  getTempDir,
  deleteTempFile
} = require('../../utils/tempManager');
const BASE = 'https://api.shizo.top/tools/meme-search';

function detectMediaType(buffer, contentType = '') {
  const b = Buffer.from(buffer || []);
  const header = String(contentType).split(';')[0].trim().toLowerCase();
  let detected = '';
  if (b.length >= 6 && /^GIF8[79]a$/.test(b.toString('ascii', 0, 6))) detected = 'image/gif';
  else if (b.length >= 8 && b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) detected = 'image/png';
  else if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) detected = 'image/jpeg';
  else if (b.length >= 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') detected = 'image/webp';
  else if (b.length >= 12 && b.toString('ascii', 4, 8) === 'ftyp') detected = 'video/mp4';
  if (!detected) return null;
  const generic = !header || header === 'application/octet-stream' || header === 'binary/octet-stream';
  const imageHeader = header.startsWith('image/');
  const videoHeader = header.startsWith('video/') || header.includes('mp4');
  if (!generic && !imageHeader && !videoHeader) return null;
  if (imageHeader && detected.startsWith('video/')) return null;
  if (videoHeader && detected.startsWith('image/')) return null;
  return detected;
}
module.exports = {
  name: 'memesearch',
  aliases: ['sm', 'smeme', 'gifsearch', 'gif'],
  category: 'fun',
  desc: 'Search and get memes',
  usage: 'memesearch <query>',
  execute: async (sock, msg, args, extra) => {
    try {
      const query = args.join(' ').trim();
      if (!query) {
        return await extra.reply('Usage: .memesearch <query>\n\nExample: .memesearch hello');
      }

      // Fetch from the query service; if it is offline, fall back to a safe random meme link.
      const url = `${BASE}?apikey=shizo&query=${encodeURIComponent(query)}`;
      let response;
      try {
        response = await axios.get(url, {
          responseType: 'arraybuffer',
          timeout: 20000,
          maxContentLength: 16 * 1024 * 1024,
          maxBodyLength: 16 * 1024 * 1024,
          headers: { 'User-Agent': 'TALKLESS-TECH-XMD/2.0' }
        });
      } catch (_) {
        try {
          const randomMeme = await APIs.getMeme();
          await sock.sendMessage(extra.from, {
            text: `🔎 Meme search for “${query}” is temporarily unavailable. Here is a random meme instead:

${randomMeme.title}
${randomMeme.url}`
          }, { quoted: msg });
          return;
        } catch (_) {
          throw new Error('Meme search is temporarily unavailable. Try .meme for a random meme.');
        }
      }
      const mediaBuffer = Buffer.from(response.data || []);

      // Verify buffer is valid
      if (!mediaBuffer || mediaBuffer.length === 0) {
        throw new Error('Empty response from API');
      }

      // Check file size limits (WhatsApp has limits: 16MB for videos, 5MB for images)
      const maxVideoSize = 16 * 1024 * 1024; // 16MB
      const maxImageSize = 5 * 1024 * 1024; // 5MB

      // Require supported media signatures; never send JSON/HTML error bodies as images.
      const mediaType = detectMediaType(mediaBuffer, response.headers?.['content-type'] || '');
      if (!mediaType) throw new Error('Search service returned an unsupported or invalid media file.');

      // Determine media type and send accordingly
      if (mediaType === 'image/gif') {
        // Check size for GIF
        if (mediaBuffer.length > maxVideoSize) {
          throw new Error(`GIF file too large: ${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB (max 16MB)`);
        }

        // Convert GIF to MP4 for better WhatsApp compatibility
        const tempDir = getTempDir();
        const timestamp = Date.now();
        const gifPath = path.join(tempDir, `meme_gif_${timestamp}.gif`);
        const mp4Path = path.join(tempDir, `meme_mp4_${timestamp}.mp4`);
        let mp4Buffer = null;
        try {
          // Write GIF to temp file
          fs.writeFileSync(gifPath, mediaBuffer);

          // Convert GIF to MP4 using FFmpeg
          const ffmpegCmd = `"${ffmpegPath}" -i "${gifPath}" -vf "fps=15,scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libx264 -pix_fmt yuv420p -movflags +faststart -fps_mode vfr -y "${mp4Path}"`;
          await new Promise((resolve, reject) => {
            exec(ffmpegCmd, {
              maxBuffer: 10 * 1024 * 1024
            }, error => {
              if (error) {
                reject(error);
              } else {
                resolve();
              }
            });
          });

          // Read MP4 file
          if (!fs.existsSync(mp4Path)) {
            throw new Error('MP4 output file not found');
          }
          mp4Buffer = fs.readFileSync(mp4Path);

          // Check MP4 size
          if (mp4Buffer.length > maxVideoSize) {
            throw new Error(`MP4 file too large: ${(mp4Buffer.length / 1024 / 1024).toFixed(2)}MB`);
          }

          // Send MP4 as video with gifPlayback
          const result = await sock.sendMessage(extra.from, {
            video: mp4Buffer,
            mimetype: 'video/mp4',
            gifPlayback: true
          }, {
            quoted: msg
          });
          if (!result) {
            throw new Error('Video send returned no result');
          }
        } catch (convertError) {
          // Fallback: try sending original GIF as document
          try {
            const result = await sock.sendMessage(extra.from, {
              document: mediaBuffer,
              mimetype: 'image/gif',
              fileName: `meme_${query.replace(/\s+/g, '_')}.gif`
            }, {
              quoted: msg
            });
            if (!result) {
              throw new Error('Document send returned no result');
            }
          } catch (docError) {
            throw new Error(`Failed to send meme: ${convertError.message}`);
          }
        } finally {
          // Cleanup temp files
          try {
            deleteTempFile(gifPath);
            deleteTempFile(mp4Path);
          } catch (cleanupError) {
            // Ignore cleanup errors
          }
        }
      } else if (mediaType === 'video/mp4') {
        // Check size for video
        if (mediaBuffer.length > maxVideoSize) {
          throw new Error(`Video file too large: ${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB (max 16MB)`);
        }
        await sock.sendMessage(extra.from, {
          video: mediaBuffer,
          mimetype: 'video/mp4'
        }, {
          quoted: msg
        });
      } else {
        // Check size for image
        if (mediaBuffer.length > maxImageSize) {
          throw new Error(`Image file too large: ${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB (max 5MB)`);
        }
        await sock.sendMessage(extra.from, {
          image: mediaBuffer,
          mimetype: mediaType
        }, {
          quoted: msg
        });
      }
    } catch (error) {
      await extra.reply(`❌ Failed to fetch meme: ${error.message}`);
    }
  }
};