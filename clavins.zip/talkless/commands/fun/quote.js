const APIs = require('../../utils/api');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'quote',
  aliases: ['quotes'],
  category: 'fun',
  description: 'Get a random quote',
  usage: '.quote',
  async execute(sock, msg, args, extra) {
    try { await extra.react('💡'); } catch (_) {}
    let quote;
    try {
      const result = await APIs.getQuote();
      if (typeof result?.content === 'string' && result.content.trim()) {
        quote = { content: result.content.trim(), author: typeof result.author === 'string' && result.author.trim() ? result.author.trim() : 'Unknown' };
      }
    } catch (_) {
      // Use a local quote if the quote service is unavailable.
    }
    if (!quote) quote = fallback.quote();
    await extra.reply(`💬 *Quote*\n\n“${quote.content}”\n— ${quote.author}`);
    try { await extra.react('✅'); } catch (_) {}
  }
};
