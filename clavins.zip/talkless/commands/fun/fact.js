const axios = require('axios');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'fact',
  aliases: ['randomfact'],
  category: 'fun',
  description: 'Get a random fact',
  usage: '.fact',
  async execute(sock, msg, args, extra) {
    try { await extra.react('💡'); } catch (_) {}
    let factText = '';
    try {
      const { data } = await axios.get('https://api.shizo.top/quote/quotes?apikey=shizo', { timeout: 8000 });
      if (data?.status && typeof data.result === 'string' && data.result.trim()) factText = data.result.trim();
    } catch (_) {
      // Use the built-in facts below when the upstream service is unavailable.
    }
    if (!factText) factText = fallback.fact();
    await extra.reply(`💡 *Random Fact*\n\n_${factText}_`);
    try { await extra.react('✅'); } catch (_) {}
  }
};
