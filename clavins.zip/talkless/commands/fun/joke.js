/** Joke command with a schema-checked local fallback. */
const APIs = require('../../utils/api');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'joke',
  aliases: ['jokes'],
  category: 'fun',
  description: 'Get a random joke',
  usage: '.joke',
  async execute(sock, msg, args, extra) {
    let joke;
    try {
      const result = await APIs.getJoke();
      if (typeof result?.setup === 'string' && result.setup.trim() && typeof result?.punchline === 'string' && result.punchline.trim()) {
        joke = { setup: result.setup.trim(), punchline: result.punchline.trim() };
      }
    } catch (_) {
      // The local joke list keeps the command usable during provider outages.
    }
    if (!joke) joke = fallback.joke();
    await extra.reply(`😂 *Joke*\n\n${joke.setup}\n\n${joke.punchline}`);
  }
};
