const axios = require('axios');
const fallback = require('../../utils/funFallbacks');

module.exports = {
  name: 'paranoia',
  aliases: [],
  category: 'fun',
  description: 'Get a random paranoia question',
  usage: '.paranoia',
  async execute(sock, msg, args, extra) {
    try { await extra.react('😱'); } catch (_) {}
    let question = '';
    try {
      const { data } = await axios.get('https://api.truthordarebot.xyz/v1/paranoia', { timeout: 8000 });
      const candidate = data?.question ?? data?.result;
      if (typeof candidate === 'string' && candidate.trim()) question = candidate.trim();
    } catch (_) {
      // Use a local question if the provider is unavailable.
    }
    if (!question) question = fallback.paranoia();
    await extra.reply(`😱 *Paranoia*\n\n_${question}_`);
    try { await extra.react('✅'); } catch (_) {}
  }
};
