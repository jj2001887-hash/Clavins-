const config = require('../../config');
const db = require('../../database');
module.exports = {
  name: 'setownernumber',
  aliases: ['setowner_number', 'setown'],
  category: 'owner',
  description: 'Change the bot owner number',
  usage: '.setownernumber <number>',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    try {
      let newNumber = '';
      const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
      if (mentioned && mentioned.length > 0) {
        newNumber = mentioned[0].split('@')[0];
      } else if (args.length > 0) {
        newNumber = args[0].replace(/[^0-9]/g, '');
      }
      if (!newNumber) {
        const fallback = Array.isArray(config.ownerNumber) ? config.ownerNumber[0] : config.ownerNumber;
        const current = db.getBotSetting('ownerNumber') ?? fallback;
        const prefix = db.getBotSetting('prefix') ?? config.prefix ?? '';
        return extra.reply(`📱 *Set Owner Number*\n\nCurrent: *${current}*\n\nUsage:\n${prefix}setownernumber <number>\n${prefix}setownernumber @mention`);
      }
      if (newNumber.length < 7 || newNumber.length > 15) {
        return extra.reply('❌ Invalid phone number! Must be 7-15 digits.');
      }
      db.setBotSetting('ownerNumber', newNumber);
      await extra.reply(`✅ Owner number changed to: *${newNumber}*`);
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
