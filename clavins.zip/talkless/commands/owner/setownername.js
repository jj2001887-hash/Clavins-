const config = require('../../config');
const db = require('../../database');
module.exports = {
  name: 'setownername',
  aliases: ['setowner_name'],
  category: 'owner',
  description: 'Change the bot owner display name',
  usage: '.setownername <new name>',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    try {
      let newName = '';
      const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (quotedMsg) {
        newName = (quotedMsg.conversation || quotedMsg.extendedTextMessage?.text || '').trim();
      } else {
        newName = args.join(' ').trim();
      }
      if (!newName) {
        const fallback = Array.isArray(config.ownerName) ? config.ownerName[0] : config.ownerName;
        const current = db.getBotSetting('ownerName') ?? fallback;
        const prefix = db.getBotSetting('prefix') ?? config.prefix ?? '';
        return extra.reply(`👑 *Set Owner Name*\n\nCurrent: *${current}*\n\nUsage: ${prefix}setownername <new name>`);
      }
      if (newName.length > 50) {
        return extra.reply('❌ Owner name must be 50 characters or less!');
      }
      db.setBotSetting('ownerName', newName);
      await extra.reply(`✅ Owner name changed to: *${newName}*`);
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
