const config = require('../../config');
const database = require('../../database');

module.exports = {
  name: 'anticall',
  aliases: ['ac'],
  category: 'owner',
  ownerOnly: true,
  description: 'Configure anti-call system (off, decline, block, on)',
  usage: '.anticall off|decline|block|on',
  async execute(sock, msg, args, extra) {
    const configured = database.getBotSetting('anticall');
    const enabled = configured ?? config.defaultGroupSettings?.anticall ?? false;
    if (!args[0]) {
      const current = enabled ? 'enabled' : 'disabled';
      return extra.reply(`📵 Anti-Call: *${current}*\n\nUsage: .anticall off | decline | block | on`);
    }
    const option = args[0].toLowerCase().trim();
    const valid = ['off', 'decline', 'block', 'on'];
    if (!valid.includes(option)) {
      return extra.reply('⚠️ Usage: .anticall off | decline | block | on');
    }
    const setting = option !== 'off';
    const action = option === 'decline' ? 'decline' : 'block';
    try {
      // The database resolves these writes in the active paired-session scope.
      database.setBotSetting('anticall', setting);
      database.setBotSetting('anticallAction', action);
      const replies = {
        off: '📵 Anti-Call set to *OFF*.',
        decline: '📵 Anti-Call set to *Decline*.',
        block: '🚫 Anti-Call set to *Block*.',
        on: '🚫 Anti-Call set to *Block*.'
      };
      return extra.reply(replies[option]);
    } catch (err) {
      console.error('[anticall]', err.message);
      return extra.reply('❌ Failed to update anti-call setting.');
    }
  }
};
