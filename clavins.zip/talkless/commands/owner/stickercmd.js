const { loadCommands } = require('../../utils/commandLoader');
const stickerStore = require('../../utils/stickerCommandStore');

module.exports = {
  name: 'stickercmd',
  aliases: ['setstickercmd', 'stickercommand'],
  category: 'owner',
  description: 'Bind a sticker to a bot command',
  usage: '.setstickercmd set <command> (reply to sticker) | list | remove (reply to sticker) | clear',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    const mode = String(args[0] || '').toLowerCase();
    const map = stickerStore.getMap();

    if (mode === 'list') {
      const entries = Object.entries(map);
      if (!entries.length) return extra.reply('No sticker commands are set yet. Reply to a sticker with .stickercmd set <command>.');
      const lines = entries.map(([hash, command]) => `• .${command} — ${hash.slice(0, 8)}`);
      return extra.reply(`*Sticker command aliases (${entries.length})*\n${lines.join('\n')}\n\nSend a mapped sticker to run its command. Normal command permissions still apply.`);
    }

    if (mode === 'clear') {
      stickerStore.saveMap({});
      return extra.reply(`Removed all ${Object.keys(map).length} sticker command alias(es).`);
    }

    if (['remove', 'delete', 'del'].includes(mode)) {
      const sticker = stickerStore.stickerFromMessage(msg);
      const hash = stickerStore.hashSticker(sticker);
      if (!hash) return extra.reply('Reply to the sticker you want to unbind, then use .stickercmd remove.');
      if (!Object.prototype.hasOwnProperty.call(map, hash)) return extra.reply('That sticker has no command alias.');
      const command = map[hash];
      delete map[hash];
      stickerStore.saveMap(map);
      return extra.reply(`Removed the sticker alias for .${command}.`);
    }

    const requestedName = mode === 'set' || mode === 'add' ? args[1] : args[0];
    if (!requestedName) {
      return extra.reply('Reply to a sticker with .stickercmd set <command>. Use .stickercmd list to view aliases.');
    }
    const commands = loadCommands();
    const command = commands.get(String(requestedName).toLowerCase());
    if (!command?.name) return extra.reply(`I could not find the command “${requestedName}”. Check its spelling or alias.`);

    const sticker = stickerStore.stickerFromMessage(msg);
    const hash = stickerStore.hashSticker(sticker);
    if (!hash) return extra.reply('Reply to a sticker, then use .stickercmd set <command>. I need its sticker ID to save the alias.');

    map[hash] = command.name;
    stickerStore.saveMap(map);
    return extra.reply(`Sticker alias saved: sending this sticker will run .${command.name}. The command’s normal permissions still apply.`);
  }
};
