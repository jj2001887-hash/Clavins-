const database = require('../../database');
const config = require('../../config');
const {
  jidDecode
} = require('@whiskeysockets/baileys');
async function resolveToPhone(jid, sock, groupMetadata) {
  if (!jid) return null;
  const raw = jid.split('@')[0].split(':')[0];
  if (jid.includes('@lid')) {
    const participant = groupMetadata?.participants?.find(p => p.id === jid || p.lid === jid || p.jid === jid);
    const participantPn = participant?.phoneNumber || participant?.pn || participant?.phone;
    if (participantPn) return String(participantPn).split('@')[0].replace(/\D/g, '');
    try {
      const mapped = await sock.signalRepository?.lidMapping?.getPNForLID?.(jid);
      if (mapped) return String(mapped).split('@')[0].replace(/\D/g, '');
    } catch (_) {}
    const fs = require('fs');
    const path = require('path');
    const sessionPath = path.join(__dirname, '../../', config.sessionName || 'session');
    const revFile = path.join(sessionPath, `lid-mapping-${raw}_reverse.json`);
    if (fs.existsSync(revFile)) {
      try {
        const pn = JSON.parse(fs.readFileSync(revFile, 'utf8').trim());
        if (pn) return String(pn);
      } catch (_) {}
    }
    return null;
  }
  return raw;
}
module.exports = {
  name: 'addsudo',
  aliases: ['addmod', 'setsudo'],
  category: 'owner',
  description: 'Add a sudo (moderator) user who can use owner-level commands',
  usage: '.addsudo @user or .addsudo number',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    const { from, reply, react, groupMetadata } = extra;
    const context = msg.message?.extendedTextMessage?.contextInfo || msg.message?.contextInfo || {};
    const mentioned = context.mentionedJid || [];
    const quoted = context.participant || null;
    let targetJid = mentioned[0] || quoted || null;
    if (!targetJid && args[0]) {
      const raw = args[0].trim();
      const explicitJid = raw.match(/\d+(?::\d+)?@(s\.whatsapp\.net|lid)/i)?.[0];
      const taggedNumber = raw.match(/^@?(\d{7,})$/)?.[1];
      if (explicitJid) targetJid = explicitJid;
      else if (taggedNumber) targetJid = `${taggedNumber}@s.whatsapp.net`;
    }
    if (!targetJid) {
      return reply(`❌ *How to add a sudo user*\n\nTag someone: ${config.prefix}addsudo @user\nOr use their international phone number: ${config.prefix}addsudo 254712345678`);
    }
    let number = await resolveToPhone(targetJid, sock, groupMetadata);
    if (!number) {
      return reply(`❌ I couldn't identify that tagged account.\n\nTry tagging the person again, or use their international phone number:\n${config.prefix}addsudo 254712345678`);
    }
    number = number.replace(/\D/g, '');
    if (number.length < 7) return reply('❌ That does not look like a valid phone number. Include the country code.');
    if (database.isModerator(number)) {
      return sock.sendMessage(from, {
        text: `⚠️ *TALKLESS XMD*\n\n@${number} is already a sudo user.`,
        mentions: [`${number}@s.whatsapp.net`]
      }, {
        quoted: msg
      });
    }
    database.addModerator(number);
    await react('✅');
    const mentionJid = `${number}@s.whatsapp.net`;
    await sock.sendMessage(from, {
      text: `✅ *TALKLESS XMD — Sudo Added*\n\n@${number} has been added as a sudo user and can now use moderator-level commands.`,
      mentions: [mentionJid]
    }, {
      quoted: msg
    });
  }
};
