const groupStats = require('../../utils/groupstats');

function jidTokens(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return [];
  const [userPart, domain = ''] = raw.split('@');
  const base = userPart.split(':')[0];
  const tokens = [`jid:${domain}:${base}`];
  if (domain === 's.whatsapp.net' || !domain) {
    const digits = base.replace(/\D/g, '');
    if (digits) tokens.push(`pn:${digits}`);
  }
  if (domain === 'lid') tokens.push(`lid:${base}`);
  return tokens;
}

function participantValues(participant) {
  return [participant?.id, participant?.jid, participant?.lid, participant?.phoneNumber, participant?.pn].filter(Boolean);
}

function mentionJid(participant) {
  const value = participant?.phoneNumber || participant?.pn || participant?.id || participant?.jid || participant?.lid || '';
  const text = String(value);
  if (text.includes('@')) return text;
  const digits = text.replace(/\D/g, '');
  return digits ? `${digits}@s.whatsapp.net` : '';
}

module.exports = {
  name: 'listoffline',
  aliases: ['listinactive', 'inactiveusers', 'inactivemembers'],
  category: 'admin',
  description: 'List members with no activity recorded by the bot',
  usage: '.listoffline',
  groupOnly: true,
  adminOnly: true,
  async execute(sock, msg, args, extra) {
    const { from, isGroup, reply, groupName } = extra;
    if (!isGroup) return reply('This command can only be used in a group.');

    try {
      const metadata = await sock.groupMetadata(from);
      const participants = Array.isArray(metadata.participants) ? metadata.participants : [];
      if (!participants.length) return reply('I could not read the member list for this group.');

      const activeRecords = groupStats.getActiveUsers(from, Number.MAX_SAFE_INTEGER);
      if (!activeRecords.length) {
        return reply('No group activity has been recorded yet, so I cannot identify inactive members. I will track messages as they arrive.');
      }

      const inactive = groupStats.getInactiveUsers(from, participants);
      const botTokens = new Set([sock.user?.id, sock.user?.lid].filter(Boolean).flatMap(jidTokens));
      const results = inactive.filter(participant => {
        if (!mentionJid(participant)) return false;
        const tokens = participantValues(participant).flatMap(jidTokens);
        return !tokens.some(token => botTokens.has(token));
      });
      if (!results.length) return reply('No members without recorded activity were found in the available group history.');

      const mentions = results.map(mentionJid).filter(Boolean);
      const lines = results.map((participant, index) => {
        const jid = mentionJid(participant);
        return `• ${index + 1}. @${String(jid).split('@')[0].split(':')[0]}`;
      });
      const text = `*INACTIVE MEMBERS — ${groupName || metadata.subject || 'Group'}*\n\nNo messages are recorded for these members in the bot’s available activity history:\n${lines.join('\n')}\n\nTotal: ${results.length}`;
      await sock.sendMessage(from, { text, mentions }, { quoted: msg });
    } catch (error) {
      console.error('[listoffline] Could not read group activity:', error.message);
      await reply('I could not load the group’s activity list. Please try again.');
    }
  }
};
