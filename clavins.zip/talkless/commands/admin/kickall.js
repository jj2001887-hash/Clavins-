function jidTokens(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return [];
  const [userPart, domain = ''] = raw.split('@');
  const base = userPart.split(':')[0];
  const tokens = [`jid:${domain}:${base}`];
  if (domain === 's.whatsapp.net' || !domain) {
    const digits = base.replace(/\D/g, '');
    if (digits) tokens.push(`pn:${digits}`);
  }
  if (domain === 'lid') tokens.push(`lid:${base}`);
  return tokens;
}

function participantValues(participant) {
  return [participant?.id, participant?.jid, participant?.lid, participant?.phoneNumber, participant?.pn].filter(Boolean);
}

function getTargets(metadata, sock, extra) {
  const selfTokens = new Set([
    sock.user?.id,
    sock.user?.lid,
    extra.sender,
    metadata.owner,
    metadata.creator
  ].flatMap(jidTokens));
  const participants = Array.isArray(metadata.participants) ? metadata.participants : [];
  return [...new Set(participants
    .filter(participant => {
      if (participant.admin === 'admin' || participant.admin === 'superadmin') return false;
      const tokens = participantValues(participant).flatMap(jidTokens);
      return !tokens.some(token => selfTokens.has(token));
    })
    .map(participant => participant.id || participant.jid || participant.lid || participant.phoneNumber || participant.pn)
    .filter(Boolean))];
}

const CHUNK_SIZE = 10;
const CHUNK_DELAY_MS = 250;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

function countChunkResult(result, chunk) {
  if (Array.isArray(result)) {
    let removed = 0;
    let failed = 0;
    for (let index = 0; index < chunk.length; index++) {
      const row = result[index];
      const status = row?.status == null ? NaN : Number(row.status);
      if (!row || (Number.isFinite(status) && status >= 300)) failed++;
      else removed++;
    }
    return { removed, failed };
  }
  const status = result?.status == null ? NaN : Number(result.status);
  if (Number.isFinite(status) && status >= 300) return { removed: 0, failed: chunk.length };
  return { removed: chunk.length, failed: 0 };
}

module.exports = {
  name: 'kickall',
  aliases: ['removeall'],
  category: 'admin',
  description: 'Remove eligible group members in small batches (group admins only)',
  usage: '.kickall',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(sock, msg, args, extra) {
    const chatId = extra.from;
    let missionStarted = false;
    try {
      const metadata = await sock.groupMetadata(chatId);
      const targets = getTargets(metadata, sock, extra);
      if (!targets.length) {
        return extra.reply('There are no removable members. The paired account, bot, and group creator are protected.');
      }

      await sock.sendMessage(chatId, {
        text: '⚠️ *TALKLESS XMD*\n\n*Mission started: Terminating this group.*\nRemoving eligible members in small batches...'
      }, { quoted: msg });
      missionStarted = true;

      let removed = 0;
      let failed = 0;
      let processed = 0;
      let stoppedAfterError = false;
      for (let offset = 0; offset < targets.length; offset += CHUNK_SIZE) {
        const chunk = targets.slice(offset, offset + CHUNK_SIZE);
        try {
          const result = await sock.groupParticipantsUpdate(chatId, chunk, 'remove');
          const counts = countChunkResult(result, chunk);
          removed += counts.removed;
          failed += counts.failed;
          processed += chunk.length;
        } catch (error) {
          console.error(`[kickall] Batch ${Math.floor(offset / CHUNK_SIZE) + 1} failed:`, error.message);
          failed += chunk.length;
          processed += chunk.length;
          stoppedAfterError = true;
          break;
        }
        if (offset + CHUNK_SIZE < targets.length) await wait(CHUNK_DELAY_MS);
      }

      const notAttempted = targets.length - processed;
      const success = failed === 0 && notAttempted === 0;
      let completion;
      if (success) {
        completion = `✅ *TALKLESS XMD*\n\n*Mission complete: Terminating this group.*\nRemoved ${removed} eligible member(s). The paired account, bot, and group creator were preserved.`;
      } else {
        const details = [
          `Removed ${removed} of ${targets.length} eligible member(s).`,
          failed ? `${failed} member(s) failed or could not be confirmed.` : '',
          notAttempted ? `${notAttempted} member(s) were not attempted after a batch error.` : ''
        ].filter(Boolean).join('\n');
        completion = `⚠️ *TALKLESS XMD*\n\n*Mission ended with members remaining.*\n${details}`;
      }
      await sock.sendMessage(chatId, { text: completion }, { quoted: msg });
    } catch (error) {
      console.error('[kickall] Bulk removal failed:', error.message);
      const failure = '⚠️ *TALKLESS XMD*\n\nTermination could not complete. Check that the bot is a group admin and try again.';
      if (missionStarted) {
        await sock.sendMessage(chatId, { text: failure }, { quoted: msg });
      } else {
        await extra.reply(failure);
      }
    }
  }
};
