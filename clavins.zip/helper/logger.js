// ============================================================
//   helper/logger.js  –  console output for TALKLESS / CLAVOHH
// ------------------------------------------------------------
//   Styling ported from TALKLESS XMD (helper/logger.js):
//     * colour is FORCED (chalk.level = 3) — a panel/VPS console is
//       not a TTY, so chalk would otherwise strip every escape code
//       and the output looked plain
//     * lolcatjs is used byte-for-byte when it happens to be
//       installed; otherwise the same rainbow is drawn with chalk
//     * every line carries a blue-bold [ TALKLESS XMD ] tag
//     * the startup art and the status box are rainbow
// ============================================================
'use strict';

process.env.FORCE_COLOR = process.env.FORCE_COLOR || '3';

const chalk = require('chalk');

let moment = null;
try { moment = require('moment-timezone'); } catch (_) { /* optional */ }

try { chalk.level = 3; } catch (_) { /* older chalk */ }

const lolcat = (() => {
  try { return require('lolcatjs'); } catch { return null; }
})();

const BRAND = process.env.BOT_BRAND || process.env.BOT_NAME || 'TALKLESS XMD';
const VERSION = process.env.BOT_VERSION || '3.1.0';

/* ── palette ─────────────────────────────────────────────────── */

const colors = {
  brand: chalk.hex('#0066FF'),
  telegram: chalk.hex('#0088cc'),
  whatsapp: chalk.hex('#25D366'),
  system: chalk.hex('#FFA500'),
  error: chalk.hex('#FF0000'),
  success: chalk.hex('#00FF00'),
  user: chalk.hex('#FFD700'),
  command: chalk.hex('#FF00FF'),
  group: chalk.hex('#00CED1'),
  dm: chalk.hex('#FF69B4'),
  rainbow: chalk.hex('#00A2FF'),
};

/* ── rainbow ─────────────────────────────────────────────────── */

function hsvToRgb(h, s, v) {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; }
  else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; }
  else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; }
  else { r = c; b = x; }
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}

// Cycles a full hue roughly every 70 characters and shifts on each block, so
// consecutive lines of a banner are coloured differently.
let phase = 0;
function rainbow(text) {
  let out = '';
  let colourIndex = phase;
  for (const ch of String(text)) {
    if (ch === '\n') { out += ch; continue; }
    const rgb = hsvToRgb((colourIndex * 5.1 + phase * 37) % 360, 1, 1);
    out += chalk.rgb(rgb[0], rgb[1], rgb[2])(ch);
    colourIndex += 1;
  }
  phase += 11;
  return out;
}

/** Rainbow through lolcatjs when available, otherwise through chalk. */
function rainbowPrint(text) {
  if (lolcat && typeof lolcat.fromString === 'function') {
    try { lolcat.fromString(String(text)); return; } catch (_) { /* fall through */ }
  }
  console.log(rainbow(text));
}

const logRainbow = (text) => {
  if (String(text).includes('\n')) rainbowPrint(text);
  else console.log(rainbow(text));
};

/* ── tagged lines ────────────────────────────────────────────── */

const getTime = () => {
  try {
    if (moment) return moment.tz ? moment.tz('Africa/Nairobi').format('HH:mm:ss') : moment().format('HH:mm:ss');
  } catch (_) { /* fall through */ }
  return new Date().toTimeString().slice(0, 8);
};

const tag = () => chalk.blue.bold(`[ ${BRAND} ]`);

// Accepts both call styles used in this project:
//   logInfo('WEBSITE', 'message')   logInfo('message')
function pair(a, b) {
  if (b === undefined) return { label: null, message: String(a == null ? '' : a) };
  return { label: String(a), message: String(b == null ? '' : b) };
}
const body = (label, message, paint) => {
  const head = label ? chalk.white.bold(label) : '';
  return label
    ? `${head}${chalk.gray(' – ')}${paint(message)}`
    : paint(message);
};

const logInfo = (a, b) => {
  const { label, message } = pair(a, b);
  console.log(`${tag()} ${colors.system('[INFO]')} ${body(label, message, chalk.gray)}`);
};
const logSuccess = (a, b) => {
  const { label, message } = pair(a, b);
  console.log(`${tag()} ${colors.success('[OK]  ')} ${body(label, message, chalk.white)}`);
};
const logWarn = (a, b) => {
  const { label, message } = pair(a, b);
  console.error(`${tag()} ${chalk.yellow('[WARN]')} ${body(label, message, chalk.yellowBright)}`);
};
const logError = (a, b) => {
  const { label, message } = pair(a, b);
  console.error(`${tag()} ${colors.error('[ERR] ')} ${body(label, message, chalk.redBright)}`);
};

const logSystem = (message, type = 'info') => {
  const paint = type === 'error' ? colors.error : type === 'success' ? colors.success : colors.system;
  const icon = type === 'error' ? '❌' : type === 'success' ? '✅' : '📡';
  console.log(`${tag()} ${paint(`${icon} [${getTime()}] ${message}`)}`);
};

/* ── session line ────────────────────────────────────────────── */

const logSession = (sessionId, status) => {
  const icon = status === 'connected' ? '🟢' : status === 'reconnecting' ? '🟡' : '🔴';
  console.log(`${tag()} ${chalk.gray('session')} ${chalk.bold(sessionId)} ${icon} ${chalk.gray(status)}`);
};

/* ── message boxes ───────────────────────────────────────────── */

const icons = {
  text: '💬', image: '🖼️', video: '🎥', audio: '🎵', sticker: '🌀',
  document: '📄', location: '📍', contact: '👤', reaction: '❤️', poll: '📊',
  viewOnce: '👁️', unknown: '❓',
};

function getMsgType(msg) {
  if (!msg) return 'unknown';
  if (msg.conversation || msg.extendedTextMessage) return 'text';
  if (msg.imageMessage) return 'image';
  if (msg.videoMessage) return 'video';
  if (msg.audioMessage) return 'audio';
  if (msg.stickerMessage) return 'sticker';
  if (msg.documentMessage) return 'document';
  if (msg.locationMessage) return 'location';
  if (msg.contactMessage) return 'contact';
  if (msg.reactionMessage) return 'reaction';
  if (msg.pollCreationMessage) return 'poll';
  if (msg.viewOnceMessage || msg.viewOnceMessageV2) return 'viewOnce';
  return 'unknown';
}

function getMsgText(msg) {
  if (!msg) return '';
  return (
    msg.conversation ||
    msg.extendedTextMessage?.text ||
    msg.imageMessage?.caption ||
    msg.videoMessage?.caption ||
    msg.documentMessage?.caption ||
    msg.reactionMessage?.text ||
    msg.pollCreationMessage?.name ||
    (msg.locationMessage
      ? `[${msg.locationMessage?.degreesLatitude?.toFixed(4)}, ${msg.locationMessage?.degreesLongitude?.toFixed(4)}]`
      : '') ||
    msg.contactMessage?.displayName ||
    ''
  );
}

const WIDTH = 59;
const bar = (color, char) => color(char.repeat(WIDTH));

function logMessage(m, chatMeta = {}) {
  try {
    const msg = m.message;
    let realMsg = msg;
    for (const w of ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension']) {
      if (realMsg?.[w]?.message) realMsg = realMsg[w].message;
    }

    const type = getMsgType(realMsg);
    const icon = icons[type] || icons.unknown;
    const text = getMsgText(realMsg).slice(0, 150);
    const sender = (m.key.participant || m.key.remoteJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const name = m.pushName || sender;
    const jid = m.key.remoteJid || '';
    const isGroup = jid.endsWith('@g.us');
    const isChannel = jid.endsWith('@newsletter');

    let title = 'PRIVATE MESSAGE';
    if ((isGroup || isChannel) && chatMeta.groupName) title = chatMeta.groupName;
    if (title.length > 30) title = title.slice(0, 30) + '…';

    const label = colors.brand;
    const value = chalk.white;
    const accent = chalk.hex('#ff6b6b');
    const border = chalk.hex('#555555');
    const titleColor = chalk.hex('#ffa500').bold;

    console.log('\\n' + bar(colors.whatsapp, '═'));
    console.log(rainbow(`  ${title}`));
    console.log(bar(colors.whatsapp, '─'));
    console.log(`  ${chalk.bold('Type: ')}${value(icon + ' ' + type)}`);
    console.log(`  ${chalk.bold('Time: ')}${chalk.gray(getTime())}`);
    console.log(`  ${chalk.bold('Sender: ')}${value(sender)}`);
    console.log(`  ${chalk.bold('Name: ')}${value(name)}`);
    console.log(`  ${chalk.bold('Chat: ')}${value(jid || 'N/A')}`);
    if (text) console.log(`  ${chalk.bold('Message: ')}${value(text)}`);
    console.log(bar(colors.whatsapp, '═') + '\n');
  } catch (e) {
    console.log(chalk.gray('─'.repeat(60)));
    console.log(chalk.yellow('⚠️  Logger error:'), e.message);
    console.log(chalk.gray('─'.repeat(60)));
  }
}

/* ── startup art + status box (rainbow) ──────────────────────── */

const ART = `
⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⢛⡛⠿⠛⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡿⠟⡉⣡⡖⠘⢗⣀⣀⡀⢢⣐⣤⣉⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⡿⠉⣠⣲⣾⡭⣀⢟⣩⣶⣶⡦⠈⣿⣿⣿⣷⣖⠍⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⡛⢀⠚⢩⠍⠀⠀⠡⠾⠿⣋⡥⠀⣤⠈⢷⠹⣿⣎⢳⣶⡘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⡏⢀⡤⠉⠀⠀⠀⣴⠆⠠⠾⠋⠁⣼⡿⢰⣸⣇⢿⣿⡎⣿⡷⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⠀⢸⢧⠁⠀⠀⢸⠇⢐⣂⣠⡴⠶⣮⢡⣿⢃⡟⡘⣿⣿⢸⣷⡀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣯⢀⡏⡾⢠⣿⣶⠏⣦⢀⠈⠉⡙⢻⡏⣾⡏⣼⠇⢳⣿⡇⣼⡿⡁⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⠈⡇⡇⡘⢏⡃⠀⢿⣶⣾⣷⣿⣿⣿⡘⡸⠇⠌⣾⢏⡼⣿⠇⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⡀⠀⢇⠃⢢⡙⣜⣾⣿⣿⣿⣿⣿⣿⣧⣦⣄⡚⣡⡾⣣⠏⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣷⡀⡀⠃⠸⣧⠘⢿⣿⣿⣿⣿⣿⣻⣿⣿⣿⣿⠃⠘⠁⢈⣤⡀⣬⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣇⣅⠀⠀⠸⠀⣦⡙⢿⣿⣿⣿⣿⣿⣿⡿⠃⢀⣴⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⡿⢛⣉⣉⣀⡀⠀⢸⣿⣿⣷⣬⣛⠛⢛⣩⣵⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⢋⣴⣿⣿⣿⣿⣿⣦⣬⣛⣻⠿⢿⣿⡇⠈⠙⢛⣛⣩⣭⣭⣝⡛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⡇⣼⣿⣿⣿⣿⣿⡿⡹⢿⣿⣽⣭⣭⣭⣄⣙⠻⢿⣿⡿⣝⣛⣛⡻⢆⠙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⢥⣿⣿⣿⣿⣿⣿⢇⣴⣿⣿⣿⣿⣿⡿⣿⣿⣿⣷⣌⢻⣿⣿⣿⣿⣿⣷⣶⣌⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿
⡆⣿⣿⣿⣿⣿⡟⣸⣿⣿⣿⣿⣿⣿⣄⣸⣿⣿⣿⣿⣦⢻⣿⣿⣿⣿⣿⣿⣿⠁⠊⠻⣿⣿⣿⣿⣿⣿⣿
⣿⠸⣿⣿⣿⣿⡇⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣷⣿⠀⣿⣿⣿⣿⣿⣿⣿
⣿⣄⢻⣿⣿⣿⣿⡸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⢀⣿⣿⣿⣿⣿⣿⣿
⣿⣿⠈⣿⣿⣿⣿⣷⢙⠿⣿⣿⣿⣿⣿⣿⣿⠿⣟⣩⣴⣷⣌⠻⣿⣿⣿⣿⣿⣿⡟⢠⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣆⢻⣿⣿⣿⣿⡇⣷⣶⣭⣭⣭⣵⣶⣾⣿⣿⣿⣿⣿⣿⣷⣌⠹⢿⣿⡿⢋⣠⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⡚⣿⣿⣿⣿⡇⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⢀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⡇⢻⣿⣿⣿⡇⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣷⠈⣿⣿⣿⣿⢆⠀⢋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣿⣿⣥⡘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⠀⣻⣿⣿⣿⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣎⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣒⣻⣿⣿⢏⣿⣿𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣇⢹⣿⡏⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣿⣿⣿⣿⣿⣷⣬⡻⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⡄⠻⢱⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣝⢎⢻⣿⣿⣿
⣿⣿⣿⣿⣿⣷⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣾⣦⢻⣿⣿
⣿⣿⣿⣿⣿⡇⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣼⣿⣿⣿⣿⣆⢻⣿
⣿⣿⣿⣿⡿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⡙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣰⣿⣿⣿⣿⣿⣿⣆⣿
⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣝⢿⣿⣿⣿⣿⣿⣿⣿⢡⣿⣿⣿⣿⣿⣿⣿⣿⡎
⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣝⢿⣿⡆⢿⣿⡿⢸⣿⣿⣿⣿⣿⣿⣿⣿⡇
⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⢻⣿⢸⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷
⣿⣿⣿⣿⣧⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⢹⠸⠁⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⡌⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⢰⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣷⡘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡌⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀`;

/**
 * Prints the rainbow art and a status box.
 * The box reports which entry points are actually configured instead of
 * always claiming everything is online.
 *
 * @param {{telegram?: boolean, website?: boolean}} [modes]
 */
const logBanner = (modes = {}) => {
  try { console.clear(); } catch (_) { /* not a TTY */ }
  rainbowPrint(ART);

  const BOX = 46;
  const row = (plain, colored) =>
    chalk.blue('║') + ' ' + colored + ' '.repeat(Math.max(0, BOX - 1 - plain.length)) + chalk.blue('║');

  const telegramState = modes.telegram === false ? 'OFF (no token)' : 'ONLINE';
  const websiteState = modes.website === false ? 'OFF (no database)' : 'ONLINE';

  console.log(rainbow('╔' + '═'.repeat(BOX) + '╗'));
  console.log(row(`👑 ${BRAND} 👑`, chalk.white.bold(`👑 ${BRAND} 👑`)));
  console.log(rainbow('╠' + '═'.repeat(BOX) + '╣'));
  console.log(row(`Version : ${VERSION}`, chalk.white('Version : ') + chalk.cyan(VERSION)));
  console.log(row(`Telegram: ${telegramState}`,
    chalk.white('Telegram: ') + (modes.telegram === false ? chalk.yellow(telegramState) : chalk.green(telegramState))));
  console.log(row(`Website : ${websiteState}`,
    chalk.white('Website : ') + (modes.website === false ? chalk.yellow(websiteState) : chalk.green(websiteState))));
  console.log(row(`Time    : ${getTime()}`, chalk.white('Time    : ') + chalk.gray(getTime())));
  console.log(rainbow('╚' + '═'.repeat(BOX) + '╝'));
  console.log('');
};

module.exports = {
  BRAND,
  VERSION,
  ART,
  colors,
  rainbow,
  rainbowPrint,
  logRainbow,
  logBanner,
  logInfo,
  logSuccess,
  logWarn,
  logError,
  logSystem,
  logSession,
  logMessage,
  getMsgType,
  getMsgText,
  getTime,
};
