// ============================================================
//   helper/web-pairing.js  –  the website <-> WhatsApp bridge
//
//   The pairing website (Vercel) never talks to this process directly.
//   It writes rows to Neon; this module polls them and answers by
//   updating the same rows. Three queues, all in one place:
//
//     talkless_pairing_requests     site asks for a code  -> code written back
//     talkless_session_submissions  "TALKLESS!<base64>" pasted on the site
//     talkless_session_imports      /session page imports
//
//   Every flow reports connected / failed, and talkless_sessions is
//   mirrored on each socket event so the site's counters are real.
//
//   Wire-up (index.js):
//     webPairing.startAll({ startWhatsApp })            at boot
//     webPairing.onSocketOpen(waNum)                    on connection === 'open'
//     webPairing.onSocketClose(sessionId, statusCode)   on connection === 'close'
// ============================================================
'use strict';

const fs   = require('fs');
const path = require('path');
const db   = require('./neon-db');
const { sessionDir, listSessions, deleteSession } = require('./function');

const LABEL = '[WEB]';
const log   = (...a) => console.log(LABEL, ...a);
const warn  = (...a) => console.warn(LABEL, ...a);
const fail  = (...a) => console.error(LABEL, ...a);

// A 24/7 panel host with a wrong URL would otherwise repeat the same error on
// every poll. Same message: at most once a minute.
const _lastLog = new Map();
function failThrottled(key, error) {
  const message = error && (error.message || String(error));
  const last = _lastLog.get(key) || { message: null, at: 0 };
  const now = Date.now();
  if (message === last.message && now - last.at < 60000) return;
  _lastLog.set(key, { message, at: now });
  fail(`${key}:`, message);
}

const POLL_PAIRING_MS     = 3000;
const POLL_SUBMISSION_MS  = 5000;
const POLL_IMPORT_MS      = 8000;
const PAIRING_TIMEOUT_MS  = 90000;
const IMPORT_TIMEOUT_MS   = 45000;

const digits = (v) => String(v == null ? '' : v).replace(/\D/g, '');

// phone -> pairing request id (so the socket can close the website row)
const pendingRequests = new Map();
// phone -> { id, timer } for the /session import queue
const pendingImports = new Map();

let starter = null;              // startWhatsApp from index.js
let pairingLoop = false;
let submissionLoop = false;
let importLoop = false;
let busy = { pairing: false, submission: false, import: false };

// ── small SQL helpers ────────────────────────────────────────
async function claimPairingRequest() {
  const { rows } = await db.query(
    `UPDATE ${db.TABLES.requests} SET status = 'processing', updated_at = now()
      WHERE id = (SELECT id FROM ${db.TABLES.requests}
                   WHERE status = 'pending' AND expires_at > now()
                   ORDER BY id LIMIT 1)
      RETURNING *`);
  return rows[0] || null;
}

async function setPairingCode(id, code) {
  await db.query(
    `UPDATE ${db.TABLES.requests} SET status = 'code_generated', pairing_code = $1, updated_at = now() WHERE id = $2`,
    [code, id]);
}

async function markPairingFailed(id, error) {
  await db.query(
    `UPDATE ${db.TABLES.requests} SET status = 'failed', error = $1, updated_at = now() WHERE id = $2`,
    [String(error || 'unknown reason').slice(0, 300), id]);
}

async function markPairingConnected(id) {
  await db.query(
    `UPDATE ${db.TABLES.requests} SET status = 'connected', updated_at = now() WHERE id = $1`,
    [id]);
}

async function claimSubmission() {
  try {
    const { rows } = await db.query(
      `UPDATE ${db.TABLES.submissions} s
          SET status = 'claimed', claimed_at = now(), error = NULL
        WHERE s.id = (SELECT id FROM ${db.TABLES.submissions}
                       WHERE status = 'pending' ORDER BY id ASC LIMIT 1
                       FOR UPDATE SKIP LOCKED)
        RETURNING s.id, s.phone, s.session`);
    return rows[0] || null;
  } catch (error) {
    if (!/does not exist/i.test(error.message || '')) {
      failThrottled('submission claim', error);
    }
    return null;
  }
}

async function setSubmissionStatus(id, status, error) {
  try {
    await db.query(
      `UPDATE ${db.TABLES.submissions} SET status = $2, error = $3 WHERE id = $1`,
      [id, status, error || null]);
  } catch (error) {
    fail('submission status failed:', error.message);
  }
}

async function markSubmissionByPhone(phone, status, error) {
  if (!phone) return;
  try {
    await db.query(
      `UPDATE ${db.TABLES.submissions} SET status = $2, error = $3
        WHERE phone = $1 AND status IN ('pending', 'claimed', 'connecting')`,
      [String(phone), status, error || null]);
  } catch (_) { /* table may not exist yet */ }
}

async function claimImport() {
  try {
    const { rows } = await db.query(
      `UPDATE ${db.TABLES.imports} SET status = 'claimed', updated_at = now()
        WHERE id = (SELECT id FROM ${db.TABLES.imports}
                     WHERE status = 'pending' AND expires_at > now()
                     ORDER BY id LIMIT 1
                     FOR UPDATE SKIP LOCKED)
        RETURNING id, phone, payload`);
    return rows[0] || null;
  } catch (error) {
    if (!/does not exist/i.test(error.message || '')) {
      failThrottled('import claim', error);
    }
    return null;
  }
}

async function setImportStatus(id, status, error) {
  try {
    await db.query(
      `UPDATE ${db.TABLES.imports}
          SET status = $2, error = $3, payload = NULL, updated_at = now()
        WHERE id = $1`,
      [id, status, String(error || '').slice(0, 300) || null]);
  } catch (e) {
    fail('import status failed:', e.message);
  }
}

/** Mirrors the live session list so the website's stats are not invented. */
async function upsertSession(sessionId, phone, status) {
  try {
    await db.query(
      `INSERT INTO ${db.TABLES.sessions} (id, phone, status, updated_at) VALUES ($1, $2, $3, now())
       ON CONFLICT (id) DO UPDATE SET phone = EXCLUDED.phone, status = EXCLUDED.status, updated_at = now()`,
      [sessionId, phone || null, status]);
  } catch (_) { /* stats only - never crash the socket */ }
}

// ── session helpers ─────────────────────────────────────────
const SESSION_PREFIX = 'wa_web_';

/** A number that already has a folder or a live socket must not be paired twice. */
function findSessionForPhone(phone) {
  const target = digits(phone);
  if (!target) return null;
  try {
    const socks = global._activeSockets;
    if (socks && typeof socks.forEach === 'function') {
      for (const [sid, sock] of socks) {
        if (String(sock?.__waNum || '') === target) return sid;
      }
    }
    for (const sid of listSessions()) {
      if (sid === target || sid.endsWith('_' + target)) return sid;
    }
  } catch (_) { /* fall through */ }
  return null;
}

/**
 * Archive (never delete) the previous folder. Wiping creds.json while the
 * device is still linked leaves the phone sending messages nothing can
 * decrypt; a rename keeps the old device working.
 */
function archiveSessionFolder(dir, key) {
  if (!fs.existsSync(dir)) return;
  try {
    const bak = path.join(path.dirname(dir), '.backup');
    fs.mkdirSync(bak, { recursive: true });
    const dst = path.join(bak, `${key}_${Date.now()}`);
    fs.renameSync(dir, dst);
    warn('previous session archived before re-pair:', dst);
    const olds = fs.readdirSync(bak).filter((n) => n.startsWith(key + '_')).sort();
    while (olds.length > 3) {
      const old = olds.shift();
      try { fs.rmSync(path.join(bak, old), { recursive: true, force: true }); } catch (_) {}
    }
  } catch (error) {
    warn('could not archive session:', error.message);
  }
}

function writeCreds(sessionId, creds) {
  const dir = sessionDir(sessionId);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'creds.json'), JSON.stringify(creds, null, 2));
  return dir;
}

/** Decode "TALKLESS!<base64>" / bare base64 / raw creds JSON. */
function decodeSession(raw) {
  // People paste from Telegram/WhatsApp, so fences, stray newlines and
  // private_chat formatting are all normal input, not corruption.
  const text = String(raw || '').replace(/```[a-z]*/gi, '').trim();
  if (!text) throw new Error('Session string is empty.');

  let parsed;
  if (text.startsWith('{')) {
    parsed = JSON.parse(text);
  } else {
    const b64 = text
      .replace(/^talkless(-?md)?!/i, '')
      .replace(/\s+/g, '')
      .replace(/-/g, '+')
      .replace(/_/g, '/');
    parsed = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
  }

  const payload = parsed.creds || parsed;
  if (!payload || !payload.me || !payload.me.id) throw new Error('Session has no creds.me.id.');
  return payload;
}

/** Reuse the folder already holding this number, otherwise create wa_web_<phone>. */
function sessionIdForPhone(phone) {
  const existing = findSessionForPhone(phone);
  return existing || SESSION_PREFIX + digits(phone);
}

// ── queue 1: website pairing requests ───────────────────────
async function runPairingRequest() {
  const row = await claimPairingRequest();
  if (!row) return;

  const phone = digits(row.phone);
  log(`pairing request #${row.id} for +${phone} claimed from the website`);
  if (!phone) return markPairingFailed(row.id, 'Request has no usable phone number.');

  const existing = findSessionForPhone(phone);
  if (existing) {
    // A folder that is not live can be re-paired: archive it first.
    const live = global._activeSockets && global._activeSockets.has(existing);
    if (live) return markPairingFailed(row.id, 'This number is already connected.');
    archiveSessionFolder(sessionDir(existing), existing);
  }

  const sessionId = SESSION_PREFIX + phone;
  archiveSessionFolder(sessionDir(sessionId), sessionId);

  // Watchdog: leave nothing stuck in 'processing' if WhatsApp stays silent.
  const watchdog = setTimeout(() => {
    db.query(`SELECT status FROM ${db.TABLES.requests} WHERE id = $1`, [row.id])
      .then(({ rows }) => {
        if (rows[0] && rows[0].status === 'processing') {
          return markPairingFailed(row.id, 'Timed out waiting for WhatsApp pairing code.');
        }
      })
      .catch(() => {});
  }, PAIRING_TIMEOUT_MS);

  let codeWritten = false;
  try {
    const code = await starter(sessionId, null, phone, null, async (value) => {
      clearTimeout(watchdog);
      codeWritten = true;
      await setPairingCode(row.id, String(value));
    });
    clearTimeout(watchdog);
    // startWhatsApp resolves with the socket, not the code: only a real
    // eight-character code is written back here.
    const codeText = typeof code === 'string' ? code.trim().toUpperCase() : '';
    if (!codeWritten && /^[A-Z0-9]{8}$/.test(codeText)) {
      await setPairingCode(row.id, codeText);
    } else if (!codeWritten) {
      warn(`pairing #${row.id}: WhatsApp did not hand back a code yet (the callback decides).`);
    }
    pendingRequests.set(phone, row.id);
  } catch (error) {
    clearTimeout(watchdog);
    fail(`pairing #${row.id} failed:`, error.message);
    await markPairingFailed(row.id, error.message);
  }
}

// ── queue 2: session strings pasted on the website ──────────
async function runSubmission() {
  const row = await claimSubmission();
  if (!row) return;

  const { id, phone, session } = row;
  if (!session || !phone) return setSubmissionStatus(id, 'failed', 'Empty submission.');

  try {
    const creds = decodeSession(session);
    const number = digits(creds.me.id.split('@')[0].split(':')[0]) || digits(phone);
    const sessionId = sessionIdForPhone(number);

    writeCreds(sessionId, creds);
    await setSubmissionStatus(id, 'connecting');
    await starter(sessionId, null, null, null);
    log('pasted session accepted for', number, '->', sessionId);
  } catch (error) {
    fail('pasted session failed:', error.message);
    await setSubmissionStatus(id, 'failed', error.message);
  }
}

// ── queue 3: the website's /session page ───────────────────
async function runImport() {
  const row = await claimImport();
  if (!row) return;

  const { id, phone, payload } = row;
  try {
    const creds = decodeSession(payload);
    const number = digits(creds.me.id.split('@')[0].split(':')[0]) || digits(phone);
    const sessionId = sessionIdForPhone(number);

    writeCreds(sessionId, creds);
    await db.query(`UPDATE ${db.TABLES.imports} SET payload = NULL WHERE id = $1`, [id]);

    const timer = setTimeout(() => {
      if (!pendingImports.has(number)) return;
      pendingImports.delete(number);
      setImportStatus(id, 'failed', 'The socket never opened within 45s.');
    }, IMPORT_TIMEOUT_MS);
    if (timer.unref) timer.unref();
    pendingImports.set(number, { id, timer });

    await starter(sessionId, null, null, null);
    log('import accepted for', number, '->', sessionId);
  } catch (error) {
    fail('import failed:', error.message);
    await setImportStatus(id, 'failed', error.message);
  }
}

async function expireStale() {
  try {
    await db.query(
      `UPDATE ${db.TABLES.requests} SET status = 'expired'
        WHERE status IN ('pending', 'processing') AND expires_at < now()`);
  } catch (_) {}
  try {
    await db.query(
      `UPDATE ${db.TABLES.imports} SET status = 'expired', payload = NULL, updated_at = now()
        WHERE status = 'pending' AND expires_at <= now()`);
  } catch (_) {}
}

// ── socket lifecycle hooks (called from index.js) ──────────

/** WhatsApp opened: close the website rows that were waiting for it. */
function onSocketOpen(waNum, sessionId) {
  const phone = digits(waNum);
  if (!phone) return;

  const requestId = pendingRequests.get(phone);
  if (requestId) {
    pendingRequests.delete(phone);
    markPairingConnected(requestId)
      .then(() => log(`pairing request #${requestId} marked connected`))
      .catch((e) => fail('could not mark connected:', e.message));
  }

  const imported = pendingImports.get(phone);
  if (imported) {
    pendingImports.delete(phone);
    clearTimeout(imported.timer);
    setImportStatus(imported.id, 'connected').catch(() => {});
  }

  markSubmissionByPhone(phone, 'connected').catch(() => {});
  // Keep the real folder name: a Telegram pair is wa_<uid>_<phone>, a website
  // pair is wa_web_<phone>, and both must appear under their own id.
  upsertSession(sessionId || SESSION_PREFIX + phone, phone, 'connected').catch(() => {});
}

/** Socket closed: forget pending rows and mirror the disconnect. */
function onSocketClose(sessionId, statusCode) {
  const phone = digits(String(sessionId || '').split('_').pop());
  upsertSession(sessionId || 'unknown', null, 'disconnected').catch(() => {});

  // 401/403 = WhatsApp refused the credentials. A normal pairing close (515)
  // is followed by a reconnect and must not fail the website row.
  const rejected = statusCode === 401 || statusCode === 403;
  if (!phone || !rejected) return;

  const requestId = pendingRequests.get(phone);
  if (requestId) {
    pendingRequests.delete(phone);
    markPairingFailed(requestId, 'WhatsApp rejected this pairing (logged out).').catch(() => {});
  }

  const imported = pendingImports.get(phone);
  if (imported) {
    pendingImports.delete(phone);
    clearTimeout(imported.timer);
    setImportStatus(imported.id, 'failed', 'WhatsApp rejected this session (logged out).').catch(() => {});
  }

  markSubmissionByPhone(phone, 'failed', 'WhatsApp rejected this session.').catch(() => {});
}

/** Compact state for /webstatus. */
function status() {
  return {
    ...db.status(),
    pendingRequests: pendingRequests.size,
    pendingImports: pendingImports.size,
    loops: { pairing: pairingLoop, submission: submissionLoop, import: importLoop },
  };
}

// ── start / stop ───────────────────────────────────────────
function startAll(opts = {}) {
  if (typeof opts.startWhatsApp !== 'function') {
    warn('startAll needs startWhatsApp - website bridging stays off.');
    return false;
  }
  starter = opts.startWhatsApp;

  if (!db.ENABLED) {
    warn('NEON_DATABASE_URL not set - website pairing disabled. Add it to .env to turn it on.');
    return false;
  }

  db.ensureSchema()
    .then(() => db.ping())
    .then((ok) => {
      if (ok) log(`WEBSITE CONNECTED - Neon ${db.status().host} ready, waiting for pairing requests`);
      else fail('WEBSITE NOT CONNECTED -', db.status().lastError);
    })
    .catch((error) => fail('schema check failed:', error.message));

  if (!pairingLoop) {
    pairingLoop = true;
    setInterval(async () => {
      if (busy.pairing) return;
      busy.pairing = true;
      try {
        await runPairingRequest();
      } catch (error) {
        failThrottled('pairing poll', error);
      } finally {
        busy.pairing = false;
      }
    }, POLL_PAIRING_MS);
    log(`pairing loop started (${POLL_PAIRING_MS / 1000}s)`);
  }

  if (!submissionLoop) {
    submissionLoop = true;
    setInterval(async () => {
      if (busy.submission) return;
      busy.submission = true;
      try {
        await runSubmission();
      } catch (error) {
        failThrottled('submission poll', error);
      } finally {
        busy.submission = false;
      }
    }, POLL_SUBMISSION_MS);
    log(`pasted-session loop started (${POLL_SUBMISSION_MS / 1000}s)`);
  }

  if (!importLoop) {
    importLoop = true;
    setInterval(async () => {
      if (busy.import) return;
      busy.import = true;
      try {
        await runImport();
      } catch (error) {
        failThrottled('import poll', error);
      } finally {
        busy.import = false;
      }
    }, POLL_IMPORT_MS);
    log(`/session import loop started (${POLL_IMPORT_MS / 1000}s)`);
  }

  setInterval(() => { expireStale().catch(() => {}); }, 60000);

  return true;
}

module.exports = {
  startAll,
  status,
  onSocketOpen,
  onSocketClose,
  markSubmissionByPhone,
  markPairingConnected,
  markPairingFailed,
  setPairingCode,
  upsertSession,
  findSessionForPhone,
  decodeSession,
  // exported for the diagnostics script
  claimPairingRequest,
  claimSubmission,
  claimImport,
  SESSION_PREFIX,
};
