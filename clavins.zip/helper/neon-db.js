// ============================================================
//   helper/neon-db.js  –  Neon Postgres connection for the pairing website
//
//   One pool for the whole process. The same URL the website (Vercel)
//   uses goes in NEON_DATABASE_URL; every table this bot touches is
//   listed in TABLES so nobody has to guess the names.
//
//   Tables are the ones the TALKLESS pairing website already writes to,
//   so pointing this bot at an existing Neon project just works.
// ============================================================
'use strict';

// Containers/VPS often have no IPv6 route - force IPv4-first DNS so Postgres
// connections don't hang on IPv6 and die with ETIMEDOUT.
try { require('dns').setDefaultResultOrder('ipv4first'); } catch (_) { /* older node */ }

// The driver is optional at require time: a host that pulled this update
// without re-running `npm install` must still boot its WhatsApp/Telegram side
// instead of dying on a missing module.
let Pool = null;
let driverError = null;
try {
  ({ Pool } = require('pg'));
} catch (error) {
  driverError = 'pg driver missing - run "npm install pg"';
  console.error('[NEON] ' + driverError);
}

const TABLES = {
  requests:    'talkless_pairing_requests',
  sessions:    'talkless_sessions',
  submissions: 'talkless_session_submissions',
  imports:     'talkless_session_imports',
};

// Strip quotes/whitespace and the ?sslmode=... part: older pg versions ignore
// sslmode, and Neon then rejects a non-TLS connection.
const NEON_URL = String(process.env.NEON_DATABASE_URL || '').trim()
  .replace(/^['"\s]+|['"\s]+$/g, '')
  .split('?')[0];

const ENABLED = Boolean(NEON_URL) && Boolean(Pool);

let pool = null;
let connected = false;
let lastError = null;

function getPool() {
  if (!Pool) throw new Error(driverError || 'pg driver unavailable');
  if (!pool) {
    pool = new Pool({
      connectionString: NEON_URL || undefined,
      ...(NEON_URL ? { ssl: { rejectUnauthorized: false } } : {}),
      connectionTimeoutMillis: 10000,
      idleTimeoutMillis: 30000,
      max: 5,
    });
    pool.on('error', (err) => {
      console.error('[NEON] idle client error:', err && (err.message || err));
    });
  }
  return pool;
}

async function query(text, params) {
  if (!ENABLED) throw new Error('NEON_DATABASE_URL is not set');
  return getPool().query(text, params);
}

/**
 * Create every table/index the website needs. The SQL file exists for people
 * who prefer the Neon SQL editor; this runs the same statements on boot so a
 * fresh database works without the extra step.
 */
async function ensureSchema() {
  if (!ENABLED) return false;
  await query(`
    CREATE TABLE IF NOT EXISTS ${TABLES.requests} (
      id           SERIAL PRIMARY KEY,
      phone        TEXT NOT NULL,
      status       TEXT NOT NULL DEFAULT 'pending',
      pairing_code TEXT,
      error        TEXT,
      created_at   TIMESTAMPTZ DEFAULT now(),
      expires_at   TIMESTAMPTZ DEFAULT now() + interval '5 minutes',
      updated_at   TIMESTAMPTZ DEFAULT now()
    )`);

  await query(`
    CREATE TABLE IF NOT EXISTS ${TABLES.sessions} (
      id         TEXT PRIMARY KEY,
      phone      TEXT,
      status     TEXT DEFAULT 'disconnected',
      updated_at TIMESTAMPTZ DEFAULT now()
    )`);

  await query(`
    CREATE TABLE IF NOT EXISTS ${TABLES.submissions} (
      id         BIGSERIAL PRIMARY KEY,
      phone      TEXT NOT NULL,
      session    TEXT,
      status     TEXT NOT NULL DEFAULT 'pending',
      error      TEXT,
      claimed_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`);

  await query(`
    CREATE TABLE IF NOT EXISTS ${TABLES.imports} (
      id          BIGSERIAL PRIMARY KEY,
      phone       TEXT NOT NULL,
      payload     TEXT,
      status      TEXT NOT NULL DEFAULT 'pending',
      claim_token TEXT NOT NULL DEFAULT '',
      error       TEXT,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
      expires_at  TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '10 minutes')
    )`);

  // Older builds created payload as NOT NULL while the wipe query writes NULL.
  try {
    await query(`ALTER TABLE ${TABLES.imports} ALTER COLUMN payload DROP NOT NULL`);
  } catch (_) { /* already nullable, or no ALTER rights */ }

  await query(`CREATE INDEX IF NOT EXISTS ${TABLES.requests}_status_idx ON ${TABLES.requests} (status, id)`);
  await query(`CREATE INDEX IF NOT EXISTS ${TABLES.submissions}_status_idx ON ${TABLES.submissions} (status, id)`);
  await query(`CREATE INDEX IF NOT EXISTS ${TABLES.imports}_status_idx ON ${TABLES.imports} (status, id)`);

  return true;
}

/** True when the database answers - used by boot and the status command. */
async function ping() {
  if (!ENABLED) return false;
  try {
    await query('SELECT 1');
    connected = true;
    lastError = null;
    return true;
  } catch (error) {
    connected = false;
    lastError = error && (error.message || String(error));
    return false;
  }
}

/** Short, UI-friendly state for the Telegram /webstatus reply. */
function status() {
  let host = null;
  try { host = new URL(NEON_URL).host; } catch (_) { /* invalid URL */ }
  return {
    enabled: ENABLED,
    connected,
    host,
    lastError: lastError || driverError,
    driver: Pool ? 'pg' : 'missing',
    tables: TABLES,
  };
}

/** Human-readable one-liner: "ONLINE (host)" or "OFF (no database)". */
function statusLine() {
  if (!ENABLED) return 'OFF (no database)';
  if (lastError) return `ERROR (${lastError})`;
  return connected ? `ONLINE (${status().host})` : `CONNECTING (${status().host})`;
}

module.exports = {
  TABLES,
  NEON_URL,
  ENABLED,
  query,
  getPool,
  ensureSchema,
  ping,
  status,
  statusLine,
};
