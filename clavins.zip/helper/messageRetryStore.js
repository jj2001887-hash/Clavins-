'use strict';

/**
 * Recent outbound WhatsApp message cache used to answer recipient retry receipts.
 * Kept in memory only; private message content is never written to disk.
 */
function createMessageRetryStore({ maxEntries = 5000, ttlMs = 24 * 60 * 60 * 1000, now = Date.now } = {}) {
  const byChatAndId = new Map();
  const byId = new Map();

  const compositeKey = key => key?.remoteJid && key?.id
    ? `${key.remoteJid}:${key.id}`
    : null;

  function prune() {
    const cutoff = now() - ttlMs;
    for (const [k, entry] of byChatAndId) {
      if (entry.savedAt < cutoff) byChatAndId.delete(k);
    }
    for (const [id, entry] of byId) {
      if (entry.savedAt < cutoff) byId.delete(id);
    }
    while (byChatAndId.size > maxEntries) {
      const oldestKey = byChatAndId.keys().next().value;
      const oldest = byChatAndId.get(oldestKey);
      byChatAndId.delete(oldestKey);
      if (oldest && byId.get(oldest.id) === oldest) byId.delete(oldest.id);
    }
    while (byId.size > maxEntries) byId.delete(byId.keys().next().value);
  }

  return {
    remember(key, message) {
      if (!key?.id || !message) return;
      const entry = { id: String(key.id), message, savedAt: now() };
      const exact = compositeKey(key);
      if (exact) byChatAndId.set(exact, entry);
      byId.set(entry.id, entry);
      prune();
    },
    get(key) {
      prune();
      const exact = compositeKey(key);
      const entry = (exact && byChatAndId.get(exact)) || (key?.id && byId.get(String(key.id)));
      return entry?.message;
    },
    get size() { return byId.size; }
  };
}

module.exports = { createMessageRetryStore };
