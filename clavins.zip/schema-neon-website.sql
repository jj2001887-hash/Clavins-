-- ============================================================
--   CLAVOHH / TALKLESS — Neon schema for the pairing website
--
--   Apply once in the Neon SQL editor (or let the bot do it on boot:
--   helper/neon-db.js runs the same statements with IF NOT EXISTS).
--
--   These are the exact table names the pairing website already uses,
--   so an existing site + this bot share one database with no changes.
-- ============================================================

-- ── 1. Pairing requests: the site asks, the bot answers ─────
CREATE TABLE IF NOT EXISTS talkless_pairing_requests (
  id           SERIAL PRIMARY KEY,
  phone        TEXT NOT NULL,
  -- pending -> processing -> code_generated -> connected
  --                              \-> failed / expired
  status       TEXT NOT NULL DEFAULT 'pending',
  pairing_code TEXT,
  error        TEXT,
  created_at   TIMESTAMPTZ DEFAULT now(),
  expires_at   TIMESTAMPTZ DEFAULT now() + interval '5 minutes',
  updated_at   TIMESTAMPTZ DEFAULT now()
);

-- ── 2. Live session mirror (website stats) ─────────────────
CREATE TABLE IF NOT EXISTS talkless_sessions (
  id         TEXT PRIMARY KEY,
  phone      TEXT,
  status     TEXT DEFAULT 'disconnected',   -- connected / disconnected / logged_out
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ── 3. Session strings pasted on the site ──────────────────
CREATE TABLE IF NOT EXISTS talkless_session_submissions (
  id         BIGSERIAL PRIMARY KEY,
  phone      TEXT NOT NULL,
  session    TEXT,                          -- "TALKLESS!<base64>"
  status     TEXT NOT NULL DEFAULT 'pending',
  -- pending -> claimed -> connecting -> connected | failed
  error      TEXT,
  claimed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── 4. The website's /session page queue ───────────────────
CREATE TABLE IF NOT EXISTS talkless_session_imports (
  id          BIGSERIAL PRIMARY KEY,
  phone       TEXT NOT NULL,
  payload     TEXT,                         -- base64 creds, wiped once used
  status      TEXT NOT NULL DEFAULT 'pending',
  -- pending -> claimed -> connected | failed | expired
  claim_token TEXT NOT NULL DEFAULT '',
  error       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '10 minutes')
);

-- ── Indexes the claim queries rely on ──────────────────────
CREATE INDEX IF NOT EXISTS talkless_pairing_requests_status_idx
  ON talkless_pairing_requests (status, id);

CREATE INDEX IF NOT EXISTS talkless_session_submissions_status_idx
  ON talkless_session_submissions (status, id);

CREATE INDEX IF NOT EXISTS talkless_session_imports_status_idx
  ON talkless_session_imports (status, id);

-- ── Optional: kept for compatibility, this bot never reads it ──
CREATE TABLE IF NOT EXISTS talkless_premium_keys (
  id         SERIAL PRIMARY KEY,
  key        TEXT UNIQUE NOT NULL,
  status     TEXT NOT NULL DEFAULT 'unused',
  used_phone TEXT,
  used_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS talkless_settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
