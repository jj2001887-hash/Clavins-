'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('node:module');

const bridgePath = require.resolve('../talklessBridge');
const sessionFs = require('../talkless/sessionFs');
const sessionCtx = require('../talkless/utils/sessionCtx');
const calls = [];
const databaseScopes = [];

function record(name, result = name) {
  return (...args) => {
    calls.push({ name, session: sessionCtx.current(), args });
    return result;
  };
}

const fakeHandler = {
  getCommandCount: () => 0,
  handleMessage: record('handleMessage'),
  storeForAnti: record('storeForAnti'),
  handleMessagesUpdate: record('handleMessagesUpdate'),
  handleRevokes: record('handleRevokes'),
  handleEdits: record('handleEdits'),
  handleGroupUpdate: record('handleGroupUpdate'),
  initializeAntiCall: record('initializeAntiCall')
};
const fakeDatabase = {
  loadSettings() {
    databaseScopes.push(sessionCtx.current());
    return { enabled: false, react: false };
  }
};

const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (parent && parent.filename === bridgePath) {
    if (request === './talkless/handler') return fakeHandler;
    if (request === './talkless/database') return fakeDatabase;
  }
  return originalLoad.call(this, request, parent, isMain);
};
const bridge = require('../talklessBridge');
Module._load = originalLoad;

// Intercept only the bridge's lazy loads; other test files/processes use the real modules.
async function withBridgeMocks(fn) {
  Module._load = function (request, parent, isMain) {
    if (parent && parent.filename === bridgePath) {
      if (request === './talkless/handler') return fakeHandler;
      if (request === './talkless/database') return fakeDatabase;
    }
    return originalLoad.call(this, request, parent, isMain);
  };
  try {
    return await fn();
  } finally {
    Module._load = originalLoad;
  }
}

const sockA = { user: { id: '254700000001:4@s.whatsapp.net' } };
const sockB = { user: { id: '254700000002:9@s.whatsapp.net' } };
const statusMessage = {
  key: {
    id: 'status-test',
    remoteJid: 'status@broadcast',
    participant: '254711111111@s.whatsapp.net'
  },
  message: { conversation: 'status' }
};

// The bridge's session extractor strips JID device suffixes and retains the paired number.
const scopeA = sessionFs.sessionFromSock(sockA);
const scopeB = sessionFs.sessionFromSock(sockB);

test('bridge operations fail closed without a paired identity and isolate valid sessions', async () => {
  calls.length = 0;
  databaseScopes.length = 0;

  await withBridgeMocks(async () => {
    for (const sock of [{}, { user: {} }, { user: { id: 'not-a-paired-jid' } }]) {
      assert.equal(await bridge.handle(sock, {}), undefined);
      assert.equal(await bridge.handleStatus(sock, statusMessage), undefined);
      assert.equal(await bridge.handleMessagesUpdate(sock, []), undefined);
      assert.equal(await bridge.handleRevoke(sock, []), undefined);
      assert.equal(await bridge.handleEdit(sock, []), undefined);
      assert.equal(await bridge.handleGroupUpdate(sock, {}), undefined);
      assert.equal(bridge.store(sock, { message: { conversation: 'must not store' } }), undefined);
      assert.throws(
        () => bridge.initializeStatusSettings(sock),
        /without a paired identity/
      );
    }

    assert.deepEqual(calls, [], 'no handler may run for missing or unstable socket identity');
    assert.deepEqual(databaseScopes, [], 'no missing-identity call may read the shared database');

    for (const [sock, expectedScope] of [[sockA, scopeA], [sockB, scopeB]]) {
      assert.equal(await bridge.handle(sock, {}), 'handleMessage');
      assert.equal(bridge.store(sock, { message: { conversation: 'cached' } }), undefined);
      assert.equal(await bridge.handleMessagesUpdate(sock, []), 'handleMessagesUpdate');
      assert.equal(await bridge.handleRevoke(sock, []), 'handleRevokes');
      assert.equal(await bridge.handleEdit(sock, []), 'handleEdits');
      assert.equal(await bridge.handleGroupUpdate(sock, {}), 'handleGroupUpdate');

      const settings = bridge.initializeStatusSettings(sock);
      assert.deepEqual(settings, { enabled: false, react: false });

      // Keep the status queue's delays deterministic without changing bridge behavior.
      const originalSetTimeout = global.setTimeout;
      global.setTimeout = (fn) => originalSetTimeout(fn, 0);
      try {
        assert.equal(await bridge.handleStatus(sock, statusMessage), undefined);
      } finally {
        global.setTimeout = originalSetTimeout;
      }

      const scopedCalls = calls.filter(call => call.session === expectedScope);
      assert.deepEqual(
        scopedCalls.map(call => call.name),
        ['handleMessage', 'storeForAnti', 'handleMessagesUpdate', 'handleRevokes', 'handleEdits', 'handleGroupUpdate'],
        `each handler operation should run only in ${expectedScope}`
      );
    }
  });

  assert.equal(scopeA, '254700000001');
  assert.equal(scopeB, '254700000002');
  assert.deepEqual(databaseScopes, [scopeA, scopeA, scopeB, scopeB]);
  assert.ok(calls.every(call => call.session === scopeA || call.session === scopeB));
});
