'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createMessageRetryStore } = require('../helper/messageRetryStore');

test('retry cache retrieves by exact chat key and falls back to message ID', () => {
  const store = createMessageRetryStore();
  const payload = { conversation: 'hello' };
  store.remember({ remoteJid: '15550001@s.whatsapp.net', id: 'msg-1' }, payload);
  assert.equal(store.get({ remoteJid: '15550001@s.whatsapp.net', id: 'msg-1' }), payload);
  assert.equal(store.get({ remoteJid: '15550001:9@s.whatsapp.net', id: 'msg-1' }), payload);
  assert.equal(store.get({ remoteJid: '15550001@s.whatsapp.net', id: 'missing' }), undefined);
});

test('retry cache prunes expired entries and enforces its size bound', () => {
  let time = 100;
  const store = createMessageRetryStore({ maxEntries: 2, ttlMs: 10, now: () => time });
  store.remember({ remoteJid: 'jid', id: 'a' }, { conversation: 'a' });
  time += 1;
  store.remember({ remoteJid: 'jid', id: 'b' }, { conversation: 'b' });
  time += 1;
  store.remember({ remoteJid: 'jid', id: 'c' }, { conversation: 'c' });
  assert.equal(store.size, 2);
  assert.equal(store.get({ remoteJid: 'jid', id: 'a' }), undefined);
  time += 20;
  assert.equal(store.get({ remoteJid: 'jid', id: 'c' }), undefined);
  assert.equal(store.size, 0);
});
