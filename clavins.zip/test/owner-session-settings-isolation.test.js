'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

// Install the same per-session filesystem context used by the bridge before
// loading database-backed commands.
const sessionFs = require('../talkless/sessionFs');
const db = require('../talkless/database');
const setOwnerNumber = require('../talkless/commands/owner/setownernumber');
const setOwnerName = require('../talkless/commands/owner/setownername');
const setPrefix = require('../talkless/commands/owner/setprefix');
const config = require('../talkless/config');

const configPath = path.join(__dirname, '../talkless/config.js');
const databaseNumbersPath = path.join(__dirname, '../talkless/database/numbers');
const fakeSock = {};

async function execute(command, args) {
  const replies = [];
  await command.execute(fakeSock, { message: {} }, args, {
    reply: async text => { replies.push(text); }
  });
  assert.ok(replies.length, 'command should reply');
  assert.ok(!replies.some(text => text.startsWith('❌ Error:')), 'command should complete without an error reply');
  return replies[replies.length - 1];
}

function settingsFor(session) {
  return sessionFs.runWithSession(session, () => db.getAllBotSettings());
}

test('owner settings remain isolated between paired-number session scopes', async () => {
  const suffix = `${process.pid}-${Date.now()}`;
  const sessionA = `owner-isolation-${suffix}-a`;
  const sessionB = `owner-isolation-${suffix}-b`;
  const configHashBefore = crypto.createHash('sha256').update(fs.readFileSync(configPath)).digest('hex');
  const configSnapshot = {
    ownerNumber: JSON.stringify(config.ownerNumber),
    ownerName: JSON.stringify(config.ownerName),
    prefix: JSON.stringify(config.prefix)
  };

  try {
    await sessionFs.runWithSession(sessionA, async () => {
      await execute(setOwnerNumber, ['254700000001']);
      await execute(setOwnerName, ['Session', 'Alpha']);
      await execute(setPrefix, ['~']);
    });

    await sessionFs.runWithSession(sessionB, async () => {
      await execute(setOwnerNumber, ['254700000002']);
      await execute(setOwnerName, ['Session', 'Beta']);
      await execute(setPrefix, ['none']);
    });

    const settingsA = settingsFor(sessionA);
    const settingsB = settingsFor(sessionB);
    assert.equal(settingsA.ownerNumber, '254700000001', 'session A should retain its own owner number');
    assert.equal(settingsA.ownerName, 'Session Alpha', 'session A should retain its own owner name');
    assert.equal(settingsA.prefix, '~', 'session A should retain its own prefix');
    assert.equal(settingsB.ownerNumber, '254700000002', 'session B should retain its own owner number');
    assert.equal(settingsB.ownerName, 'Session Beta', 'session B should retain its own owner name');
    assert.equal(settingsB.prefix, '', 'session B should retain its own empty prefix');

    assert.ok(
      config.ownerNumber !== undefined && JSON.stringify(config.ownerNumber) === configSnapshot.ownerNumber &&
      JSON.stringify(config.ownerName) === configSnapshot.ownerName &&
      JSON.stringify(config.prefix) === configSnapshot.prefix,
      'owner commands must not mutate the shared config object'
    );
    const configHashAfter = crypto.createHash('sha256').update(fs.readFileSync(configPath)).digest('hex');
    assert.ok(configHashAfter === configHashBefore, 'owner commands must not rewrite shared config.js');
  } finally {
    // Database writes are flushed via setImmediate; let those finish before cleanup.
    await new Promise(resolve => setImmediate(resolve));
    for (const session of [sessionA, sessionB]) {
      execFileSync('rm', ['-rf', path.join(databaseNumbersPath, session)]);
    }
  }
});
