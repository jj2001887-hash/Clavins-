'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

test('real session files persist separate owner and prefix settings without changing global config', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'talkless-isolation-'));
  const root = path.resolve(__dirname, '../talkless');
  const wanted = ['config.js', 'database.js', 'sessionFs.js', 'utils/sessionCtx.js', 'commands/owner/setownernumber.js', 'commands/owner/setownername.js', 'commands/owner/setprefix.js'];
  try {
    for (const name of wanted) {
      const dest = path.join(tmp, name);
      fs.mkdirSync(path.dirname(dest), { recursive: true, mode: 0o700 });
      fs.copyFileSync(path.join(root, name), dest);
      fs.chmodSync(dest, 0o600);
    }
    const originalConfig = fs.readFileSync(path.join(tmp, 'config.js'));
    const sessionFs = require(path.join(tmp, 'sessionFs.js'));
    const db = require(path.join(tmp, 'database.js'));
    const config = require(path.join(tmp, 'config.js'));
    const owner = require(path.join(tmp, 'commands/owner/setownernumber.js'));
    const ownerName = require(path.join(tmp, 'commands/owner/setownername.js'));
    const prefix = require(path.join(tmp, 'commands/owner/setprefix.js'));
    const extra = { reply: async () => {} };
    const message = { message: {} };
    await Promise.all([
      sessionFs.runWithSession('111111111', async () => {
        await owner.execute({}, message, ['111111111'], extra);
        await ownerName.execute({}, message, ['Alpha'], extra);
        await prefix.execute({}, message, ['!'], extra);
        assert.deepEqual(config.ownerNumber, ['111111111']);
        assert.equal(config.prefix, '!');
      }),
      sessionFs.runWithSession('222222222', async () => {
        await owner.execute({}, message, ['222222222'], extra);
        await ownerName.execute({}, message, ['Beta'], extra);
        await prefix.execute({}, message, ['?'], extra);
        assert.deepEqual(config.ownerNumber, ['222222222']);
        assert.equal(config.prefix, '?');
      })
    ]);
    await new Promise(resolve => setTimeout(resolve, 30));
    for (const [sid, number, name, mark] of [['111111111', '111111111', 'Alpha', '!'], ['222222222', '222222222', 'Beta', '?']]) {
      const file = path.join(tmp, 'database', 'numbers', sid, 'bot-settings.json');
      const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
      assert.equal(saved.ownerNumber, number);
      assert.equal(saved.ownerName, name);
      assert.equal(saved.prefix, mark);
      sessionFs.runWithSession(sid, () => assert.equal(db.getBotSetting('prefix'), mark));
    }
    assert.deepEqual(fs.readFileSync(path.join(tmp, 'config.js')), originalConfig);
  } finally {
    await new Promise(resolve => setTimeout(resolve, 30));
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});
