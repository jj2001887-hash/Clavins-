'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

// Install per-session file scoping before loading the database-backed command.
const sessionFs = require('../talkless/sessionFs');
const database = require('../talkless/database');
const anticall = require('../talkless/commands/owner/anticall');
const config = require('../talkless/config');
const configPath = path.join(__dirname, '../talkless/config.js');
const databaseNumbersPath = path.join(__dirname, '../talkless/database/numbers');

async function execute(args) {
  const replies = [];
  await anticall.execute({}, { message: {} }, args, {
    reply: async text => { replies.push(text); }
  });
  assert.equal(replies.length, 1, 'command should reply exactly once');
  assert.ok(!replies[0].startsWith('❌'), 'command should complete without an error reply');
  return replies[0];
}

function settingsFor(session) {
  return sessionFs.runWithSession(session, () => ({
    anticall: database.getBotSetting('anticall'),
    anticallAction: database.getBotSetting('anticallAction')
  }));
}

test('anticall command persists keys per session without changing shared config', async () => {
  const suffix = `${process.pid}-${Date.now()}`;
  const sessionA = `anticall-regression-${suffix}-a`;
  const sessionB = `anticall-regression-${suffix}-b`;
  const configHashBefore = crypto.createHash('sha256').update(fs.readFileSync(configPath)).digest('hex');
  const configSnapshot = JSON.stringify(config.defaultGroupSettings);

  try {
    const expected = [
      ['off', false, 'block', '📵 Anti-Call set to *OFF*.'],
      ['decline', true, 'decline', '📵 Anti-Call set to *Decline*.'],
      ['block', true, 'block', '🚫 Anti-Call set to *Block*.'],
      ['on', true, 'block', '🚫 Anti-Call set to *Block*.']
    ];
    for (const [option, enabled, action, reply] of expected) {
      const actualReply = await sessionFs.runWithSession(sessionA, () => execute([option]));
      assert.equal(actualReply, reply, `.${option} should keep its established reply`);
      assert.deepEqual(settingsFor(sessionA), { anticall: enabled, anticallAction: action }, `.${option} should save both keys`);
    }

    const replyB = await sessionFs.runWithSession(sessionB, () => execute(['decline']));
    assert.equal(replyB, '📵 Anti-Call set to *Decline*.');
    assert.deepEqual(settingsFor(sessionB), { anticall: true, anticallAction: 'decline' });
    assert.deepEqual(settingsFor(sessionA), { anticall: true, anticallAction: 'block' }, 'session B must not overwrite session A');

    assert.equal(config.defaultGroupSettings.anticall === undefined, false, 'config default should remain available');
    assert.equal(JSON.stringify(config.defaultGroupSettings), configSnapshot, 'command must not mutate the shared config object');
    const configHashAfter = crypto.createHash('sha256').update(fs.readFileSync(configPath)).digest('hex');
    assert.equal(configHashAfter, configHashBefore, 'command must not rewrite shared config.js');

    const statusReply = await sessionFs.runWithSession(sessionB, () => execute([]));
    assert.match(statusReply, /Anti-Call: \*enabled\*/);
  } finally {
    // Let database's deferred writes complete before removing the synthetic sessions.
    await new Promise(resolve => setImmediate(resolve));
    for (const session of [sessionA, sessionB]) {
      execFileSync('rm', ['-rf', path.join(databaseNumbersPath, session)]);
    }
  }
});
