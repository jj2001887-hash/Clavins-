'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('node:module');
const path = require('node:path');

const handlerPath = path.resolve(__dirname, '../talkless/handler.js');
const sessionContext = require('../talkless/utils/sessionCtx');
const config = require('../talkless/config');
const originalOwnerNumber = config.ownerNumber;
const sessionSettings = new Map();
const currentSettings = () => sessionSettings.get(sessionContext.current() || 'default') || {};
const fakeDatabase = {
  getBotSetting(key) {
    const values = currentSettings();
    if (Object.prototype.hasOwnProperty.call(values, key)) return values[key];
    if (key === 'prefix') return '.';
    if (key === 'autoReadMode') return 'off';
    if (key === 'antibug') return false;
    return undefined;
  },
  isModerator() { return false; },
  getGroupSettings() { return {}; },
  getBadWords() { return []; },
  isUserMuted() { return false; },
};

const commandMap = new Map();
const stubLoadCommands = () => commandMap;
const commandScope = { run: (_enabled, fn) => fn() };
const chalkPassThrough = value => value;
const chalk = {
  magenta: { bold: chalkPassThrough }, cyan: chalkPassThrough,
  yellow: chalkPassThrough, green: chalkPassThrough,
  blue: chalkPassThrough, white: chalkPassThrough,
};
const participantAdmin = new Map();
const baileysStub = {
  jidDecode(jid) {
    if (typeof jid !== 'string' || !jid.includes('@')) return null;
    const [rawUser, server] = jid.split('@');
    return { user: rawUser.split(':')[0], server };
  },
  jidEncode(user, server) { return `${user}@${server}`; },
  WAMessageStubType: { REVOKE: 1 },
};

const originalLoad = Module._load;
const originalSetInterval = global.setInterval;
global.setInterval = () => ({ unref() {} });
Module._load = function(request, parent, isMain) {
  if (parent?.filename === handlerPath) {
    if (request === './database') return fakeDatabase;
    if (request === './utils/commandLoader') return { loadCommands: stubLoadCommands };
    if (request === './utils/stickerCommandStore') return { hashSticker: () => null, getMap: () => ({}) };
    if (request === './utils/groupstats') return { addMessage() {}, getActiveUsers: () => [], getInactiveUsers: () => [] };
    if (request === './utils/autoReact') return { load: () => ({ enabled: false, mode: 'bot' }) };
    if (request === './utils/botMode') return { getMode: () => 'public', canRespond: () => true };
    if (request === './utils/presenceSettings') return { getMode: () => 'off' };
    if (request === './utils/fontConverter') return { applyFont: value => value };
    if (request === './utils/box') return { BOX_CHARS: /[\u2500-\u257f]/, wrapText: value => value };
    if (request === '../helper/cleanText') return { commandScope };
    if (request === './commands/fun/bomb') return { gameState: new Map() };
    if (request === './commands/fun/tictactoe') return { games: {}, handleTicTacToeMove: async () => false };
  }
  if (request === '@whiskeysockets/baileys') return baileysStub;
  if (request === 'axios') return {};
  if (request === 'chalk') return chalk;
  return originalLoad.call(this, request, parent, isMain);
};

let handler;
try {
  handler = require(handlerPath);
} finally {
  global.setInterval = originalSetInterval;
}

function makeSocket(id, metadataProvider = async () => ({ participants: [] })) {
  const sent = [];
  return {
    user: { id: `${id}:1@s.whatsapp.net` },
    sent,
    groupMetadata: async group => metadataProvider(group),
    sendMessage: async (...args) => { sent.push(args); return {}; },
    sendPresenceUpdate: async () => {},
    readMessages: async () => {},
    ev: { on() {} },
  };
}

function makeMessage(sock, text, { fromMe = false, remoteJid } = {}) {
  return {
    key: {
      remoteJid: remoteJid || (fromMe ? sock.user.id.split(':')[0] + '@s.whatsapp.net' : '90001@s.whatsapp.net'),
      fromMe,
      id: `msg-${Math.random().toString(16).slice(2)}`,
    },
    message: { conversation: text },
  };
}

function registerCommand(name, properties = {}) {
  const calls = [];
  commandMap.set(name, {
    name,
    ...properties,
    async execute(_sock, _msg, _args, extra) { calls.push(extra); },
  });
  return calls;
}

async function dispatch(session, sock, text, options) {
  return sessionContext.run(session, () => handler.handleMessage(sock, makeMessage(sock, text, options)));
}

async function dispatchButton(session, sock, id, { fromMe = false, remoteJid = '90001@s.whatsapp.net', template = false } = {}) {
  const msg = makeMessage(sock, '', { fromMe, remoteJid });
  if (remoteJid.endsWith('@g.us')) msg.key.participant = '90001@s.whatsapp.net';
  msg.message = template
    ? { templateButtonReplyMessage: { selectedId: id } }
    : { buttonsResponseMessage: { selectedButtonId: id } };
  return sessionContext.run(session, () => handler.handleMessage(sock, msg));
}

test.after(() => {
  Module._load = originalLoad;
  config.ownerNumber = originalOwnerNumber;
  sessionSettings.clear();
  commandMap.clear();
});

test('two sockets use their own persisted prefix without mutating global config', async () => {
  const calls = registerCommand('ping');
  const socketA = makeSocket('10001');
  const socketB = makeSocket('10002');
  sessionSettings.set('10001', { prefix: '.', ownerNumber: ['10001'] });
  sessionSettings.set('10002', { prefix: '!', ownerNumber: ['10002'] });
  const originalPrefix = config.prefix;

  await dispatch('10001', socketA, '.ping');
  await dispatch('10002', socketB, '!ping');
  await dispatch('10001', socketA, '!ping');

  assert.equal(calls.length, 2, 'only each session’s configured prefix should dispatch');
  assert.deepEqual(calls.map(call => call.prefix), ['.', '!']);
  assert.equal(config.prefix, originalPrefix, 'handler must never write a request prefix to global config');
});

test('owner identity defaults to the paired number and explicit overrides stay per session', async () => {
  sessionSettings.set('session-a', { ownerNumber: ['11110000'] });
  sessionSettings.set('session-b', { ownerNumber: [] });
  sessionSettings.set('55550000', {});
  assert.equal(sessionContext.run('55550000', () => fakeDatabase.getBotSetting('ownerNumber')), undefined);

  assert.equal(sessionContext.run('session-a', () => handler.isOwner('11110000@s.whatsapp.net')), true);
  assert.equal(sessionContext.run('session-a', () => handler.isOwner('99990000@s.whatsapp.net')), false);
  assert.equal(sessionContext.run('session-b', () => handler.isOwner(originalOwnerNumber[0])), false);
  assert.equal(sessionContext.run('55550000', () => handler.isOwner('55550000@s.whatsapp.net')), true);
  assert.equal(sessionContext.run('55550000', () => handler.isOwner(originalOwnerNumber[0])), false);
});

test('paired-only commands remain restricted to fromMe messages and are callable by each paired socket', async () => {
  const calls = registerCommand('pairedop', { pairedOnly: true });
  const ownerCalls = registerCommand('ownerop', { ownerOnly: true });
  const socketA = makeSocket('20001');
  const socketB = makeSocket('20002');
  sessionSettings.set('20001', { prefix: '.' });
  sessionSettings.set('20002', { prefix: '.' });

  await dispatch('20001', socketA, '.pairedop');
  await dispatch('20001', socketA, '.pairedop', { fromMe: true });
  await dispatch('20002', socketB, '.pairedop', { fromMe: true });
  await dispatch('20001', socketA, '.ownerop', { fromMe: true });

  assert.equal(calls.length, 2);
  assert.equal(ownerCalls.length, 1);
  assert.equal(ownerCalls[0].isOwner, true, 'fromMe remains an owner even without a configured phone owner entry');
  assert.equal(socketA.sent.some(([, content]) => String(content?.text || '').includes('Only the paired owner')), true);
});

test('buttons use the normal paired, owner and fresh group-admin permission checks', async () => {
  const paired = registerCommand('buttonpaired', { pairedOnly: true });
  const owner = registerCommand('buttonowner', { ownerOnly: true });
  const restrictedMenu = registerCommand('menu', { ownerOnly: true });
  const groupAdmin = registerCommand('buttongroup', { groupOnly: true, adminOnly: true, botAdminNeeded: true });
  let userRole = null;
  let botRole = 'admin';
  const socket = makeSocket('23001', async () => ({ participants: [
    { id: '90001@s.whatsapp.net', admin: userRole },
    { id: '23001:1@s.whatsapp.net', admin: botRole },
  ] }));
  sessionSettings.set('23001', { prefix: '!' });
  const group = '230-group@g.us';
  await dispatchButton('23001', socket, '!buttonpaired');
  await dispatchButton('23001', socket, '!buttonowner', { template: true });
  await dispatchButton('23001', socket, 'btn_menu');
  await dispatchButton('23001', socket, '!buttongroup', { remoteJid: group });
  assert.equal(paired.length, 0);
  assert.equal(owner.length, 0);
  assert.equal(restrictedMenu.length, 0);
  assert.equal(groupAdmin.length, 0);
  userRole = 'admin';
  await dispatchButton('23001', socket, '!buttongroup', { remoteJid: group, template: true });
  assert.equal(groupAdmin.length, 1, 'current group admin and bot admin can execute');
  botRole = null;
  await dispatchButton('23001', socket, '!buttongroup', { remoteJid: group });
  assert.equal(groupAdmin.length, 1, 'demoted bot may not execute bot-admin command');
  await dispatchButton('23001', socket, '.buttonpaired', { fromMe: true });
  await dispatchButton('23001', socket, '!buttonpaired', { fromMe: true });
  await dispatchButton('23001', socket, '!buttonowner', { fromMe: true });
  await dispatchButton('23001', socket, 'btn_menu', { fromMe: true });
  assert.equal(paired.length, 1, 'button must use this session’s prefix and paired identity');
  assert.equal(owner.length, 1);
  assert.equal(restrictedMenu.length, 1);
});

test('group metadata cache is scoped by session even for the same group JID', async () => {
  const group = '12345@g.us';
  let callsA = 0;
  let callsB = 0;
  const socketA = makeSocket('30001', async () => { callsA++; return { subject: 'A', participants: [] }; });
  const socketB = makeSocket('30002', async () => { callsB++; return { subject: 'B', participants: [] }; });

  const metadataA = await sessionContext.run('30001', () => handler.getGroupMetadata(socketA, group));
  const metadataB = await sessionContext.run('30002', () => handler.getGroupMetadata(socketB, group));
  const cachedA = await sessionContext.run('30001', () => handler.getGroupMetadata(socketA, group));

  assert.equal(metadataA.subject, 'A');
  assert.equal(metadataB.subject, 'B');
  assert.equal(cachedA.subject, 'A');
  assert.equal(callsA, 1);
  assert.equal(callsB, 1);
});

test('admin checks fetch fresh roles, observe demotion, isolate sockets, and fail closed on metadata errors', async () => {
  const group = 'same-group@g.us';
  const user = '40003@s.whatsapp.net';
  let roleA = 'admin';
  let botRoleA = 'admin';
  const socketA = makeSocket('40001', async () => ({
    participants: [
      { id: user, admin: roleA },
      { id: '40001:1@s.whatsapp.net', admin: botRoleA },
    ],
  }));
  const socketB = makeSocket('40002', async () => ({
    participants: [
      { id: user, admin: null },
      { id: '40002:1@s.whatsapp.net', admin: null },
    ],
  }));
  const staleAdminMetadata = { participants: [{ id: user, admin: 'admin' }] };

  assert.equal(await sessionContext.run('40001', () => handler.isAdmin(socketA, user, group, staleAdminMetadata)), true);
  assert.equal(await sessionContext.run('40002', () => handler.isAdmin(socketB, user, group, staleAdminMetadata)), false);
  roleA = null;
  assert.equal(await sessionContext.run('40001', () => handler.isAdmin(socketA, user, group, staleAdminMetadata)), false, 'a demotion must take effect immediately');

  assert.equal(await sessionContext.run('40001', () => handler.isBotAdmin(socketA, group, staleAdminMetadata)), true);
  botRoleA = null;
  assert.equal(await sessionContext.run('40001', () => handler.isBotAdmin(socketA, group, staleAdminMetadata)), false, 'bot demotion must take effect immediately');
  socketA.groupMetadata = async () => { throw new Error('metadata unavailable'); };
  assert.equal(await sessionContext.run('40001', () => handler.isBotAdmin(socketA, group, staleAdminMetadata)), false, 'old bot-admin status must not authorize when fresh metadata fails');
  assert.equal(await sessionContext.run('40001', () => handler.isAdmin(socketA, user, group, staleAdminMetadata)), false);
});
