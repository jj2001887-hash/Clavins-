# Talkless XMD — latest command fixes

This source package includes the tested `#kick`, `setstickercmd`, and chunked `kickall` updates, together with the existing Talkless XMD source and regression tests.

## Included changes

- `#kick` and `#kickall` authorize the invoking participant through their current group-admin role; the paired bot account must also be a group admin.
- `#kickall` removes eligible members sequentially in batches of up to 10, with a short delay between batches and a partial-failure summary. The paired account, bot, and group creator are protected.
- `setstickercmd` supports binding a sticker to a command, listing aliases, removing one alias, and clearing all aliases, with the current session's owner authorization.
- Regression tests cover authorization, sticker alias management, batch sizing, and partial failures.

## Safe deployment

This ZIP deliberately excludes live WhatsApp sessions, runtime database files, `node_modules`, `.env`, and service credentials. It includes `.env.example` with empty settings only. On a fresh deployment, supply your own service values through environment settings or a private `.env` file and pair the WhatsApp session again. When updating an existing installation, preserve its own session and database data separately; do not replace those runtime files with this source ZIP.

The three command files were installed on the Talkless XMD server. The running bot must receive a normal panel restart to load the updates; no force-stop is included or required by this ZIP.

Requires Node.js 18 or newer. Install dependencies with `npm install --omit=dev --no-audit --no-fund --legacy-peer-deps`, then use `npm start`. Run the regression suite with:

```bash
node --test test/*.test.js talkless/tests/*.test.js
```
